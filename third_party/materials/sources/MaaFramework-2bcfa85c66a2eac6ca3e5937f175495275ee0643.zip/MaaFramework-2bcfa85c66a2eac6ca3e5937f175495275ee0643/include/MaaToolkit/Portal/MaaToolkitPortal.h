// IWYU pragma: private, include <MaaToolkit/MaaToolkitAPI.h>

#pragma once

#include "../MaaToolkitDef.h"

#ifdef __cplusplus
extern "C"
{
#endif
    MAA_TOOLKIT_API MaaToolkitPortalHelper* MaaToolkitPortalHelperCreate();
    MAA_TOOLKIT_API void MaaToolkitPortalHelperDestroy(MaaToolkitPortalHelper* helper);
    MAA_TOOLKIT_API MaaBool MaaToolkitPortalHelperOpenStream(MaaToolkitPortalHelper* helper);
    MAA_TOOLKIT_API MaaBool MaaToolkitPortalHelperGetPersist(MaaToolkitPortalHelper* helper);
    MAA_TOOLKIT_API void MaaToolkitPortalHelperSetPersist(MaaToolkitPortalHelper* helper, MaaBool enable);
    MAA_TOOLKIT_API int MaaToolkitPortalHelperGetPipeWireFD(MaaToolkitPortalHelper* helper);
    MAA_TOOLKIT_API uint32_t MaaToolkitPortalHelperGetPipeWireNodeID(MaaToolkitPortalHelper* helper);
    MAA_TOOLKIT_API const char* MaaToolkitPortalHelperGetRestoreToken(MaaToolkitPortalHelper* helper);
    MAA_TOOLKIT_API void MaaToolkitPortalHelperSetRestoreToken(MaaToolkitPortalHelper* helper, const char* token);
#ifdef __cplusplus
}
#endif
