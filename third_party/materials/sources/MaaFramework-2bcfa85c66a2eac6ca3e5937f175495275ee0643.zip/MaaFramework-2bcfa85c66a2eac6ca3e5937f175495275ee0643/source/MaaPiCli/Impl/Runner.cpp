#include "ProjectInterface/Runner.h"

#include <format>
#include <iostream>

#include <meojson/json.hpp>

#include "MaaAgentClient/MaaAgentClientAPI.h"
#include "MaaFramework/MaaAPI.h"
#include "MaaToolkit/MaaToolkitAPI.h"

#include "Common/MaaTypes.h"
#include "MaaUtils/Encoding.h"
#include "MaaUtils/IOStream/BoostIO.hpp"
#include "MaaUtils/Logger.h"
#include "MaaUtils/Platform.h"
#include "MaaUtils/ScopeLeave.hpp"

MAA_PROJECT_INTERFACE_NS_BEGIN

#ifdef _WIN32
std::vector<std::wstring> conv_args(const std::vector<std::string>& args)
{
    std::vector<std::wstring> wargs;
    for (const auto& arg : args) {
        wargs.emplace_back(to_u16(arg));
    }
    return wargs;
}
#else
std::vector<std::string> conv_args(const std::vector<std::string>& args)
{
    return args;
}
#endif

RuntimeParam::AdbParam reconfig_adb(const RuntimeParam::AdbParam& raw)
{
    auto list_handle = MaaToolkitAdbDeviceListCreate();
    OnScopeLeave([&]() { MaaToolkitAdbDeviceListDestroy(list_handle); });

    MaaToolkitAdbDeviceFind(list_handle);

    size_t size = MaaToolkitAdbDeviceListSize(list_handle);
    for (size_t i = 0; i < size; ++i) {
        auto device_handle = MaaToolkitAdbDeviceListAt(list_handle, i);

        std::string name = MaaToolkitAdbDeviceGetName(device_handle);
        std::string path = MaaToolkitAdbDeviceGetAdbPath(device_handle);

        if (name != raw.name || path != raw.adb_path) {
            continue;
        }

        LogInfo << "Reconfigure ADB Param" << VAR(name) << VAR(path);

        std::string new_address = MaaToolkitAdbDeviceGetAddress(device_handle);
        if (raw.address != new_address) {
            LogInfo << "ADB Address changed" << VAR(raw.address) << VAR(new_address);
        }

        RuntimeParam::AdbParam new_param = raw;
        new_param.address = new_address;
        new_param.input = MaaToolkitAdbDeviceGetInputMethods(device_handle);
        new_param.screencap = MaaToolkitAdbDeviceGetScreencapMethods(device_handle);
        new_param.config = MaaToolkitAdbDeviceGetConfig(device_handle);
        return new_param;
    }

    return raw;
}

std::string reconfig_linux(const RuntimeParam::LinuxParam& raw)
{
    json::object obj { { "screencap_method", raw.screencap },
                       { "input_method", raw.input },
                       { "use_win32_vk_code", raw.use_win32_vk_code } };
    if (raw.screencap == MaaLinuxScreencapMethod_Wlr || raw.input == MaaLinuxInputMethod_Wlr) {
        obj["wlr_socket_path"] = raw.wlr_socket_path;
    }
    if (raw.screencap == MaaLinuxScreencapMethod_PipeWire) {
        if (raw.pipewire_source == "Gamescope") {
            // gamescope 实例的 PipeWire 节点现查; 跳过无截图节点的实例
            auto instance_list = MaaToolkitGamescopeInstanceListCreate();
            OnScopeLeave([&]() { MaaToolkitGamescopeInstanceListDestroy(instance_list); });

            if (!MaaToolkitGamescopeInstanceFindAll(instance_list)) {
                LogError << "Failed to find gamescope instances";
                return "";
            }

            uint32_t pw_node_id = 0;
            for (MaaSize i = 0; i < MaaToolkitGamescopeInstanceListSize(instance_list); ++i) {
                auto instance = MaaToolkitGamescopeInstanceListAt(instance_list, i);
                if (uint32_t node_id = MaaToolkitGamescopeInstanceGetPipeWireNodeId(instance); node_id != 0) {
                    pw_node_id = node_id;
                    break;
                }
            }
            if (pw_node_id == 0) {
                LogError << "No gamescope PipeWire node found";
                return "";
            }
            obj["pw_node_id"] = pw_node_id;
        }
        else {
            // 显示器捕获: 通过 portal 获取 fd + node id
            auto helper_handle = MaaToolkitPortalHelperCreate();
            if (!helper_handle) {
                LogError << "Failed to create portal helper";
                return "";
            }
            if (!MaaToolkitPortalHelperOpenStream(helper_handle)) {
                LogError << "Failed to open stream";
                MaaToolkitPortalHelperDestroy(helper_handle);
                return "";
            }
            obj["pw_socket_fd"] = MaaToolkitPortalHelperGetPipeWireFD(helper_handle);
            obj["pw_node_id"] = MaaToolkitPortalHelperGetPipeWireNodeID(helper_handle);
            MaaToolkitPortalHelperDestroy(helper_handle);
        }
    }
    if (raw.input == MaaLinuxInputMethod_UInput) {
        obj["uinput_screen_width"] = raw.uinput_screen_width;
        obj["uinput_screen_height"] = raw.uinput_screen_height;
    }
    if (raw.input == MaaLinuxInputMethod_Libei) {
        obj["eis_socket_path"] = raw.eis_socket_path;
    }

    return obj.dumps();
}

bool Runner::run(const RuntimeParam& param)
{
    MaaTasker* tasker_handle = MaaTaskerCreate();

    MaaController* controller_handle = nullptr;
    if (const auto* p_adb_param = std::get_if<RuntimeParam::AdbParam>(&param.controller_param)) {
        RuntimeParam::AdbParam adb_param = reconfig_adb(*p_adb_param);
        controller_handle = MaaAdbControllerCreate(
            adb_param.adb_path.c_str(),
            adb_param.address.c_str(),
            adb_param.screencap,
            adb_param.input,
            adb_param.config.c_str(),
            adb_param.agent_path.c_str());
    }
    else if (const auto* p_win32_param = std::get_if<RuntimeParam::Win32Param>(&param.controller_param)) {
        controller_handle =
            MaaWin32ControllerCreate(p_win32_param->hwnd, p_win32_param->screencap, p_win32_param->mouse, p_win32_param->keyboard);
    }
    else if (const auto* p_playcover_param = std::get_if<RuntimeParam::PlayCoverParam>(&param.controller_param)) {
#if defined(__APPLE__)
        controller_handle = MaaPlayCoverControllerCreate(p_playcover_param->address.c_str(), p_playcover_param->uuid.c_str());
#else
        std::ignore = p_playcover_param;
        LogError << "PlayCover controller is only supported on macOS";
        return false;
#endif
    }
    else if (const auto* p_gamepad_param = std::get_if<RuntimeParam::GamepadParam>(&param.controller_param)) {
#if defined(_WIN32)
        controller_handle = MaaGamepadControllerCreate(p_gamepad_param->hwnd, p_gamepad_param->gamepad_type, p_gamepad_param->screencap);
#else
        std::ignore = p_gamepad_param;
        LogError << "Gamepad controller is only supported on Windows";
        return false;
#endif
    }
    else if (const auto* p_macos_param = std::get_if<RuntimeParam::MacOSParam>(&param.controller_param)) {
#if defined(__APPLE__)
        controller_handle = MaaMacOSControllerCreate(p_macos_param->window_id, p_macos_param->screencap, p_macos_param->input);
#else
        std::ignore = p_macos_param;
        LogError << "MacOS controller is only supported on macOS";
        return false;
#endif
    }
    else if (const auto* p_wlroots_param = std::get_if<RuntimeParam::LinuxParam>(&param.controller_param)) {
#if defined(__linux__)
        auto config_json = reconfig_linux(*p_wlroots_param);
        if (config_json.empty()) {
            LogError << "Failed to build Linux controller config";
            return false;
        }
        controller_handle = MaaLinuxControllerCreate(config_json.c_str());
#else
        std::ignore = p_wlroots_param;
        LogError << "WlRoots controller is only supported on Linux";
        return false;
#endif
    }
    else {
        LogError << "Unknown controller type";
        return false;
    }

    MaaResource* resource_handle = MaaResourceCreate();

    OnScopeLeave([&]() {
        MaaTaskerDestroy(tasker_handle);
        MaaResourceDestroy(resource_handle);
        MaaControllerDestroy(controller_handle);
    });

    // 设置分辨率选项
    if (param.display_config.raw) {
        MaaBool raw = true;
        MaaControllerSetOption(controller_handle, MaaCtrlOption_ScreenshotUseRawSize, &raw, sizeof(raw));
    }
    else if (param.display_config.expand.has_value()) {
        int32_t expand[2] = { param.display_config.expand->at(0), param.display_config.expand->at(1) };
        MaaControllerSetOption(controller_handle, MaaCtrlOption_ScreenshotTargetExpand, expand, sizeof(expand));
    }
    else if (param.display_config.long_side.has_value()) {
        int long_side = param.display_config.long_side.value();
        MaaControllerSetOption(controller_handle, MaaCtrlOption_ScreenshotTargetLongSide, &long_side, sizeof(long_side));
    }
    else if (param.display_config.short_side.has_value()) {
        int short_side = param.display_config.short_side.value();
        MaaControllerSetOption(controller_handle, MaaCtrlOption_ScreenshotTargetShortSide, &short_side, sizeof(short_side));
    }
    // 如果都没设置，使用默认值 720
    else {
        int short_side = 720;
        MaaControllerSetOption(controller_handle, MaaCtrlOption_ScreenshotTargetShortSide, &short_side, sizeof(short_side));
    }

    MaaId cid = controller_handle->post_connection();
    MaaId rid = 0;
    for (const auto& path : param.resource_path) {
        rid = resource_handle->post_bundle(path);
    }

    tasker_handle->bind_controller(controller_handle);
    tasker_handle->bind_resource(resource_handle);

    if (MaaStatus_Failed == controller_handle->wait(cid)) {
        LogError << "Failed to connect controller";
        return false;
    }

    if (MaaStatus_Failed == resource_handle->wait(rid)) {
        LogError << "Failed to load resource";
        return false;
    }

    std::vector<MaaAgentClient*> agents;
    std::vector<boost::process::child> agent_children;
    for (const auto& agent_param : param.agent) {
        MaaAgentClient* agent = MaaAgentClientCreateV2(nullptr);
        MaaAgentClientBindResource(agent, resource_handle);
        auto* id_buffer = MaaStringBufferCreate();
        MaaAgentClientIdentifier(agent, id_buffer);
        std::string socket_id = MaaStringBufferGet(id_buffer);
        MaaStringBufferDestroy(id_buffer);

        std::vector<std::string> args = agent_param.child_args;
        args.emplace_back(socket_id);
        auto os_args = conv_args(args);

        // v2.5.0: set PI_* environment variables in current process (child inherits them)
        for (const auto& [key, val] : agent_param.env_vars) {
            boost::this_process::environment()[key] = val;
        }

        LogInfo << "Start Agent" << VAR(agent_param.child_exec) << VAR(os_args) << VAR(agent_param.cwd);
        auto& agent_child = agent_children.emplace_back(agent_param.child_exec, os_args, boost::process::start_dir = agent_param.cwd);
        if (!agent_child.valid()) {
            LogError << "Failed to start agent process" << VAR(agent_param.child_exec) << VAR(args) << VAR(agent_param.cwd);
            return false;
        }

        bool connected = MaaAgentClientConnect(agent);
        if (!connected) {
            LogError << "Failed to connect agent" << VAR(agent_param.child_exec) << VAR(args);
            return false;
        }

        agents.emplace_back(agent);
    }

    MaaId tid = 0;
    for (const auto& task : param.task) {
        tid = tasker_handle->post_task(task.entry, task.pipeline_override);
    }

    tasker_handle->wait(tid);

    for (auto* agent : agents) {
        MaaAgentClientDisconnect(agent);
        MaaAgentClientDestroy(agent);
    }

    return true;
}

MAA_PROJECT_INTERFACE_NS_END
