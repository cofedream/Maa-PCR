#include "MaaFramework/MaaAPI.h"

#include "MaaUtils/Logger.h"

MaaController* MaaAdbControllerCreate(const char*, const char*, MaaAdbScreencapMethod, MaaAdbInputMethod, const char*, const char*)
{
    LogError << "MaaAgentServer Not implement this API, Please use MaaFramework";
    return nullptr;
}

MaaController* MaaWin32ControllerCreate(void*, MaaWin32ScreencapMethod, MaaWin32InputMethod, MaaWin32InputMethod)
{
    LogError << "MaaAgentServer Not implement this API, Please use MaaFramework";
    return nullptr;
}

MaaController* MaaMacOSControllerCreate(uint32_t, MaaMacOSScreencapMethod, MaaMacOSInputMethod)
{
    LogError << "MaaAgentServer Not implement this API, Please use MaaFramework";
    return nullptr;
}

MaaController* MaaAndroidNativeControllerCreate(const char*)
{
    LogError << "MaaAgentServer Not implement this API, Please use MaaFramework";
    return nullptr;
}

MaaController* MaaCustomControllerCreate(MaaCustomControllerCallbacks*, void*)
{
    LogError << "MaaAgentServer Not implement this API, Please use MaaFramework";
    return nullptr;
}

MaaController* MaaDbgControllerCreate(const char*)
{
    LogError << "MaaAgentServer Not implement this API, Please use MaaFramework";
    return nullptr;
}

MaaController* MaaReplayControllerCreate(const char*)
{
    LogError << "MaaAgentServer Not implement this API, Please use MaaFramework";
    return nullptr;
}

MaaController* MaaRecordControllerCreate(MaaController*, const char*)
{
    LogError << "MaaAgentServer Not implement this API, Please use MaaFramework";
    return nullptr;
}

MaaController* MaaGamepadControllerCreate(void*, MaaGamepadType, MaaWin32ScreencapMethod)
{
    LogError << "MaaAgentServer Not implement this API, Please use MaaFramework";
    return nullptr;
}

MaaController* MaaPlayCoverControllerCreate(const char*, const char*)
{
    LogError << "MaaAgentServer Not implement this API, Please use MaaFramework";
    return nullptr;
}

MaaController* MaaWlRootsControllerCreate(const char*, MaaBool)
{
    LogError << "MaaAgentServer Not implement this API, Please use MaaFramework";
    return nullptr;
}

MaaController* MaaKWinControllerCreate(const char*, int, int, MaaBool)
{
    LogError << "MaaAgentServer Not implement this API, Please use MaaFramework";
    return nullptr;
}

MaaController* MaaLinuxControllerCreate(const char*)
{
    LogError << "MaaAgentServer Not implement this API, Please use MaaFramework";
    return nullptr;
}

void MaaControllerDestroy(MaaController*)
{
    LogError << "MaaAgentServer Not implement this API, Please use MaaFramework";
}

MaaResource* MaaResourceCreate()
{
    LogError << "MaaAgentServer Not implement this API, Please use MaaFramework";
    return nullptr;
}

void MaaResourceDestroy(MaaResource*)
{
    LogError << "MaaAgentServer Not implement this API, Please use MaaFramework";
}

MaaTasker* MaaTaskerCreate()
{
    LogError << "MaaAgentServer Not implement this API, Please use MaaFramework";
    return nullptr;
}

void MaaTaskerDestroy(MaaTasker*)
{
    LogError << "MaaAgentServer Not implement this API, Please use MaaFramework";
}

MaaBool MaaGlobalLoadPlugin(const char*)
{
    LogError << "MaaAgentServer Not implement this API, Please use MaaFramework";
    return false;
}
