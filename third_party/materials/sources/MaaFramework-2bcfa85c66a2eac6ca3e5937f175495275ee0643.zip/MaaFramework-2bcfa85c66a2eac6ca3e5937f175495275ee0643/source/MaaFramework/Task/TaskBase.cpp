#include "TaskBase.h"

#include <thread>

#include "Component/ActionHelper.h"
#include "Component/Actuator.h"
#include "Component/Recognizer.h"
#include "Controller/ControllerAgent.h"
#include "Global/OptionMgr.h"
#include "MaaFramework/MaaMsg.h"
#include "MaaUtils/JsonExt.hpp"
#include "MaaUtils/Logger.h"
#include "Resource/ResourceMgr.h"

MAA_TASK_NS_BEGIN

TaskBase::TaskBase(std::string entry, Tasker* tasker, std::shared_ptr<Context> context)
    : tasker_(tasker)
    , entry_(std::move(entry))
    , cur_node_(entry_)
    , context_(context ? std::move(context) : Context::create(task_id_, tasker))
{
}

bool TaskBase::override_pipeline(const json::value& pipeline_override)
{
    return context_ && context_->override_pipeline(pipeline_override);
}

Tasker* TaskBase::tasker() const
{
    return tasker_;
}

MaaTaskId TaskBase::task_id() const
{
    return task_id_;
}

const std::string& TaskBase::entry() const
{
    return entry_;
}

MAA_RES_NS::ResourceMgr* TaskBase::resource()
{
    return tasker_ ? tasker_->resource() : nullptr;
}

MAA_CTRL_NS::ControllerAgent* TaskBase::controller()
{
    return tasker_ ? tasker_->controller() : nullptr;
}

RecoResult TaskBase::run_recognition(
    const cv::Mat& image,
    const PipelineData& data,
    std::optional<std::string> anchor_name,
    std::shared_ptr<MAA_VISION_NS::OCRCache> ocr_cache)
{
    LogFunc << VAR(cur_node_) << VAR(data.name);

    if (!context_) {
        LogError << "context is null";
        return { };
    }

    Recognizer recognizer(tasker_, *context_, image, std::move(ocr_cache));

    json::value cb_detail {
        { "task_id", task_id() },
        { "reco_id", recognizer.get_id() },
        { "name", data.name },
        { "focus", data.focus },
    };
    if (anchor_name) {
        cb_detail["anchor"] = *anchor_name;
    }

    notify(MaaMsg_Node_Recognition_Starting, cb_detail);

    RecoResult result = recognizer.recognize(data.reco_type, data.reco_param, data.name);

    if (data.inverse) {
        LogDebug << "pipeline_data.inverse is true, reverse the result" << VAR(data.name) << VAR(result.box);
        result.box = result.box ? std::nullopt : std::make_optional<cv::Rect>();
    }

    cb_detail["reco_details"] = result;
    notify(result.box ? MaaMsg_Node_Recognition_Succeeded : MaaMsg_Node_Recognition_Failed, cb_detail);

    return result;
}

ActionResult TaskBase::run_action(const RecoResult& reco, const PipelineData& data)
{
    if (!context_) {
        LogError << "context is null";
        return { };
    }

    if (!reco.box) {
        LogError << "reco box is nullopt";
        return { };
    }

    if (!data.enabled) {
        LogDebug << "node disabled" << data.name << VAR(data.enabled);
        return { };
    }

    wait_freezes(data.pre_wait_freezes, *reco.box, data.name, "pre", data.focus);
    sleep(data.pre_delay);

    Actuator actuator(tasker_, *context_);
    json::value cb_detail {
        { "task_id", task_id() },
        { "action_id", actuator.get_id() },
        { "name", reco.name },
        { "focus", data.focus },
    };
    notify(MaaMsg_Node_Action_Starting, cb_detail);

    ActionResult result;

    for (uint i = 0; i < data.repeat; ++i) {
        if (i > 0) {
            wait_freezes(data.repeat_wait_freezes, *reco.box, data.name, "repeat", data.focus);
            sleep(data.repeat_delay);
        }

        if (context_->need_to_stop()) {
            return { };
        }

        result = actuator.run(*reco.box, reco.reco_id, data, entry_);
        LogInfo << "action" << VAR(i) << VAR(data.repeat) << VAR(result);

        if (context_->need_to_stop()) {
            break;
        }
    }

    cb_detail["action_details"] = result;
    notify(result.success ? MaaMsg_Node_Action_Succeeded : MaaMsg_Node_Action_Failed, cb_detail);

    if (!context_->need_to_stop()) {
        wait_freezes(data.post_wait_freezes, *reco.box, data.name, "post", data.focus);
        sleep(data.post_delay);
    }

    return result;
}

cv::Mat TaskBase::screencap()
{
    if (!controller()) {
        LogDebug << "controller not bound, skip screencap";
        return { };
    }

    return controller()->screencap();
}

MaaNodeId TaskBase::generate_node_id()
{
    return ++s_global_node_id;
}

void TaskBase::set_node_detail(MaaNodeId node_id, NodeDetail detail)
{
    if (!tasker_) {
        LogError << "tasker is null";
        return;
    }

    auto& cache = tasker_->runtime_cache();
    cache.set_node_detail(node_id, detail);
    if (!detail.name.empty()) {
        cache.set_latest_node(detail.name, node_id);
    }

    // value_or 的默认值用于 run 到一半调用方手动 clear cache 了的情况
    TaskDetail task_detail =
        cache.get_task_detail(task_id_).value_or(TaskDetail { .task_id = task_id_, .entry = entry_, .status = MaaStatus_Running });
    task_detail.node_ids.emplace_back(node_id);

    set_task_detail(task_detail);
}

void TaskBase::set_task_detail(TaskDetail detail)
{
    if (!tasker_) {
        LogError << "tasker is null";
        return;
    }

    auto& cache = tasker_->runtime_cache();
    cache.set_task_detail(task_id_, detail);
}

void TaskBase::wait_freezes(
    const MAA_RES_NS::WaitFreezesParam& param,
    const cv::Rect& box,
    const std::string& name,
    std::string_view phase,
    const json::value& focus)
{
    ActionHelper helper(context_.get());
    helper.wait_freezes(param, box, { .name = name, .phase = std::string(phase), .focus = focus });
}

void TaskBase::sleep(std::chrono::milliseconds ms) const
{
    LogDebug << ms;

    std::this_thread::sleep_for(ms);
}

bool TaskBase::debug_mode() const
{
    return MAA_GLOBAL_NS::OptionMgr::get_instance().debug_mode();
}

void TaskBase::notify(std::string_view msg, const json::value detail)
{
    if (!tasker_ || !context_) {
        return;
    }

    tasker_->context_notify(context_.get(), msg, detail);
}

MAA_TASK_NS_END
