#pragma once

#include "Base/ForegroundUtils.h"
#include "Common/Conf.h"
#include "MaaControlUnit/ControlUnitAPI.h"
#include "MaaUtils/SafeWindows.hpp"

MAA_CTRL_UNIT_NS_BEGIN

// 发送 WM_ACTIVATE 消息激活窗口（用于后台消息发送方式）
// 让目标窗口认为自己被激活，但不实际改变前台窗口
inline void send_activate_message(HWND hwnd, bool use_post = false)
{
    if (!hwnd) {
        return;
    }
    // WM_ACTIVATE + WA_ACTIVE，lParam 为 0 表示没有前一个窗口
    if (use_post) {
        PostMessageW(hwnd, WM_ACTIVATE, WA_ACTIVE, 0);
    }
    else {
        SendMessageW(hwnd, WM_ACTIVATE, WA_ACTIVE, 0);
    }

    std::this_thread::sleep_for(std::chrono::milliseconds(10));
}

// 检查鼠标左右按键是否被交换
inline bool IsMouseButtonSwapped()
{
    return GetSystemMetrics(SM_SWAPBUTTON) != 0;
}

// 获取兼容鼠标左右按键交换后的鼠标按键映射
inline int GetMappedContact(int original_contact)
{
    if (!IsMouseButtonSwapped()) {
        return original_contact;
    }
    switch (original_contact) {
    case 0:
        return 1;
    case 1:
        return 0;
    default:
        return original_contact;
    }
}

// Contact 到 WM_* 消息的转换结果
struct MouseMessageInfo
{
    UINT message = 0;
    WPARAM w_param = 0;
};

// 将 contact ID 转换为鼠标按下消息
inline bool contact_to_mouse_down_message(int contact, MouseMessageInfo& info)
{
    int mapped_contact = GetMappedContact(contact);
    switch (mapped_contact) {
    case 0:
        info.message = WM_LBUTTONDOWN;
        info.w_param = MK_LBUTTON;
        return true;
    case 1:
        info.message = WM_RBUTTONDOWN;
        info.w_param = MK_RBUTTON;
        return true;
    case 2:
        info.message = WM_MBUTTONDOWN;
        info.w_param = MK_MBUTTON;
        return true;
    case 3:
        info.message = WM_XBUTTONDOWN;
        info.w_param = MAKEWPARAM(MK_XBUTTON1, XBUTTON1);
        return true;
    case 4:
        info.message = WM_XBUTTONDOWN;
        info.w_param = MAKEWPARAM(MK_XBUTTON2, XBUTTON2);
        return true;
    default:
        return false;
    }
}

// 将 contact ID 转换为鼠标移动消息
inline bool contact_to_mouse_move_message(int contact, MouseMessageInfo& info)
{
    int mapped_contact = GetMappedContact(contact);
    switch (mapped_contact) {
    case 0:
        info.message = WM_MOUSEMOVE;
        info.w_param = MK_LBUTTON;
        return true;
    case 1:
        info.message = WM_MOUSEMOVE;
        info.w_param = MK_RBUTTON;
        return true;
    case 2:
        info.message = WM_MOUSEMOVE;
        info.w_param = MK_MBUTTON;
        return true;
    case 3:
        info.message = WM_MOUSEMOVE;
        info.w_param = MK_XBUTTON1;
        return true;
    case 4:
        info.message = WM_MOUSEMOVE;
        info.w_param = MK_XBUTTON2;
        return true;
    default:
        return false;
    }
}

// 将 contact ID 转换为鼠标抬起消息
inline bool contact_to_mouse_up_message(int contact, MouseMessageInfo& info)
{
    int mapped_contact = GetMappedContact(contact);
    switch (mapped_contact) {
    case 0:
        info.message = WM_LBUTTONUP;
        info.w_param = 0;
        return true;
    case 1:
        info.message = WM_RBUTTONUP;
        info.w_param = 0;
        return true;
    case 2:
        info.message = WM_MBUTTONUP;
        info.w_param = 0;
        return true;
    case 3:
        info.message = WM_XBUTTONUP;
        info.w_param = MAKEWPARAM(0, XBUTTON1);
        return true;
    case 4:
        info.message = WM_XBUTTONUP;
        info.w_param = MAKEWPARAM(0, XBUTTON2);
        return true;
    default:
        return false;
    }
}

// MOUSEEVENTF 标志和按钮数据
struct MouseEventFlags
{
    DWORD flags;
    DWORD button_data;
};

// 将 contact ID 转换为 MOUSEEVENTF 按下标志（用于 SendInput/mouse_event）
inline bool contact_to_mouse_down_flags(int contact, MouseEventFlags& flags_info)
{
    switch (contact) {
    case 0:
        flags_info.flags = MOUSEEVENTF_LEFTDOWN;
        flags_info.button_data = 0;
        return true;
    case 1:
        flags_info.flags = MOUSEEVENTF_RIGHTDOWN;
        flags_info.button_data = 0;
        return true;
    case 2:
        flags_info.flags = MOUSEEVENTF_MIDDLEDOWN;
        flags_info.button_data = 0;
        return true;
    case 3:
        flags_info.flags = MOUSEEVENTF_XDOWN;
        flags_info.button_data = XBUTTON1;
        return true;
    case 4:
        flags_info.flags = MOUSEEVENTF_XDOWN;
        flags_info.button_data = XBUTTON2;
        return true;
    default:
        return false;
    }
}

// 将 contact ID 转换为 MOUSEEVENTF 抬起标志（用于 SendInput/mouse_event）
inline bool contact_to_mouse_up_flags(int contact, MouseEventFlags& flags_info)
{
    switch (contact) {
    case 0:
        flags_info.flags = MOUSEEVENTF_LEFTUP;
        flags_info.button_data = 0;
        return true;
    case 1:
        flags_info.flags = MOUSEEVENTF_RIGHTUP;
        flags_info.button_data = 0;
        return true;
    case 2:
        flags_info.flags = MOUSEEVENTF_MIDDLEUP;
        flags_info.button_data = 0;
        return true;
    case 3:
        flags_info.flags = MOUSEEVENTF_XUP;
        flags_info.button_data = XBUTTON1;
        return true;
    case 4:
        flags_info.flags = MOUSEEVENTF_XUP;
        flags_info.button_data = XBUTTON2;
        return true;
    default:
        return false;
    }
}

// 构造 WM_KEYDOWN 的 lParam
inline LPARAM make_keydown_lparam(int key)
{
    UINT sc = MapVirtualKeyW(static_cast<UINT>(key), MAPVK_VK_TO_VSC);
    return 1 | (static_cast<LPARAM>(sc) << 16);
}

// 构造 WM_KEYUP 的 lParam
inline LPARAM make_keyup_lparam(int key)
{
    UINT sc = MapVirtualKeyW(static_cast<UINT>(key), MAPVK_VK_TO_VSC);
    // 置位先前状态与转换状态位
    return (1 | (static_cast<LPARAM>(sc) << 16) | (1 << 30) | (1 << 31));
}

MAA_CTRL_UNIT_NS_END
