#include "PlayCoverControlUnitMgr.h"

#include "MaaUtils/Logger.h"
#include "MaaUtils/NoWarningCV.hpp"

#include "Client/PlayToolsClient.h"

MAA_CTRL_UNIT_NS_BEGIN

PlayCoverControlUnitMgr::PlayCoverControlUnitMgr(std::string address, std::string uuid)
    : client_(std::make_unique<PlayToolsClient>())
    , address_(std::move(address))
    , uuid_(std::move(uuid))
{
    LogFunc << VAR(address_) << VAR(uuid_);
}

PlayCoverControlUnitMgr::~PlayCoverControlUnitMgr()
{
    LogFunc;
}

bool PlayCoverControlUnitMgr::connect()
{
    if (!client_) {
        LogError << "client_ is nullptr";
        return false;
    }

    LogFunc << VAR(address_);
    return client_->connect(address_);
}

bool PlayCoverControlUnitMgr::connected() const
{
    if (!client_) {
        LogError << "client_ is nullptr";
        return false;
    }
    return client_->connected();
}

bool PlayCoverControlUnitMgr::request_uuid(std::string& uuid)
{
    uuid = uuid_;
    return true;
}

MaaControllerFeature PlayCoverControlUnitMgr::get_features() const
{
    return MaaControllerFeature_UseMouseDownAndUpInsteadOfClick;
}

bool PlayCoverControlUnitMgr::start_app(const std::string& intent)
{
    LogWarn << "start_app is not supported on PlayCover" << VAR(intent);
    std::ignore = intent;
    return false;
}

bool PlayCoverControlUnitMgr::stop_app(const std::string& intent)
{
    if (!client_) {
        LogError << "client_ is nullptr";
        return false;
    }

    LogInfo << "stop_app" << VAR(intent);
    std::ignore = intent;
    return client_->terminate();
}

bool PlayCoverControlUnitMgr::screencap(cv::Mat& image)
{
    if (!client_) {
        LogError << "client_ is nullptr";
        return false;
    }

    LogTrace;

    std::vector<uint8_t> buffer;
    int width = 0, height = 0;

    if (!client_->screencap(buffer, width, height)) {
        LogError << "Failed to screencap";
        return false;
    }

    if (buffer.empty() || width <= 0 || height <= 0) {
        LogError << "Invalid screencap data";
        return false;
    }

    cv::Mat rgba(height, width, CV_8UC4, buffer.data());
    cv::cvtColor(rgba, image, cv::COLOR_RGBA2BGR);

    return true;
}

// get_features() 返回 MaaControllerFeature_UseMouseDownAndUpInsteadOfClick，
// 上层 ControllerAgent 会使用 touch_down/touch_up 替代 click/swipe
bool PlayCoverControlUnitMgr::click(int x, int y)
{
    LogError << "deprecated: get_features() returns MaaControllerFeature_UseMouseDownAndUpInsteadOfClick, "
                "use touch_down/touch_up instead"
             << VAR(x) << VAR(y);
    return false;
}

bool PlayCoverControlUnitMgr::swipe(int x1, int y1, int x2, int y2, int duration)
{
    LogError << "deprecated: get_features() returns MaaControllerFeature_UseMouseDownAndUpInsteadOfClick, "
                "use touch_down/touch_move/touch_up instead"
             << VAR(x1) << VAR(y1) << VAR(x2) << VAR(y2) << VAR(duration);
    return false;
}

bool PlayCoverControlUnitMgr::touch_down(int contact, int x, int y, int pressure)
{
    if (!client_) {
        LogError << "client_ is nullptr";
        return false;
    }

    std::ignore = pressure;

    if (!client_->touch(PlayToolsClient::TouchPhase::Began, x, y, contact)) {
        return false;
    }

    last_touch_points_[contact] = { x, y };
    return true;
}

bool PlayCoverControlUnitMgr::touch_move(int contact, int x, int y, int pressure)
{
    if (!client_) {
        LogError << "client_ is nullptr";
        return false;
    }

    std::ignore = pressure;

    if (!client_->touch(PlayToolsClient::TouchPhase::Moved, x, y, contact)) {
        return false;
    }

    last_touch_points_[contact] = { x, y };
    return true;
}

bool PlayCoverControlUnitMgr::touch_up(int contact)
{
    if (!client_) {
        LogError << "client_ is nullptr";
        return false;
    }

    int up_x = 0;
    int up_y = 0;
    const auto it = last_touch_points_.find(contact);
    if (it != last_touch_points_.end()) {
        up_x = it->second.first;
        up_y = it->second.second;
    }
    else {
        auto [width, height] = client_->screen_size();
        up_x = width / 2;
        up_y = height / 2;
    }

    if (!client_->touch(PlayToolsClient::TouchPhase::Ended, up_x, up_y, contact)) {
        return false;
    }

    last_touch_points_.erase(contact);
    return true;
}

bool PlayCoverControlUnitMgr::click_key(int key)
{
    LogWarn << "click_key is not supported on PlayCover" << VAR(key);
    std::ignore = key;
    return false;
}

bool PlayCoverControlUnitMgr::input_text(const std::string& text)
{
    LogWarn << "input_text is not supported on PlayCover" << VAR(text);
    std::ignore = text;
    return false;
}

bool PlayCoverControlUnitMgr::key_down(int key)
{
    LogWarn << "key_down is not supported on PlayCover" << VAR(key);
    std::ignore = key;
    return false;
}

bool PlayCoverControlUnitMgr::key_up(int key)
{
    LogWarn << "key_up is not supported on PlayCover" << VAR(key);
    std::ignore = key;
    return false;
}

bool PlayCoverControlUnitMgr::inactive()
{
    return true;
}

json::object PlayCoverControlUnitMgr::get_info() const
{
    json::object info;
    info["type"] = "playcover";
    info["address"] = address_;
    return info;
}

MAA_CTRL_UNIT_NS_END
