declare global {
    namespace maa {
        type ClickParam = {
            point: Point
            contact: number
        }

        type LongPressParam = {
            point: Point
            duration: number
            contact: number
        }

        type SwipeParam = {
            begin: Point
            end: Point[]
            end_hold: number[]
            duration: number[]
            only_hover: boolean
            starting: number
            contact: number
        }

        type MultiSwipeParam = {
            swipes: SwipeParam[]
        }

        type TouchParam = {
            contact: number
            point: Point
            pressure: number
        }

        type ClickKeyParam = {
            keycode: number[]
        }

        type LongPressKeyParam = {
            keycode: number[]
            duration: number
        }

        type InputTextParam = {
            text: string
        }

        type AppParam = {
            package: string
        }

        type ScrollParam = {
            dx: number
            dy: number
        }

        type RelativeMoveParam = {
            dx: number
            dy: number
        }

        type ActionParam =
            | {}
            | ClickParam
            | LongPressParam
            | SwipeParam
            | MultiSwipeParam
            | TouchParam
            | ClickKeyParam
            | LongPressKeyParam
            | InputTextParam
            | AppParam
            | ScrollParam
            | RelativeMoveParam

        type ControllerNotify = {
            msg: NotifyMessage<'Action'>
            ctrl_id: number // CtrlId
            uuid: string
            info: Record<string, unknown>
        } & (
            | {
                  action: 'connect'
                  param?: never
              }
            | {
                  action: 'click'
                  param: ClickParam
              }
            | {
                  action: 'long_press'
                  param: LongPressParam
              }
            | {
                  action: 'swipe'
                  param: SwipeParam
              }
            | {
                  action: 'multi_swipe'
                  param: MultiSwipeParam
              }
            | {
                  action: 'touch_down' | 'touch_move' | 'touch_up'
                  param: TouchParam
              }
            | {
                  action: 'relative_move'
                  param: RelativeMoveParam
              }
            | {
                  action: 'click_key' | 'key_down' | 'key_up'
                  param: ClickKeyParam
              }
            | {
                  action: 'long_press_key'
                  param: LongPressKeyParam
              }
            | {
                  action: 'input_text'
                  param: InputTextParam
              }
            | {
                  action: 'screencap'
                  param?: never
              }
            | {
                  action: 'inactive'
                  param?: never
              }
            | {
                  action: 'start_app' | 'stop_app'
                  param: AppParam
              }
            | {
                  action: 'scroll'
                  param: ScrollParam
              }
        )

        class ImageJob extends Job<CtrlId, Controller, ImageData | null> {
            constructor(source: Controller, id: CtrlId)
        }

        class Controller {
            constructor(handle?: string)

            destroy(): void
            add_sink(cb: (ctrl: Controller, msg: ControllerNotify) => MaybePromise<void>): SinkId
            remove_sink(id: SinkId): void
            clear_sinks(): void

            set screenshot_target_long_side(value: number)
            set screenshot_target_short_side(value: number)
            set screenshot_target_expand(value: [number, number])
            set screenshot_use_raw_size(value: boolean)
            set screenshot_resize_method(value: number)

            post_connection(): Job<CtrlId, Controller>
            post_click(
                x: number,
                y: number,
                contact?: number,
                pressure?: number,
            ): Job<CtrlId, Controller>
            post_swipe(
                x1: number,
                y1: number,
                x2: number,
                y2: number,
                duration: number,
                contact?: number,
                pressure?: number,
            ): Job<CtrlId, Controller>
            post_click_key(keycode: number): Job<CtrlId, Controller>
            post_input_text(text: string): Job<CtrlId, Controller>
            post_start_app(intent: string): Job<CtrlId, Controller>
            post_stop_app(intent: string): Job<CtrlId, Controller>
            post_touch_down(
                contact: number,
                x: number,
                y: number,
                pressure: number,
            ): Job<CtrlId, Controller>
            post_touch_move(
                contact: number,
                x: number,
                y: number,
                pressure: number,
            ): Job<CtrlId, Controller>
            post_touch_up(contact: number): Job<CtrlId, Controller>
            /**
             * Post a relative move action. Supported by Win32, MacOS, and custom controllers that implement relative_move.
             */
            post_relative_move(dx: number, dy: number): Job<CtrlId, Controller>
            /**
             * Set mouse lock follow mode. For TPS/FPS games that lock the mouse in the background.
             * Only supported by Win32 controllers using message-based input methods.
             * @returns true if successful, false otherwise
             */
            set mouse_lock_follow(enabled: boolean)
            set background_managed_keys(keycodes: number[])
            post_key_down(keycode: number): Job<CtrlId, Controller>
            post_key_up(keycode: number): Job<CtrlId, Controller>
            /**
             * Post a scroll action. Supported by Win32, MacOS, and custom controllers that implement scroll.
             * Using multiples of 120 (WHEEL_DELTA) is recommended for best compatibility.
             */
            post_scroll(dx: number, dy: number): Job<CtrlId, Controller>
            post_inactive(): Job<CtrlId, Controller>
            post_screencap(): ImageJob
            override_pipeline(pipeline: Record<string, unknown> | Record<string, unknown>[]): void
            override_next(node_name: string, next_list: string[]): void
            get_node_data(node_name: string): string | null
            get_node_data_parsed(node_name: string): DumpTask | null
            clear(): void
            status(id: CtrlId): Status
            wait(id: CtrlId): Promise<Status>
            get connected(): boolean
            get cached_image(): ImageData | null
            get uuid(): string | null
            get resolution(): [width: number, height: number] | null
            get info(): string | null
        }

        type AdbDevice = [
            name: string,
            adb_path: string,
            address: string,
            screencap_methods: ScreencapOrInputMethods,
            input_methods: ScreencapOrInputMethods,
            config: string,
        ]

        class AdbController extends Controller {
            constructor(
                adb_path: string,
                address: string,
                screencap_methods: ScreencapOrInputMethods,
                input_methods: ScreencapOrInputMethods,
                config: string,
                agent?: string,
            )

            static agent_path(): string
            static find(adb?: string): Promise<AdbDevice[] | null>
        }

        type DesktopDevice = [handle: DesktopHandle, class_name: string, window_name: string]

        class Win32Controller extends Controller {
            constructor(
                hwnd: DesktopHandle,
                screencap_method: ScreencapOrInputMethods,
                mouse_method: ScreencapOrInputMethods,
                keyboard_method: ScreencapOrInputMethods,
            )

            static find(): Promise<DesktopDevice[] | null>
        }

        class MacOSController extends Controller {
            constructor(
                window_id: number,
                screencap_method: ScreencapOrInputMethods,
                input_method: ScreencapOrInputMethods,
            )

            static find(): Promise<DesktopDevice[] | null>
        }

        class PlayCoverController extends Controller {
            constructor(address: string, uuid: string)
        }

        class DbgController extends Controller {
            constructor(read_path: string)
        }

        class ReplayController extends Controller {
            constructor(recording_path: string)
        }

        /**
         * Proxy controller that wraps an existing controller and records all operations.
         * The recorded file can be replayed using ReplayController.
         */
        class RecordController extends Controller {
            constructor(
                inner: Controller,
                recording_path: string,
            )
        }

        /**
         * Virtual gamepad controller for Windows (requires ViGEm Bus Driver).
         *
         * Control mapping:
         * - click_key/key_down/key_up: Digital buttons (use GamepadButton constants)
         * - touch_down/touch_move/touch_up: Analog sticks and triggers (use GamepadContact constants)
         *   - contact 0: Left stick (x, y: -32768~32767)
         *   - contact 1: Right stick (x, y: -32768~32767)
         *   - contact 2: Left trigger (pressure: 0~255)
         *   - contact 3: Right trigger (pressure: 0~255)
         */
        class GamepadController extends Controller {
            constructor(
                hwnd: DesktopHandle | null, // Window handle for screencap (can be null)
                gamepad_type: Uint64, // GamepadType (Xbox360 or DualShock4)
                screencap_method: ScreencapOrInputMethods,
            )
        }

        type WlRootsCompositor = [handle: DesktopHandle, class_name: string, window_name: string]

        type GamescopeInstance = [
            display_no: number,
            pipewire_node_id: number,
            eis_socket_path: string,
        ]

        /**
         * @deprecated Use LinuxController instead.
         */
        class WlRootsController extends Controller {
            /**
             * @param wlr_socket_path Wayland socket path (e.g. "/run/user/1000/wayland-0")
             * @param use_win32_vk_code When true, key codes passed to click_key / key_down / key_up are
             *   interpreted as Win32 Virtual-Key codes (VK_*) and translated to Linux evdev codes internally.
             *   Defaults to false (raw evdev codes).
             */
            constructor(wlr_socket_path: string, use_win32_vk_code?: boolean)

            static find(): Promise<WlRootsCompositor[] | null>
        }

        /**
         * @deprecated Use LinuxController instead.
         */
        class KWinController extends Controller {
            /**
             * @param device_node uinput device path (e.g. "/dev/uinput")
             * @param screen_width Screen width in pixels
             * @param screen_height Screen height in pixels
             * @param use_win32_vk_code When true, key codes passed to click_key / key_down / key_up are
             *   interpreted as Win32 Virtual-Key codes (VK_*) and translated to Linux evdev codes internally.
             *   Defaults to false (raw evdev codes).
             */
            constructor(
                device_node: string,
                screen_width: number,
                screen_height: number,
                use_win32_vk_code?: boolean,
            )
        }

        /**
         * Linux controller for native Linux applications.
         *
         * Configurable screencap and input methods via JSON config.
         * Supports Wlroots (Wayland), PipeWire / xdg-desktop-portal, and UInput.
         */
        class LinuxController extends Controller {
            /**
             * @param config JSON config for the control unit. Required fields:
             *   - screencap_method: screencap method to use.
             *   - input_method: input method to use.
             *
             *   Wlroots required fields:
             *   - wlr_socket_path: wayland socket path (e.g. "/run/user/1000/wayland-0").
             *
             *   PipeWire monitor capture (via xdg-desktop-portal):
             *   - pw_socket_fd: The PipeWire socket FD (from the ScreenCast portal).
             *   - pw_node_id: The PipeWire Node ID.
             *
             *   PipeWire session-daemon node capture (gamescope etc.):
             *   - pw_node_id: attach to a session-daemon node directly; discover the node
             *     with find_gamescope_instances().
             *
             *   UInput optional fields:
             *   - uinput_path: The uinput device node path, default is "/dev/uinput".
             *   - uinput_screen_width / uinput_screen_height: screen size for the uinput
             *     absolute axis range.
             *
             *   Libei (EIS) required fields:
             *   - eis_socket_path: the EIS socket path, e.g. "/run/user/1000/gamescope-0-ei".
             *
             *   Optional fields:
             *   - use_win32_vk_code: If true, key codes passed to click_key / key_down / key_up are
             *     interpreted as Win32 Virtual-Key codes (VK_*) and translated to Linux evdev codes
             *     internally. If false, key codes are passed through as raw evdev codes.
             */
            constructor(config: string)

            /**
             * Create a PortalHelper for the PipeWire screencap method.
             *
             * Opens a xdg-desktop-portal ScreenCast session and exposes the resulting PipeWire
             * FD and node ID, which can be fed into the LinuxController config
             * (`pw_socket_fd` / `pw_node_id`).
             */
            static create_portal_helper(): PortalHelper

            /**
             * Find running gamescope instances.
             *
             * Scans $XDG_RUNTIME_DIR (falling back to /run/user/<uid>) for
             * `gamescope-<n>` named Wayland sockets; each instance's PipeWire node ID
             * is queried via the gamescope_pipewire protocol, and the EIS socket path
             * is derived as `gamescope-<n>-ei`. Stale sockets that cannot be connected
             * are discarded; a connected instance without PipeWire has node id 0.
             *
             * @returns instances sorted by display number, or null if the query failed
             */
            static find_gamescope_instances(): Promise<GamescopeInstance[] | null>

            static find_wlr_compositor(): Promise<WlRootsCompositor[] | null>
        }

        interface CustomControllerActor {
            connect?(): maa.MaybePromise<boolean>
            // connected?(): maa.MaybePromise<boolean>
            request_uuid?(): maa.MaybePromise<string | null>
            get_features?(): maa.MaybePromise<null | ('mouse' | 'keyboard')[]>
            start_app?(intent: string): maa.MaybePromise<boolean>
            stop_app?(intent: string): maa.MaybePromise<boolean>
            screencap?(): maa.MaybePromise<maa.ImageData | null>
            click?(x: number, y: number): maa.MaybePromise<boolean>
            swipe?(
                x1: number,
                y1: number,
                x2: number,
                y2: number,
                duration: number,
            ): maa.MaybePromise<boolean>
            touch_down?(
                contact: number,
                x: number,
                y: number,
                pressure: number,
            ): maa.MaybePromise<boolean>
            touch_move?(
                contact: number,
                x: number,
                y: number,
                pressure: number,
            ): maa.MaybePromise<boolean>
            touch_up?(contact: number): maa.MaybePromise<boolean>
            click_key?(keycode: number): maa.MaybePromise<boolean>
            input_text?(text: string): maa.MaybePromise<boolean>
            key_down?(keycode: number): maa.MaybePromise<boolean>
            key_up?(keycode: number): maa.MaybePromise<boolean>
            scroll?(dx: number, dy: number): maa.MaybePromise<boolean>
            relative_move?(dx: number, dy: number): maa.MaybePromise<boolean>
            shell?(cmd: string, timeout: number): maa.MaybePromise<string | null>
            inactive?(): maa.MaybePromise<boolean>
            get_info?(): maa.MaybePromise<string | null>
        }

        class CustomController extends Controller {
            constructor(actor: CustomControllerActor)
        }
    }
}

export {}
