#pragma once

#include <map>
#include <optional>
#include <string>
#include <tuple>

#include <MaaFramework/MaaAPI.h>

#include "../foundation/spec.h"
#include "job.h"

struct ImageJobImpl : public JobImpl
{
    virtual maajs::ValueType get() override;

    constexpr static char name[] = "ImageJob";

    static ImageJobImpl* ctor(const maajs::CallbackInfo& info);
    static void init_proto(maajs::ObjectType proto, maajs::FunctionType ctor);
};

struct ControllerImpl : public maajs::NativeClassBase
{
    MaaController* controller { };
    bool own = false;
    std::map<MaaSinkId, maajs::CallbackContext*> sinks { };

    ControllerImpl() = default;
    ControllerImpl(MaaController* ctrl, bool own);
    ~ControllerImpl();
    void destroy();
    MaaSinkId add_sink(maajs::FunctionType sink);
    void remove_sink(MaaSinkId id);
    void clear_sinks();
    void set_screenshot_target_long_side(int32_t value);
    void set_screenshot_target_short_side(int32_t value);
    void set_screenshot_target_expand(std::tuple<int32_t, int32_t> value);
    void set_screenshot_use_raw_size(bool value);
    void set_screenshot_resize_method(int32_t value);
    maajs::ValueType post_connection(maajs::ValueType self, maajs::EnvType env);
    maajs::ValueType post_click(
        maajs::ValueType self,
        maajs::EnvType env,
        int32_t x,
        int32_t y,
        maajs::OptionalParam<int32_t> contact,
        maajs::OptionalParam<int32_t> pressure);
    maajs::ValueType post_swipe(
        maajs::ValueType self,
        maajs::EnvType env,
        int32_t x1,
        int32_t y1,
        int32_t x2,
        int32_t y2,
        int32_t duration,
        maajs::OptionalParam<int32_t> contact,
        maajs::OptionalParam<int32_t> pressure);
    maajs::ValueType post_click_key(maajs::ValueType self, maajs::EnvType env, int32_t keycode);
    maajs::ValueType post_input_text(maajs::ValueType self, maajs::EnvType env, std::string text);
    maajs::ValueType post_start_app(maajs::ValueType self, maajs::EnvType env, std::string intent);
    maajs::ValueType post_stop_app(maajs::ValueType self, maajs::EnvType env, std::string intent);
    maajs::ValueType post_touch_down(maajs::ValueType self, maajs::EnvType env, int32_t contact, int32_t x, int32_t y, int32_t pressure);
    maajs::ValueType post_touch_move(maajs::ValueType self, maajs::EnvType env, int32_t contact, int32_t x, int32_t y, int32_t pressure);
    maajs::ValueType post_touch_up(maajs::ValueType self, maajs::EnvType env, int32_t contact);
    maajs::ValueType post_relative_move(maajs::ValueType self, maajs::EnvType env, int32_t dx, int32_t dy);
    void set_mouse_lock_follow(bool enabled);
    void set_background_managed_keys(std::vector<int32_t> keycodes);
    maajs::ValueType post_key_down(maajs::ValueType self, maajs::EnvType env, int32_t keycode);
    maajs::ValueType post_key_up(maajs::ValueType self, maajs::EnvType env, int32_t keycode);
    maajs::ValueType post_scroll(maajs::ValueType self, maajs::EnvType env, int32_t dx, int32_t dy);
    maajs::ValueType post_inactive(maajs::ValueType self, maajs::EnvType env);
    maajs::ValueType post_screencap(maajs::ValueType self, maajs::EnvType env);
    MaaStatus status(MaaCtrlId id);
    maajs::PromiseType wait(MaaCtrlId id);
    bool get_connected();
    std::optional<maajs::ArrayBufferType> get_cached_image();
    std::optional<std::string> get_uuid();
    std::optional<std::tuple<int32_t, int32_t>> get_resolution();
    std::optional<std::string> get_info();

    std::string to_string() override;

    static maajs::ValueType locate_object(maajs::EnvType env, MaaController* ctrl);

    constexpr static char name[] = "Controller";

    virtual void init_bind(maajs::ObjectType self) override;
    virtual void gc_mark(maajs::NativeMarkerFunc marker) override;
    static ControllerImpl* ctor(const maajs::CallbackInfo&);
    static void init_proto(maajs::ObjectType proto, maajs::FunctionType ctor);
};

using AdbDevice = std::tuple<std::string, std::string, std::string, MaaAdbScreencapMethod, MaaAdbInputMethod, std::string>;
using AdbControllerCtorParam =
    std::tuple<std::string, std::string, MaaAdbScreencapMethod, MaaAdbInputMethod, std::string, maajs::OptionalParam<std::string>>;

struct AdbControllerImpl : public ControllerImpl
{
    using ControllerImpl::ControllerImpl;

    static std::string agent_path();
    static maajs::PromiseType find(maajs::EnvType env, maajs::OptionalParam<std::string> adb);

    constexpr static char name[] = "AdbController";

    static AdbControllerImpl* ctor(const maajs::CallbackInfo&);
    static void init_proto(maajs::ObjectType proto, maajs::FunctionType ctor);
};

using Win32Device = std::tuple<uintptr_t, std::string, std::string>;
using Win32ControllerCtorParam = std::tuple<uintptr_t, MaaWin32ScreencapMethod, MaaWin32InputMethod, MaaWin32InputMethod>;

struct Win32ControllerImpl : public ControllerImpl
{
    using ControllerImpl::ControllerImpl;

    static maajs::PromiseType find(maajs::EnvType env);

    constexpr static char name[] = "Win32Controller";

    static Win32ControllerImpl* ctor(const maajs::CallbackInfo&);
    static void init_proto(maajs::ObjectType proto, maajs::FunctionType ctor);
};

using MacOSDevice = std::tuple<uintptr_t, std::string, std::string>;
using MacOSControllerCtorParam = std::tuple<uint32_t, MaaMacOSScreencapMethod, MaaMacOSInputMethod>;

struct MacOSControllerImpl : public ControllerImpl
{
    using ControllerImpl::ControllerImpl;

    static maajs::PromiseType find(maajs::EnvType env);

    constexpr static char name[] = "MacOSController";

    static MacOSControllerImpl* ctor(const maajs::CallbackInfo&);
    static void init_proto(maajs::ObjectType proto, maajs::FunctionType ctor);
};

using PlayCoverControllerCtorParam = std::tuple<std::string, std::string>;

struct PlayCoverControllerImpl : public ControllerImpl
{
    using ControllerImpl::ControllerImpl;

    constexpr static char name[] = "PlayCoverController";

    static PlayCoverControllerImpl* ctor(const maajs::CallbackInfo&);
    static void init_proto(maajs::ObjectType proto, maajs::FunctionType ctor);
};

using DbgControllerCtorParam = std::tuple<std::string>;

struct DbgControllerImpl : public ControllerImpl
{
    using ControllerImpl::ControllerImpl;

    constexpr static char name[] = "DbgController";

    static DbgControllerImpl* ctor(const maajs::CallbackInfo&);
    static void init_proto(maajs::ObjectType proto, maajs::FunctionType ctor);
};

using ReplayControllerCtorParam = std::tuple<std::string>;

struct ReplayControllerImpl : public ControllerImpl
{
    using ControllerImpl::ControllerImpl;

    constexpr static char name[] = "ReplayController";

    static ReplayControllerImpl* ctor(const maajs::CallbackInfo&);
    static void init_proto(maajs::ObjectType proto, maajs::FunctionType ctor);
};

using RecordControllerCtorParam = std::tuple<maajs::NativeObject<ControllerImpl>, std::string>;

struct RecordControllerImpl : public ControllerImpl
{
    using ControllerImpl::ControllerImpl;

    constexpr static char name[] = "RecordController";

    static RecordControllerImpl* ctor(const maajs::CallbackInfo&);
    static void init_proto(maajs::ObjectType proto, maajs::FunctionType ctor);
};

using GamepadControllerCtorParam = std::tuple<std::optional<uintptr_t>, MaaGamepadType, MaaWin32ScreencapMethod>;

struct GamepadControllerImpl : public ControllerImpl
{
    using ControllerImpl::ControllerImpl;

    constexpr static char name[] = "GamepadController";

    static GamepadControllerImpl* ctor(const maajs::CallbackInfo&);
    static void init_proto(maajs::ObjectType proto, maajs::FunctionType ctor);
};

using WlRootsCompositor = std::tuple<uint64_t, std::string, std::string>;
using WlRootsControllerCtorParam = std::tuple<std::string, maajs::OptionalParam<bool>>;

using GamescopeInstance = std::tuple<uint32_t, uint32_t, std::string>;

struct WlRootsControllerImpl : public ControllerImpl
{
    using ControllerImpl::ControllerImpl;

    static maajs::PromiseType find(maajs::EnvType env);

    constexpr static char name[] = "WlRootsController";

    static WlRootsControllerImpl* ctor(const maajs::CallbackInfo&);
    static void init_proto(maajs::ObjectType proto, maajs::FunctionType ctor);
};

using KWinControllerCtorParam = std::tuple<std::string, int, int, maajs::OptionalParam<bool>>;

struct KWinControllerImpl : public ControllerImpl
{
    using ControllerImpl::ControllerImpl;

    constexpr static char name[] = "KWinController";

    static KWinControllerImpl* ctor(const maajs::CallbackInfo&);
    static void init_proto(maajs::ObjectType proto, maajs::FunctionType ctor);
};

using LinuxControllerCtorParam = std::tuple<std::string>;

struct LinuxControllerImpl : public ControllerImpl
{
    using ControllerImpl::ControllerImpl;

    static maajs::PromiseType find_wlr_compositor(maajs::EnvType env);

    static maajs::PromiseType find_gamescope_instances(maajs::EnvType env);

    static maajs::ValueType create_portal_helper(maajs::EnvType env);

    constexpr static char name[] = "LinuxController";

    static LinuxControllerImpl* ctor(const maajs::CallbackInfo&);
    static void init_proto(maajs::ObjectType proto, maajs::FunctionType ctor);
};

struct CustomControllerContext
{
    std::map<std::string, maajs::CallbackContext*> callbacks;

    ~CustomControllerContext();
    void add_bind(
        maajs::EnvType env,
        std::string name,
        std::string func_name,
        int argc,
        std::shared_ptr<maajs::ObjectRefType> actor,
        std::function<maajs::ValueType(maajs::EnvType)> fallback);
    void gc_mark(maajs::NativeMarkerFunc marker);
};

struct CustomControllerImpl : public ControllerImpl
{
    std::shared_ptr<maajs::ObjectRefType> actor;
    std::unique_ptr<CustomControllerContext> context;

    using ControllerImpl::ControllerImpl;

    constexpr static char name[] = "CustomController";

    virtual void gc_mark(maajs::NativeMarkerFunc marker) override;
    static CustomControllerImpl* ctor(const maajs::CallbackInfo&);
    static void init_proto(maajs::ObjectType proto, maajs::FunctionType ctor);
};
