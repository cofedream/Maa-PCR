#include "AdbDeviceFinder.h"

#include <charconv>
#include <chrono>
#include <cstdint>
#include <filesystem>
#include <memory>
#include <optional>
#include <ranges>
#include <thread>
#include <unordered_set>

#include "LibraryHolder/ControlUnit.h"
#include "MaaControlUnit/ControlUnitAPI.h"
#include "MaaUtils/IOStream/BoostIO.hpp"
#include "MaaUtils/IOStream/ChildPipeIOStream.h"
#include "MaaUtils/Logger.h"
#include "MaaUtils/StringMisc.hpp"

MAA_TOOLKIT_NS_BEGIN

namespace
{
void append_unique_devices(
    std::vector<AdbDevice>& result,
    std::unordered_set<std::string>& accurate_serials,
    std::vector<AdbDevice> devices)
{
    for (auto& dev : devices) {
        if (!accurate_serials.emplace(dev.serial).second) {
            continue;
        }
        result.emplace_back(std::move(dev));
    }
}

std::optional<boost::asio::ip::tcp::endpoint> parse_tcp_endpoint(const std::string& serial)
{
    std::string_view view(serial);
    auto colon = view.rfind(':');
    if (colon == std::string_view::npos) {
        return std::nullopt; // emulator-5554 之类的名字没有端口可探测，交给 adb 自行判断
    }

    boost::system::error_code ec;
    auto address = boost::asio::ip::make_address(view.substr(0, colon), ec);
    if (ec) {
        return std::nullopt; // 不认识的地址形式不做拦截
    }

    auto port_view = view.substr(colon + 1);
    int port = 0;
    auto [ptr, port_ec] = std::from_chars(port_view.data(), port_view.data() + port_view.size(), port);
    if (port_ec != std::errc { } || ptr != port_view.data() + port_view.size() || port <= 0 || port > 65535) {
        return std::nullopt;
    }

    return boost::asio::ip::tcp::endpoint(address, static_cast<std::uint16_t>(port));
}

// 端口没人监听时 adb connect 要等到自己的超时（Connection::connect_remote() 给的是 60s），
// 枚举阶段先用一次 TCP 可达性筛选。拒绝和丢包都可能被防火墙/VPN 拖慢，所以所有候选串口并行探测、
// 共用同一个预算，单个串口不会各自吃掉一份超时。
std::vector<std::string> filter_reachable_serials(const std::vector<std::string>& serials)
{
    constexpr auto kProbeBudget = std::chrono::milliseconds(500);

    boost::asio::io_context context;
    std::vector<std::unique_ptr<boost::asio::ip::tcp::socket>> sockets;
    std::vector<bool> reachable(serials.size(), true);

    for (size_t i = 0; i < serials.size(); ++i) {
        auto endpoint = parse_tcp_endpoint(serials[i]);
        if (!endpoint) {
            continue;
        }

        reachable[i] = false;
        sockets.emplace_back(std::make_unique<boost::asio::ip::tcp::socket>(context));
        sockets.back()->async_connect(*endpoint, [&reachable, i](const boost::system::error_code& connect_ec) {
            reachable[i] = !connect_ec;
        });
    }

    if (!sockets.empty()) {
        context.run_for(kProbeBudget);
    }

    std::vector<std::string> result;
    for (size_t i = 0; i < serials.size(); ++i) {
        if (reachable[i]) {
            result.emplace_back(serials[i]);
        }
        else {
            LogInfo << "skip unreachable common serial" << VAR(serials[i]);
        }
    }
    return result;
}

// 探测只能证明端口有人接 TCP，接的人是不是 adb 只有 adb 自己知道；被中间设备接管或 adbd 半死时
// adb connect 会卡到 Connection::connect_remote() 的 60s 上限，枚举阶段用短超时直接放弃这个串口。
bool try_adb_connect(const std::filesystem::path& adb_path, const std::string& serial)
{
    using namespace std::chrono_literals;
    constexpr auto kConnectTimeout = 3s;
    constexpr auto kPollInterval = 20ms;
    // adb connect 的退出码无论成败都是 0，只能看输出，成功时是 "connected to" / "already connected to"
    constexpr std::string_view kConnectedFlag = "connected to";

    ChildPipeIOStream ios(adb_path, { "connect", serial });

    auto deadline = std::chrono::steady_clock::now() + kConnectTimeout;
    while (ios.running() && std::chrono::steady_clock::now() < deadline) {
        std::this_thread::sleep_for(kPollInterval);
    }

    if (ios.running()) {
        LogWarn << "adb connect timeout" << VAR(adb_path) << VAR(serial);
        return false;
    }

    auto output = ios.read();
    LogDebug << VAR(adb_path) << VAR(serial) << VAR(output);

    return output.find(kConnectedFlag) != std::string::npos;
}

// 同一设备的串号常有多种写法：adb devices 注册的是 emulator-5554，常量表和手动 connect 常用
// 127.0.0.1:5555 / localhost:5555。把已知别名归一成同一个键，用于判断"候选串口是否已被枚举结果覆盖"；
// 只在 find_by_common_serials 的候选过滤里使用，返回给上层的 serial 保持原样，
// MaaPiCli / 通用 GUI 按原始串号保存设备身份的行为不受影响。
std::string canonical_serial(const std::string& serial)
{
    std::string_view view(serial);

    // 模拟器 console N / adb N+1 的固定约定（AVD 表内两种写法并存即来源于此）
    constexpr std::string_view kEmulatorPrefix = "emulator-";
    if (view.starts_with(kEmulatorPrefix)) {
        std::string_view num = view.substr(kEmulatorPrefix.size());
        int port = 0;
        auto [ptr, ec] = std::from_chars(num.data(), num.data() + num.size(), port);
        if (ec == std::errc { } && ptr == num.data() + num.size() && port > 0 && port < 65535) {
            return std::format("127.0.0.1:{}", port + 1);
        }
        return serial;
    }

    auto colon = view.rfind(':');
    if (colon == std::string_view::npos) {
        return serial;
    }

    std::string host(view.substr(0, colon));
    tolowers_(host);
    if (host == "localhost" || host == "::1" || host == "[::1]") {
        host = "127.0.0.1";
    }
    return std::format("{}:{}", host, view.substr(colon + 1));
}
} // namespace

std::vector<AdbDevice> AdbDeviceFinder::find() const
{
    LogFunc;

    std::vector<AdbDevice> result;
    std::unordered_set<std::string> accurate_serials;

    auto all_emulators = find_emulators();
    for (const Emulator& e : all_emulators) {
        auto res = find_by_emulator_tool(e);
        bool found = !res.empty();
        append_unique_devices(result, accurate_serials, std::move(res));
        if (found) {
            continue;
        }

        if (e.adb_path.empty() || !std::filesystem::exists(e.adb_path)) {
            LogWarn << "adb_path is empty or does not exist" << VAR(e.adb_path);
            continue;
        }

        append_unique_devices(result, accurate_serials, find_specified(e.adb_path, accurate_serials, e));
        append_unique_devices(result, accurate_serials, find_by_common_serials(e.adb_path, accurate_serials, e));
    }

#if MAAUTILS_HAS_BOOST_PROCESS
    if (auto env_adb = boost::process::search_path("adb"); std::filesystem::exists(env_adb)) {
        append_unique_devices(result, accurate_serials, find_specified(env_adb, accurate_serials));
    }
#endif

    LogInfo << VAR(result);
    return result;
}

std::vector<AdbDevice> AdbDeviceFinder::find_specified(
    const std::filesystem::path& adb_path,
    const std::unordered_set<std::string>& exclude_serials,
    const Emulator& emulator) const
{
    LogFunc << VAR(adb_path);

    std::vector<AdbDevice> result;

    auto serials = find_serials_by_adb_command(adb_path);

    for (const std::string& ser : serials) {
        if (exclude_serials.count(ser)) {
            LogInfo << "skip excluded serial" << VAR(ser);
            continue;
        }
        auto res_opt = try_device(adb_path, ser, emulator);
        if (!res_opt) {
            continue;
        }
        result.emplace_back(std::move(*res_opt));
    }

    LogInfo << VAR(result);
    return result;
}

std::vector<AdbDevice> AdbDeviceFinder::find_by_common_serials(
    const std::filesystem::path& adb_path,
    const std::unordered_set<std::string>& exclude_serials,
    const Emulator& emulator) const
{
    LogFunc << VAR(adb_path) << VAR(emulator.common_serials);

    std::vector<AdbDevice> result;

    // 已枚举到的串号按规范化键排除：adb devices 列出的是 emulator-5554、常量表写的是 127.0.0.1:5555 时，
    // 两者是同一设备，不能再 connect 一次在结果里多出一条别名。规范化副本只在函数内使用，
    // accurate_serials 与返回给上层的 serial 仍保持原始写法。
    std::unordered_set<std::string> exclude_canonical;
    exclude_canonical.reserve(exclude_serials.size());
    for (const std::string& ser : exclude_serials) {
        exclude_canonical.emplace(canonical_serial(ser));
    }

    std::vector<std::string> candidates;
    for (const std::string& ser : emulator.common_serials) {
        if (exclude_canonical.count(canonical_serial(ser))) {
            LogInfo << "skip excluded serial" << VAR(ser);
            continue;
        }
        candidates.emplace_back(ser);
    }

    // adb server 与模拟器之间的 TCP 会话可能已断开（模拟器进程与端口仍在），此时 adb devices 不会列出设备，
    // 需要按已知端口重新 connect 一次。
    for (const std::string& ser : filter_reachable_serials(candidates)) {
        // adb connect 只对 ip:port 形式有意义，emulator-5554 这类名字交给 try_device 自行判断
        if (ser.find(':') != std::string::npos && !try_adb_connect(adb_path, ser)) {
            continue;
        }

        auto res_opt = try_device(adb_path, ser, emulator);
        if (!res_opt) {
            continue;
        }
        result.emplace_back(std::move(*res_opt));
    }

    LogInfo << VAR(result);
    return result;
}

std::vector<std::string> AdbDeviceFinder::find_serials_by_adb_command(const std::filesystem::path& adb_path) const
{
    LogFunc << VAR(adb_path);

    std::string str_adb = path_to_utf8_string(adb_path);

    auto control_unit =
        AdbControlUnitLibraryHolder::create_control_unit(str_adb.c_str(), "", MaaAdbScreencapMethod_None, MaaAdbInputMethod_None, "{}", "");

    if (!control_unit) {
        LogError << "Failed to create control unit";
        return { };
    }

    std::vector<std::string> devices;
    auto found = control_unit->find_device(devices);

    LogDebug << VAR(devices);

    if (!found) {
        LogError << "Failed to find_device";
        return { };
    }

    return devices;
}

bool request_waydroid_config(std::shared_ptr<MAA_CTRL_UNIT_NS::AdbControlUnitAPI> control_unit, AdbDevice& device)
{
    if (!control_unit) {
        return false;
    }

    std::string output;
    bool ret = control_unit->shell("getprop | grep ro.product.brand", output);
    if (!ret) {
        return false;
    }

    string_trim_(output);
    tolowers_(output);

    if (output.find("waydroid") == std::string::npos) {
        return false;
    }

    auto& command = device.config["command"];

    command["StartApp"] = json::array {
        "{ADB}", "-s", "{ADB_SERIAL}", "shell", "monkey -p {INTENT} --pct-syskeys 0 1",
    };
    command["StartActivity"] = json::array {
        "{ADB}", "-s", "{ADB_SERIAL}", "shell", "am start -n {INTENT} --windowingMode 4",
    };

    LogInfo << "waydroid" << VAR(device);
    return true;
}

bool request_androws_config(std::shared_ptr<MAA_CTRL_UNIT_NS::AdbControlUnitAPI> control_unit, AdbDevice& device)
{
    if (!control_unit) {
        return false;
    }

    // Detect via Tencent-specific property; non-empty means this is an Androws device
    std::string output;
    bool ret = control_unit->shell("getprop sys.tencent.imei", output);
    if (!ret) {
        return false;
    }

    if (output.find_first_not_of(" \t\n\r\f\v") == std::string::npos) {
        return false;
    }

    // Just mark the device; AndrowsExtras will dynamically resolve the correct
    // display ID at runtime using the app package name.
    device.config["extras"]["androws"]["enable"] = true;
    device.screencap_methods = MaaAdbScreencapMethod_EmulatorExtras;
    device.input_methods = MaaAdbInputMethod_EmulatorExtras;

    LogInfo << "Androws detected" << VAR(device);
    return true;
}

bool request_avd_config(std::shared_ptr<MAA_CTRL_UNIT_NS::AdbControlUnitAPI> control_unit, AdbDevice& device)
{
    if (!control_unit) {
        return false;
    }

    if (!device.serial.starts_with("emulator-")) {
        return false;
    }

    std::string output;
    if (!control_unit->shell("getprop ro.product.model", output)) {
        return false;
    }

    string_trim_(output);
    tolowers_(output);

    if (!output.starts_with("android sdk") && !output.starts_with("sdk_")) {
        return false;
    }

    device.config["extras"]["avd"]["enable"] = true;

    LogInfo << "AVDExtras enabled for" << VAR(device);
    return true;
}

bool request_vivo_orientation_config(std::shared_ptr<MAA_CTRL_UNIT_NS::AdbControlUnitAPI> control_unit, AdbDevice& device)
{
    if (!control_unit) {
        return false;
    }

    std::string brand;
    if (!control_unit->shell("getprop ro.product.brand", brand)) {
        return false;
    }

    string_trim_(brand);
    tolowers_(brand);

    std::string manufacturer;
    if (control_unit->shell("getprop ro.product.manufacturer", manufacturer)) {
        string_trim_(manufacturer);
        tolowers_(manufacturer);
    }

    std::string model;
    if (control_unit->shell("getprop ro.product.model", model)) {
        string_trim_(model);
        tolowers_(model);
    }

    const bool is_vivo_device = brand.find("vivo") != std::string::npos || manufacturer.find("vivo") != std::string::npos
                                || model.find("vivo") != std::string::npos || model.find("iqoo") != std::string::npos;

    if (!is_vivo_device) {
        return false;
    }

    // If SurfaceOrientation (Android 12-) or InputDeviceOrientation (Android 13+) exists,
    // the default Orientation command should still work.
    // In this case, do not override the default command to minimize the impact scope.
    std::string input_device_orientation;
    if (control_unit->shell("dumpsys input | grep -m 1 -e SurfaceOrientation -e InputDeviceOrientation", input_device_orientation)) {
        string_trim_(input_device_orientation);
        if (!input_device_orientation.empty()) {
            return false;
        }
    }

    // Some vivo / iQOO devices have neither field in dumpsys input,
    // but Viewport INTERNAL contains orientation=0/1/2/3.
    std::string viewport;
    if (!control_unit->shell("dumpsys input | grep -m 1 'Viewport INTERNAL'", viewport)) {
        return false;
    }

    if (viewport.find("orientation=") == std::string::npos) {
        return false;
    }

    auto& command = device.config["command"];

    command["Orientation"] = json::array {
        "{ADB}",
        "-s",
        "{ADB_SERIAL}",
        "shell",
        "dumpsys input | sed -n 's/.*Viewport INTERNAL.*orientation=\\([0-3]\\).*/\\1/p' | tail -n 1",
    };

    LogInfo << "vivo orientation config enabled" << VAR(device);
    return true;
}

std::optional<AdbDevice>
    AdbDeviceFinder::try_device(const std::filesystem::path& adb_path, const std::string& serial, const Emulator& emulator) const
{
    LogFunc << VAR(adb_path) << VAR(serial);

    std::string str_adb = path_to_utf8_string(adb_path);

    auto control_unit = AdbControlUnitLibraryHolder::create_control_unit(
        str_adb.c_str(),
        serial.c_str(),
        MaaAdbScreencapMethod_None,
        MaaAdbInputMethod_None,
        "{}",
        "");

    if (!control_unit) {
        LogError << "Failed to create control unit";
        return std::nullopt;
    }
    if (!control_unit->connect()) {
        LogError << "Failed to connect" << VAR(serial);
        return std::nullopt;
    }

    AdbDevice device;
    device.name = std::format("{}-{}", serial, emulator.name.empty() ? path_to_utf8_string(adb_path) : emulator.name);
    device.adb_path = adb_path;
    device.serial = serial;
    device.screencap_methods = MaaAdbScreencapMethod_Default;
    device.input_methods = MaaAdbInputMethod_Default;
    device.config = { };

    if (request_waydroid_config(control_unit, device)) {
    }
    else if (request_androws_config(control_unit, device)) {
    }
    else if (request_avd_config(control_unit, device)) {
    }
    else if (request_vivo_orientation_config(control_unit, device)) {
    }
    // else if (request_xxx_config(control_unit, device)) {
    // }
    else {
    }

    return device;
}

std::vector<AdbDeviceFinder::Emulator> AdbDeviceFinder::find_emulators() const
{
    LogFunc;

    std::vector<Emulator> result;
    std::unordered_set<std::filesystem::path> seen_adb_paths;

    auto all_processes = list_processes();

    const auto& emu_constant = get_emulator_const_data();

    for (const auto& process : all_processes) {
        auto find_it = std::ranges::find_if(emu_constant, [&process](const auto& pair) -> bool {
            return process.name.find(pair.second.keyword) != std::string::npos;
        });
        if (find_it == emu_constant.cend()) {
            continue;
        }

        auto process_path = get_process_path(process.pid);
        if (!process_path) {
            continue;
        }

        auto adb_path = get_emulator_adb_path(find_it->second, process.pid);

        if (adb_path.empty()) {
            LogWarn << "adb_path is empty or does not exist" << VAR(adb_path);
            continue;
        }

        // Deduplicate by adb_path to distinguish multiple instances or installations
        if (!seen_adb_paths.insert(adb_path).second) {
            continue;
        }

        Emulator emulator {
            .name = find_it->first,
            .process_path = *process_path,
            .adb_path = adb_path,
            .common_serials = find_it->second.adb_common_serials,
        };
        result.emplace_back(std::move(emulator));
    }

    // Platform-specific fallback discovery (e.g. registry lookup for elevated-process emulators like Androws).
    // Merged here so downstream logic in find() treats them uniformly. Deduplicated by adb_path against
    // process-enumerated entries to avoid connecting to the same adb server twice.
    for (auto& extra : find_extra_emulators()) {
        if (extra.adb_path.empty() || !std::filesystem::exists(extra.adb_path)) {
            LogWarn << "extra emulator has invalid adb_path" << VAR(extra);
            continue;
        }
        if (!seen_adb_paths.insert(extra.adb_path).second) {
            continue;
        }
        result.emplace_back(std::move(extra));
    }

    LogInfo << VAR(result);

    return result;
}

std::filesystem::path AdbDeviceFinder::get_emulator_adb_path(const EmulatorConstantData& emulator, os_pid pid) const
{
    auto path_opt = get_process_path(pid);
    if (!path_opt) {
        return { };
    }
    auto dir = path_opt->parent_path();

    for (const auto& adb_rel_path : emulator.adb_candidate_paths) {
        auto adb_path = dir / adb_rel_path;
        if (!std::filesystem::exists(adb_path)) {
            continue;
        }
        return std::filesystem::canonical(adb_path);
    }
    return { };
}

MAA_TOOLKIT_NS_END
