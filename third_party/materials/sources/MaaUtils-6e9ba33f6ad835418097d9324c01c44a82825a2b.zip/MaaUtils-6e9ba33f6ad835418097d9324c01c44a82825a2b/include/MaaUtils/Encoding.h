#pragma once

#include <optional>
#include <string>
#include <string_view>

#include <boost/regex.hpp>

#include "MaaUtils/Conf.h"
#include "MaaUtils/Port.h"

MAA_NS_BEGIN

MAA_UTILS_API std::wstring to_u16(std::string_view u8str);
MAA_UTILS_API std::string from_u16(std::wstring_view u16str);

MAA_UTILS_API std::optional<boost::wregex> regex_valid(const std::wstring& regex);

MAA_NS_END
