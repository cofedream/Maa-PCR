include(FetchContent)

# 本地源码覆盖不执行下载；关闭下载时仍允许使用调用方指定的现有源码。
find_package(pugixml 1.16 QUIET CONFIG)
if(NOT TARGET pugixml::pugixml)
    if(NOT XDB_FETCH_DEPENDENCIES AND NOT FETCHCONTENT_SOURCE_DIR_PUGIXML)
        message(FATAL_ERROR "需要 pugixml >= 1.16；请安装或启用 XDB_FETCH_DEPENDENCIES")
    endif()
    set(PUGIXML_BUILD_TESTS OFF CACHE BOOL "" FORCE)
    FetchContent_Declare(pugixml
        URL https://codeload.github.com/zeux/pugixml/tar.gz/refs/tags/v1.16
        URL_HASH SHA256=357bcab8877dc9943f355d3a72daba1b053238ba955f50fa81586afb65090219)
    FetchContent_MakeAvailable(pugixml)
endif()

# mdns 是单头文件库。这里只取源码，跳过上游 CMake 中的示例程序和安装规则。
# 核心库私有使用该头文件，公共设备发现接口不暴露其类型。
if(NOT XDB_FETCH_DEPENDENCIES AND NOT FETCHCONTENT_SOURCE_DIR_MDNS)
    message(FATAL_ERROR
        "离线构建需要 FETCHCONTENT_SOURCE_DIR_MDNS 指向 mdns 1.4.3 源码，"
        "或启用 XDB_FETCH_DEPENDENCIES 下载固定版本")
endif()
FetchContent_Declare(mdns
    URL https://codeload.github.com/mjansson/mdns/tar.gz/refs/tags/1.4.3
    URL_HASH SHA256=be1fd8e35599cb7de179decbd0633c121d11a2dcb9cc193ff5c590bd0d480483
    SOURCE_SUBDIR xdb-header-only)
FetchContent_MakeAvailable(mdns)
if(NOT EXISTS "${mdns_SOURCE_DIR}/mdns.h")
    message(FATAL_ERROR "mdns 源码中缺少 mdns.h：${mdns_SOURCE_DIR}")
endif()
add_library(XdbMdns INTERFACE)
target_include_directories(XdbMdns SYSTEM INTERFACE "${mdns_SOURCE_DIR}")
add_library(Xdb::Mdns ALIAS XdbMdns)
