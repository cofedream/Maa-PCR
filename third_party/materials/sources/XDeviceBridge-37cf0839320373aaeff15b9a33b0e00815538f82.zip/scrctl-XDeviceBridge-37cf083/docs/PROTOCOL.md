# xdb local protocol (version 1)

English | [简体中文](PROTOCOL_zh.md)

This is the **client-to-host-server protocol**, not Apple's device protocol.
The server listens only on IPv4 loopback and accepts local clients without
authentication. Loopback limits direct network access; it does not authenticate
client processes or operating-system users. Any local process able to connect can
invoke device control, clipboard access and server shutdown. Phone pairing and
device authentication are handled separately by the server and do not authorize
individual local clients.

## Version and upgrade policy

The package version, C ABI (1) and wire protocol (1) are separate contracts.
The protocol number in the frame header and `hello.params.protocol` must both be 1.
A package version mismatch alone is not a reason to kill or replace a server.

XDB 1.0 establishes the documented C ABI 1 and wire protocol 1 baseline.
The compatibility commitments apply to published releases, not unreleased development snapshots.

Within protocol 1:

- New optional request fields must preserve the old behavior when omitted.
- Clients must ignore unknown result fields; servers may add result fields/events.
  Event consumers must tolerate names they do not use. Required fields and existing
  error codes keep their documented meanings; error messages are diagnostic text.
- New methods may be added. A client must handle `unknown_method`/operation failure
  instead of assuming the method exists because a package version looks new enough.
- Removing a method/field, changing its type/units/default meaning or media body layout
  requires a new protocol number. This includes ownership/lifetime changes.
- Rejected handshakes close the connection and never trigger automatic replacement
  of a listener. Use the executable that owns the old service to stop it, then start
  the desired version. The SDK never kills an occupied/incompatible port automatically.

The C SDK owns opaque handles and response buffers as documented in `xdb.h`.
Existing exported entry points keep their signatures within the published ABI;
new entry points are additive and consumers must check optional symbols. Protocol
compatibility does not imply an Apple device supports a requested feature.

Incompatible C ABI changes require a new ABI major and shared-library SOVERSION;
incompatible wire changes require a new protocol number and migration notes. Users
should ship a tested client/server combination, and keep older packages available
for rollback. Pairing data is retained during installation; any future incompatible
on-disk migration must preserve the prior records or offer an explicit export path.

## Framing

Each message is a 16-byte header followed by UTF-8 JSON and optional raw binary:

| Offset | Size | Meaning |
| --- | --- | --- |
| 0 | 4 | ASCII `XDB1` |
| 4 | 4 | Version `1`, unsigned big endian |
| 8 | 4 | JSON bytes, unsigned big endian, 1..1 MiB |
| 12 | 4 | Binary bytes, unsigned big endian, 0..64 MiB |

Reads must tolerate TCP fragmentation and coalescing. JSON nesting is limited to
64 levels. Bad framing closes the connection before allocating oversized payloads.
Client requests currently carry no binary body. Never search for newlines to delimit messages.

## Handshake and calls

The first request must be:

```json
{"id":1,"method":"hello","params":{"protocol":1}}
```

Protocol version or hello method failure closes the connection. The library performs this handshake.
Then send one request at a time, with a unique unsigned integer `id` and object `params`:

```json
{"id":2,"method":"server.info","params":{}}
```

Responses use `{"id":2,"ok":true,"result":{...}}` or
`{"id":2,"ok":false,"error":{"code":"...","message":"..."}}`.
During a request, zero or more messages of the form
`{"id":2,"event":"progress","data":{...}}` may precede its response.
Pairing PIN events use `event: "pin"`, `data: {"pin":"123456"}` and must not be logged.
The server does not send credentials in responses, events or discovery results.

Closing a client socket cancels pairing/DDI where supported and detaches its
session; other attachments may keep that session alive. A manually connected
base tunnel survives client-session cleanup. Cancelled or failed operations may
have already changed device state.
The client can interrupt its socket from another thread; wait for request completion
before destroying that client. Event callbacks cannot reenter or destroy their client.

## Methods

Complete field/default/result/error/state references are in [API.md](API.md);
C symbol ownership/threading/reference is in [C_API.md](C_API.md). The table below
is a quick summary rather than the full method contract.

| Method | Parameters | Result / binary |
| --- | --- | --- |
| `server.info` | none | Protocol, server version and process ID |
| `server.stop` | none | Requests shutdown after replying; all sessions are cancelled |
| `devices` | `transport`: auto/usb/wifi; `timeout_ms`: 0..60000 | Devices, candidates, warnings |
| `mdns.check` / `mdns.services` | optional `timeout_ms`: 1..60000 | Discovery backend, availability, warnings; services also lists raw service endpoints |
| `connect` | `address`, optional `port`, `udid`, `timeout_ms` | Authenticated Server-owned Wi-Fi base connection; no discovery required |
| `disconnect` | optional `address`, `port`, `udid` | Closes matching manual connections and invalidates attached sessions; preserves records/DDI |
| `pair` | `transport`: wifi/usb; optional `udid`; `timeout_ms`: 1..300000 | UDID and reused status; progress/PIN events |
| `ddi.download` | `os_version`, optional `product_type`, `cache_directory`, `timeout_seconds` | Build/cache metadata; progress events |
| `ddi.prepare` | `udid`, optional `wifi`, `port`, `cache_directory`, `replace`, download/install timeout seconds | Prepared status; progress events |
| `ddi.status` | `udid`, optional `wifi`, `port` | Mount state and evidence; independent installed DDI Cryptex metadata |
| `ddi.remove` | `udid`, optional `wifi`, `port` | Verified absent state and whether this request removed the DDI |
| `connection.open` | `udid`, optional `wifi`, `port`, `access`: control/read | Control session or parallel read association; capability-negotiated |
| `connection.close` | none | Releases services, inputs and device lease |
| `device.info` | none | Device UDID, OS version, model |
| `screenshot` | optional `format`: png/bgra (default png) | PNG body or decoded BGRA pixels, with display geometry |
| `video.start` | optional `hardware_decode`, `max_fps`, `max_bitrate` | Starts background latest-frame capture |
| `video.frame` | `since`: frame serial, `timeout_ms`: 0..1000 | Format BGRA, serial, width, height, row pitch, optional display geometry; raw pixels |
| `video.stop` | none | Stops the video pump |
| `input.tap` | `x`, `y`: 0..1; `hold_ms`: 0..2000 | Report delivery status |
| `input.touch` | `x`, `y`: 0..1; `down`: bool; optional integer `contact`: 0..4, default 0 | Specified contact/release report delivery status |
| `input.keyboard` | `usages`: USB HID keyboard usages, each <240 | Replaces the held keyboard usage set; `[]` releases |
| `input.button` | `page` (default 12), `usage`, `down` | Hardware consumer-key down/up |
| `input.text` | `text`: US-keyboard ASCII/tab/newline, <=4096 bytes; `timeout_ms`: 1..300000 (default 30000) | Unsupported text is rejected in full |
| `app.list` | none | Bundle identifiers and names |
| `app.launch` | `bundle_id`, optional `terminate_existing` | Request status |
| `app.stop` | `bundle_id` | Request status |

Except management methods, operations require a device session. A disconnected socket cannot resume itself; a new socket can attach only while
another attachment keeps the session alive. Use one long-lived library client
or `rpc-shell` for a multi-operation session.

### Manual Wi-Fi connections

`connect` / `disconnect` are available since 1.2 without changing protocol 1;
check `server.info.capabilities.manual_connections`. `connect` requires a usable
local record and keeps the authenticated tunnel in Server. It does not pair or
prepare DDI. An explicit IP needs no mDNS. Without UDID, exactly one usable local
record must exist. The default device RemotePairing port is 49152, distinct from
the local Server port selected by CLI `--port`.

Device sessions reuse manual connections; closing the last attachment releases
media/input services and preserves the idle tunnel. Default control access
remains exclusive. `devices` merges manual connections and
discovery by UDID; manual connections remain connected without an advertisement
and include `manual_connection:{address,port}`. `disconnect` without selectors
closes all manual connections; an endpoint and UDID together must both match.
Transport loss or Server shutdown closes them too, with no automatic reconnect
or persisted endpoint. Idle TCP keepalive/actual I/O detects loss; detection time
depends on the OS. Close stale sessions before explicit connect/open; old
attachments are invalid. Disconnect manual connections before pairing or DDI management.

### Parallel read associations (since 1.3)

When `server.info.capabilities.read_only_sessions` is true, `connection.open` may
set `access:"read"`. Readers share the device and may read an existing video pump;
they do not start another video stream. Read attachments inherit restrictions and
cannot inject input, configure media, consume audio or perform global management
mutations. Closing the last controller stops media and invalidates its control
capability, while readers may still capture screenshots. A later controller may
acquire an unowned session. Older Servers may ignore unknown access fields, so
check the capability. CLI screenshots negotiate it, retaining legacy behavior on
older Servers. See the complete API contract.

Shared control is separately negotiated with `shared_control_sessions` and
`connection.open.access:"shared"`. Independent groups share one video producer,
release only their own inputs on departure, and retain video until the last group
leaves. Matching stream parameters are required; explicit media shutdown and
recording remain exclusive. Audio has one consuming group. See API.md for details.

## Geometry and media ownership

`devices` adds per-device `state` (`discovered`, `paired`, `connected`), `pairing`
(`record_present` or `unknown`) and `connection` (`connected` or `unverified`).
Connected means an active authenticated server session, not a fresh liveness
probe or a promise that every device service works. Candidate `pairing` preserves
the discovery reason (`record_present`, `incomplete_record`, `identifier_hint`,
`ambiguous`, `invalid_advertisement`, `crypto_error`, `unknown`). The existing
candidate `paired` boolean still only describes a complete matching local record.
No active connection or pairing is performed by this listing request.

Desktop servers share one process-local native discovery subscription (Bonjour,
optional Avahi, or Windows DNS-SD). A warm snapshot returns without waiting out
`timeout_ms`; cold/empty snapshots can wait within that budget. Updates/removals
come from system callbacks; the server does not periodically restart discovery.
The cache contains advertisements only, and each request matches current pairing
records independently. Last-server shutdown releases it; provider failure clears
it and permits request-driven reconnection/direct-mDNS fallback. Android retains
the embedding App's NSD lease model. No cache is persisted to disk.

CLI-only selection allows omitting `-s` for `screenshot` / `ddi prepare` /
`ddi status` / `ddi remove` when exactly one identified device is found. SDK DDI
methods require an explicit nonempty UDID.

`ddi.status` queries mount evidence and the DDI Cryptex installation independently,
without downloading or installing. `cryptex_installed:null` means that service is
not advertised; queried installation failures return errors. `ddi.remove` reverses
preparation: uninstall the reported DDI Cryptex at its live version, or otherwise
unmount the Classic/Personalized image. Verifies absence; already absent is
success. Preserves host caches, pairing records and unrelated Cryptexes; does not
request a nonce roll.
Both methods need an exclusive lease; close active sessions first. Empty `wifi`
uses USB, `wifi:"auto"` uses paired Wi-Fi discovery. A reported OS category is not
the installed image's identity. Errors or cancellation can follow a device-side
change; query status before retrying an uncertain removal.

Idle image-mounter connections send a best-effort `Hangup` before teardown or
reconnect. Cleanup waits at most one second, honors cancellation and does not
replace the completed operation's result. Failed transports and incomplete raw
uploads close directly without an additional protocol command.

Touch coordinates refer to the device's panel axes, not a rotated/cropped client
window. BGRA frame dimensions can include codec padding. `display` metadata comes
from the device display subscription and contains width, height, orientation and
geometry serial. Clients must account for crop/rotation when mapping visible pixels
to panel coordinates; absent metadata must not be invented.

A response owns its pixels until `xdb_response_destroy`. There is no FFmpeg,
OpenCV, C++ object or GPU handle in the C ABI. Future encoded media negotiation
must be explicit; the current implementation does not send HEVC/AAC payloads.

## Consumer sessions and additional methods

`connection.open` accepts `transport` (`auto`, `usb`, `wifi`) and returns a random,
connection-private `attachment` capability. A client may call
`connection.attach` with it on another socket, allowing audio/video polling and
control to proceed independently. Keep this capability private. The device session and
lease live until all clients close; media ownership lasts only while a control
client or control attachment remains. `connection.close`
only detaches the requesting client; it does not invalidate another attachment.

- `display.info`: subscribes to display updates and returns panel geometry.
- `display.rotate`: queries the current cardinal orientation, requests the opposite
  portrait/landscape orientation once, and verifies the returned state. It does not
  unlock the device's orientation policy or retry an uncertain mutation.
- `clipboard.set` / `clipboard.get`: explicit clipboard access (`text`, <=256 KiB
  on write). This is not automatic text-input fallback.
- `recording.configure`: before media starts, provide an absolute server-host `path`,
  `format` (`mp4`/`mkv`), `video`, `audio`, `orientation`, and optionally
  `orientation_from_device`. The file is written by the server. Container media
  remains encoded; it is not reconstructed from the IPC image/audio bodies.
- `video.start`: also accepts `decode` (default true), `record_path` (raw HEVC,
  absolute server path) and `restart_on_silence` (default true). Encoded-only capture
  must become ready with a checked recording IDR before this call succeeds.
- `video.start.max_fps`: integer 0..240, default 0/unlimited, negotiated through
  `capabilities.video_max_fps`. Bounds BGRA conversion/copy and publication, not
  device encoding, reference decoding or recording. Can be changed while running;
  shared groups use the highest request (unlimited wins), released on group exit.
  Startup/recovery frames bypass the cap. `media.status.video_max_fps` reports the
  effective cap and `video_rate_limited` counts skipped pixel publications.
- `video.start.max_bitrate`: uint64 bit/s, 0/omitted keeps device defaults for a new
  producer; advertised by `capabilities.video_max_bitrate`. Sent without a
  device-specific clamp. The first producer's request wins; later differing
  requests reuse it with `warnings` and a Server log. Omission reuses silently.
  Start returns `max_bitrate` and `negotiated_max_bitrate` (device `TXMaxBitrate`
  or null); status exposes `video_max_bitrate`/`video_negotiated_max_bitrate`.
- `video.frame`: `allow_cached` permits reuse of a healthy latest frame after its
  wait expires. Geometry is captured with the published frame, not read later.
- `screenshot`: `format: "bgra"` requests server-side PNG decoding; the default
  remains PNG. Both include geometry; a changing display fails the capture.
- `audio.start`: `decode`, `duplicate`, `buffer_ms` (0..1000); returns sample rate,
  channels and preroll frames. `audio.read` requests 1..48000 interleaved frames,
  returning raw **signed 16-bit little-endian** PCM and its actual frame count.
  Poll on a dedicated attached socket; never make a network call in a sound callback.
- `audio.stop`: stops audio only. `media.finish`: joins producers, finalizes
  recordings, then stops device audio. Errors propagate to the caller.
- `media.status`: terminal `error` and `video_unusable` (for screenshot fallback).
- `network.debug`: `enabled` controls server-side tunnel diagnostics.

`devices` includes `capabilities.video_decode`; clients should derive Stream
availability from the server, not their local libraries. In the C API, port 0
uses `XDB_PORT` or 17423. Desktop connections start a missing server automatically;
Android connections require an App-owned embedded server.
`xdb_client_start_server` explicitly ensures a server is running, while
`xdb_client_kill_server` stops an existing server without starting one.
`include/xdb/client.hpp` is an optional header-only C++ adapter; the
binary boundary remains the C API. GUI clients can use that API directly for
`pair` / `ddi.prepare`; device credentials never leave the server.

`media.status.recording_error` reports a recording failure separately from the
transport/media `error`, so decoded mirroring may continue. `media.finish` still
returns the recording failure. The server holds the requested audio startup
preroll; clients should keep only a small output queue instead of buffering that
duration again.

## Idle connection limits

A hello must complete within five seconds. After hello, a connection without a
device session or in-flight operation expires after 60 idle seconds; when the
16-worker pool is full, such idle clients can be reclaimed immediately. A partial
request does not reserve a slot. Connections owning/attached to a device session
and requests already executing are not evicted by this policy. Stalled frame
chunks have a five-second receive timeout. Clients whose idle socket was closed
must reconnect before another request.

### Multiple touch contacts (Server 1.4.0+)

For `input.touch`, `down: true` presses or moves the specified `contact`; `down: false` lifts only that contact. Server sends a complete HID snapshot of all active contacts and releases them during session cleanup. Omitting `contact` preserves the original single-contact calls.

Multi-contact callers must check for Server 1.4.0 or later: older Servers may ignore the unknown `contact` parameter. No new capability flag, C ABI or RPC protocol number is introduced. A shared control group owns the whole touch gesture until all contacts lift; separate windows do not combine their contacts into one gesture.
