// SPDX-License-Identifier: LGPL-3.0-only
#include "ipc/Json.h"
#include "ipc/Endpoint.h"
#include "cli/Help.h"
#include "util/DataDirectory.h"
#include "ipc/Wire.h"
#include "xdb/xdb.h"
#include <algorithm>
#include <atomic>
#include <chrono>
#include <csignal>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <memory>
#include <optional>
#include <set>
#include <thread>
using Json = nlohmann::json;
namespace {
static_assert(std::atomic<int>::is_always_lock_free);
std::atomic<int> stopping{0};
void stop(int) { stopping = 1; }
const char *env(const char *name) {
    auto *value = std::getenv(name);
    return value ? value : "";
}
void event(const char *message, void *) {
    auto value = xdb::ipc::parse_json(message);
    auto data = value.value("data", Json::object());
    if (value.value("event", std::string()) == "pin")
        std::cerr << "Pairing code: " << data.value("pin", std::string()) << '\n';
    else if (data.contains("message"))
        std::cerr << data["message"].get<std::string>() << '\n';
    else
        std::cerr << data.dump() << '\n';
}
int number(const std::string &value, int minimum, int maximum) {
    size_t used = 0;
    auto n = std::stoll(value, &used);
    if (used != value.size() || n < minimum || n > maximum)
        throw std::invalid_argument("Numeric option out of range");
    return int(n);
}

std::string endpoint_label(const Json &candidate) {
    auto label = candidate["transport"].get<std::string>();
    auto address = candidate["address"].get<std::string>();
    if (!address.empty()) {
        if (address.find(':') != std::string::npos)
            address = "[" + address + "]";
        label += " " + address + ":" + std::to_string(candidate["port"].get<int>());
    }
    return label;
}

void print_devices(const Json &result, bool detailed) {
    std::cout << "List of iOS devices\n";
    for (const auto &device : result["devices"]) {
        auto udid = device.value("udid", std::string());
        std::cout << (udid.empty() ? "(unidentified)" : udid) << "\t"
                  << device.value("state", std::string("discovered"));
        if (detailed) {
            auto name = device.value("name", std::string());
            if (!name.empty()) std::cout << "  name:" << name;
        }
        std::cout << '\n';
        if (!detailed) continue;

        const auto pairing = device.value("pairing", std::string("unknown"));
        size_t width = 0;
        for (const auto &candidate : device["candidates"])
            width = std::max(width, endpoint_label(candidate).size());
        for (const auto &candidate : device["candidates"]) {
            auto label = endpoint_label(candidate);
            auto interface_name = candidate.value("interface", std::string());
            auto type = candidate.value("connection_type", std::string());
            auto candidate_pairing = candidate.value("pairing", std::string("unknown"));
            const bool unchecked_usb = candidate.value("transport", std::string()) == "usb" &&
                                       candidate_pairing == "unknown";
            const bool show_pairing = !unchecked_usb && !candidate_pairing.empty() &&
                                      candidate_pairing != pairing;
            std::cout << "  " << label;
            if (!interface_name.empty() || !type.empty() || show_pairing)
                std::cout << std::string(width - label.size(), ' ');
            if (!type.empty()) std::cout << "  type:" << type;
            if (!interface_name.empty()) std::cout << "  interface:" << interface_name;
            if (show_pairing) std::cout << "  pairing:" << candidate_pairing;
            std::cout << '\n';
        }
    }
    for (const auto &warning : result["warnings"])
        std::cerr << "warning: " << warning.get<std::string>() << '\n';
}

struct SelectionError : std::invalid_argument {
    bool ambiguous;
    SelectionError(std::string message, bool multiple)
        : std::invalid_argument(std::move(message)), ambiguous(multiple) {}
};

const Json &select_device(const Json &devices, const std::string &serial,
                          bool prefer_manual, const std::string &wifi_address) {
    std::set<std::string> identifiers, manual;
    bool unidentified = false;
    for (const auto &device : devices) {
        auto id = device.value("udid", std::string());
        if (!serial.empty() && id != serial) continue;
        if (!wifi_address.empty() && wifi_address != "auto") {
            bool matches = false;
            for (const auto &candidate : device["candidates"])
                matches |= candidate.value("transport", std::string()) == "wifi" &&
                           candidate.value("address", std::string()) == wifi_address;
            if (!matches) continue;
        }
        if (id.empty())
            unidentified = true;
        else {
            identifiers.insert(id);
            if (prefer_manual && device.contains("manual_connection") &&
                device.value("state", std::string()) == "connected") manual.insert(id);
        }
    }
    if (!manual.empty()) {
        identifiers = std::move(manual);
        unidentified = false;
    }
    if (identifiers.empty()) {
        if (!serial.empty()) throw SelectionError("Device not found: " + serial, false);
        throw SelectionError(unidentified ? "Discovered device has no known UDID; pair it first"
                                         : "No device found", false);
    }
    if (identifiers.size() > 1 || unidentified) {
        std::string message = "Multiple devices; select one with -s UDID:";
        for (const auto &id : identifiers) message += " " + id;
        if (unidentified) message += " (also unidentified devices)";
        throw SelectionError(message, true);
    }
    return *std::find_if(devices.begin(), devices.end(), [&](const auto &device) {
        return device.value("udid", std::string()) == *identifiers.begin();
    });
}
} // namespace
int main(int argc, char **argv) {
    try {
        if (argc < 2) {
            xdb::cli::print_help({});
            return 0;
        }
        uint16_t port = 17423;
        std::string dir, output, serial, wifi_address, cache;
        std::optional<std::string> display_brand;
        bool wifi = false, usb = false, replace = false, json_output = false, long_output = false;
        bool show_help = false, show_version = false, explicit_port = false, explicit_serial = false;
        int timeout = -1;
        std::vector<std::string> args;
        for (int i = 1; i < argc; ++i) {
            std::string a = argv[i];
            if (a == "--help" || a == "-h")
                show_help = true;
            else if (a == "--version")
                show_version = true;
            else if (a == "-e") {
                wifi = true;
                if (wifi_address.empty()) wifi_address = "auto";
            } else if (a == "--wifi") {
                wifi = true;
                wifi_address = "auto";
                if (i + 1 < argc) {
                    std::string next = argv[i + 1];
                    if (next == "auto" || next.find('.') != std::string::npos ||
                        next.find(':') != std::string::npos) {
                        wifi_address = next;
                        ++i;
                    }
                }
            } else if (a == "--usb" || a == "-d")
                usb = true;
            else if (a == "--replace")
                replace = true;
            else if (a == "--json")
                json_output = true;
            else if (a == "-l") {
                long_output = true;
            } else if (a == "--port" || a == "--data-dir" || a == "--output" || a == "-s" ||
                       a == "--serial" || a == "--timeout" || a == "--cache-dir" || a == "--display-brand") {
                if (++i == argc)
                    throw std::invalid_argument("Missing value for " + a);
                if (a == "--port") {
                    port = uint16_t(number(argv[i], 0, 65535));
                    explicit_port = true;
                } else if (a == "--data-dir")
                    dir = argv[i];
                else if (a == "--output")
                    output = argv[i];
                else if (a == "-s" || a == "--serial") {
                    serial = argv[i];
                    explicit_serial = true;
                } else if (a == "--timeout")
                    timeout = number(argv[i], 0, 300000);
                else if (a == "--display-brand")
                    display_brand = argv[i];
                else
                    cache = argv[i];
            } else if (a.starts_with('-'))
                throw std::invalid_argument("Unknown option: " + a);
            else
                args.push_back(a);
        }
        if (!args.empty() && args[0] == "help") {
            args.erase(args.begin());
            show_help = true;
        }
        if (show_version || (!show_help && args.size() == 1 && args[0] == "version")) {
            xdb::cli::print_version();
            return 0;
        }
        if (show_help || (args.size() == 1 && (args[0] == "ddi" || args[0] == "mdns"))) {
            xdb::cli::print_help(args);
            return 0;
        }
        if (!explicit_port && *env("XDB_PORT"))
            port = uint16_t(number(env("XDB_PORT"), 1, 65535));
        if (!explicit_serial)
            serial = env("XDB_SERIAL");
        if (wifi && usb)
            throw std::invalid_argument("Choose -d/--usb or -e/--wifi");
        if (args.empty())
            throw std::invalid_argument("Missing command");
        if (display_brand && args[0] != "pair")
            throw std::invalid_argument("--display-brand is only available for pair");
        if (args[0] == "server") {
            if (args.size() != 1)
                throw std::invalid_argument("Unexpected server argument");
            if (dir.empty())
                dir = xdb::util::default_data_directory();
            auto *server = xdb_server_start(port, dir.c_str());
            if (!server) {
                std::cerr << xdb_server_last_error() << '\n';
                return 1;
            }
            std::unique_ptr<xdb_server, decltype(&xdb_server_stop)> owned(server, xdb_server_stop);
            std::signal(SIGINT, stop);
            std::signal(SIGTERM, stop);
            std::cout << Json{{"ready", true},
                              {"protocol", xdb::ipc::protocol_version},
                              {"host", "127.0.0.1"},
                              {"port", xdb_server_port(server)}}
                             .dump()
                      << std::endl;
            while (!stopping && xdb_server_is_running(server))
                std::this_thread::sleep_for(std::chrono::milliseconds(50));
            return 0;
        }
        if (args[0] == "start-server" || args[0] == "kill-server") {
            if (args.size() != 1 || !port)
                throw std::invalid_argument("Server lifecycle commands require a fixed port and no extra arguments");
            auto ok = args[0] == "start-server"
                          ? xdb_client_start_server(port, dir.empty() ? nullptr : dir.c_str())
                          : xdb_client_kill_server(port);
            if (!ok)
                std::cerr << xdb_last_error() << '\n';
            return ok ? 0 : 1;
        }
        if (args[0] != "devices" && args[0] != "pair" && args[0] != "ddi" && args[0] != "screenshot" &&
            args[0] != "rpc" && args[0] != "rpc-shell" && args[0] != "connect" && args[0] != "disconnect" &&
            args[0] != "get-state" && args[0] != "get-serialno" && args[0] != "wait-for-device" && args[0] != "mdns")
            throw std::invalid_argument("Unknown command; run xdb --help");
        const bool query_device = args[0] == "get-state" || args[0] == "get-serialno";
        if ((query_device || args[0] == "wait-for-device") && args.size() != 1)
            throw std::invalid_argument("Unexpected argument for " + args[0]);
        std::optional<xdb::ipc::Endpoint> endpoint;
        if (args[0] == "connect" || args[0] == "disconnect") {
            if (args.size() > 2 || (args[0] == "connect" && args.size() != 2))
                throw std::invalid_argument("Expected connect HOST[:PORT] or disconnect [HOST[:PORT]]");
            if (wifi || usb || replace || !cache.empty())
                throw std::invalid_argument("connect/disconnect use an explicit Wi-Fi endpoint, without --wifi/--usb");
            if (args.size() == 2) endpoint = xdb::ipc::parse_endpoint(args[1]);
            if (timeout == 0 || (args[0] == "disconnect" && timeout >= 0))
                throw std::invalid_argument("--timeout applies only to connect and must be positive");
        }
        if (args[0] == "ddi") {
            if (args.size() != 2 ||
                (args[1] != "prepare" && args[1] != "status" && args[1] != "remove"))
                throw std::invalid_argument("Expected ddi prepare/status/remove; run xdb ddi --help");
            if (args[1] != "prepare" && (replace || !cache.empty()))
                throw std::invalid_argument("--replace and --cache-dir apply only to ddi prepare");
        }
        if (args[0] == "mdns" && (args.size() != 2 || (args[1] != "check" && args[1] != "services")))
            throw std::invalid_argument("Expected mdns check/services; run xdb mdns --help");
        if (args[0] == "mdns" && (timeout == 0 || timeout > 60000))
            throw std::invalid_argument("mDNS diagnostic timeout must be 1..60000 ms");
        if (!dir.empty() && !xdb_client_start_server(port, dir.c_str())) {
            std::cerr << xdb_last_error() << '\n';
            return 1;
        }
        std::unique_ptr<xdb_client, decltype(&xdb_client_destroy)> client(
            xdb_client_connect(port, event, nullptr), xdb_client_destroy);
        if (!client) {
            std::cerr << xdb_last_error() << '\n';
            return 1;
        }
        auto request = [&](const std::string &method, const Json &params, bool display = true, bool quiet = false) {
            auto text = params.dump();
            xdb_response *raw = nullptr;
            if (!xdb_client_request(client.get(), method.c_str(), text.c_str(), &raw))
                throw std::runtime_error(xdb_last_error());
            std::unique_ptr<xdb_response, decltype(&xdb_response_destroy)> response(raw,
                                                                                    xdb_response_destroy);
            auto value = xdb::ipc::parse_json(xdb_response_json(raw));
            if (!value.value("ok", false)) {
                if (display && json_output)
                    std::cout << value.dump() << '\n';
                else if (!quiet)
                    std::cerr << value["error"].value("message", std::string("Request failed")) << '\n';
                return value;
            }
            if (xdb_response_size(raw)) {
                if (output.empty())
                    throw std::invalid_argument("Binary response requires --output FILE");
                std::ofstream file(std::filesystem::u8path(output), std::ios::binary);
                file.write(reinterpret_cast<const char *>(xdb_response_data(raw)), xdb_response_size(raw));
                if (!file)
                    throw std::runtime_error("Failed to write binary output");
            }
            if (display) {
                if (json_output || args[0] == "rpc" || args[0] == "rpc-shell")
                    std::cout << value.dump() << std::endl;
                else if (method == "devices")
                    print_devices(value["result"], long_output);
                else if (method == "pair")
                    std::cout << "Paired: " << value["result"].value("udid", std::string()) << '\n';
                else if (method == "connect") {
                    const auto &result = value["result"];
                    const xdb::ipc::Endpoint connected{result.at("address").get<std::string>(), result.at("port").get<uint16_t>()};
                    std::cout << (result.value("reused", false) ? "Already connected to " : "Connected to ")
                              << connected.label() << " (" << result.at("udid").get<std::string>() << ")\n";
                } else if (method == "disconnect") {
                    const auto &disconnected = value["result"].at("disconnected");
                    if (disconnected.empty()) std::cout << "No matching manual connection\n";
                    for (const auto &item : disconnected) {
                        const xdb::ipc::Endpoint closed{item.at("address").get<std::string>(), item.at("port").get<uint16_t>()};
                        std::cout << "Disconnected " << closed.label() << " (" << item.at("udid").get<std::string>() << ")\n";
                    }
                } else if (method == "ddi.status") {
                    const auto &state = value["result"];
                    if (state.at("mounted").get<bool>())
                        std::cout << "DDI mounted: " << state.at("image_type").get<std::string>()
                                  << " (" << state.at("udid").get<std::string>() << ")\n";
                    else
                        std::cout << "DDI not mounted: " << state.at("udid").get<std::string>() << '\n';
                    const auto installed = state.value("cryptex_installed", Json(nullptr));
                    if (installed == true)
                        std::cout << "DDI Cryptex installed: " << state.at("cryptex_identifier").get<std::string>()
                                  << " " << state.at("cryptex_version").get<std::string>() << '\n';
                    else
                        std::cout << "DDI Cryptex: " << (installed.is_null() ? "unavailable" : "not installed")
                                  << '\n';
                } else if (method == "ddi.remove")
                    std::cout << (value["result"].at("changed").get<bool>() ? "DDI removed: "
                                                                          : "DDI already absent: ")
                              << value["result"].at("udid").get<std::string>() << '\n';
                else
                    std::cout << "OK\n";
            }
            return value;
        };
        if (args[0] == "mdns") {
            const auto info = request("server.info", Json::object(), false);
            if (!info.value("ok", false) || !info.value("result", Json::object())
                    .value("capabilities", Json::object()).value("mdns_diagnostics", false))
                throw std::runtime_error("This server does not support mDNS diagnostics; upgrade xdb Server");
            Json params = Json::object();
            if (timeout >= 0) params["timeout_ms"] = timeout;
            const auto reply = request("mdns." + args[1], params, json_output);
            if (!reply.value("ok", false)) return 1;
            const auto &result = reply["result"];
            if (!json_output) {
                std::cout << "mDNS backend: " << result.at("backend").get<std::string>()
                          << (result.at("available").get<bool>() ? " (available)\n" : " (unavailable)\n");
                if (args[1] == "services") {
                    std::cout << "List of " << result.at("service_type").get<std::string>() << " services\n";
                    for (const auto &service : result.at("services")) {
                        std::cout << service.at("instance").get<std::string>() << '\n';
                        for (const auto &ep : service.at("endpoints")) {
                            xdb::ipc::Endpoint endpoint{ep.at("address").get<std::string>(), ep.at("port").get<uint16_t>()};
                            std::cout << "  " << endpoint.label() << "  interface:"
                                      << ep.at("interface").get<std::string>() << '\n';
                        }
                    }
                }
                for (const auto &warning : result.at("warnings"))
                    std::cerr << "warning: " << warning.get<std::string>() << '\n';
            }
            if (result.value("cancelled", false)) return 130;
            return result.at("available").get<bool>() ? 0 : 1;
        }
        if (args[0] == "wait-for-device") {
            // Only this command owns signal handling and interrupts its own RPC socket.
            std::signal(SIGINT, stop);
            std::signal(SIGTERM, stop);
            const auto deadline = timeout > 0
                ? std::chrono::steady_clock::now() + std::chrono::milliseconds(timeout)
                : std::chrono::steady_clock::time_point::max();
            std::atomic<bool> expired{false};
            std::jthread interrupt([&](std::stop_token token) {
                while (!token.stop_requested()) {
                    if (stopping || std::chrono::steady_clock::now() >= deadline) {
                        expired = !stopping;
                        xdb_client_interrupt(client.get());
                        return;
                    }
                    std::this_thread::sleep_for(std::chrono::milliseconds(20));
                }
            });
            std::string last_error;
            try {
                const auto info = request("server.info", Json::object(), false, true);
                if (!info.value("ok", false) || !info.value("result", Json::object())
                        .value("capabilities", Json::object()).value("read_only_sessions", false))
                    throw std::runtime_error("wait-for-device requires a Server with read-only sessions; upgrade xdb Server");
                while (!stopping && !expired) {
                    try {
                        auto selected = serial;
                        if (selected.empty()) {
                            auto found = request("devices", {{"transport", usb ? "usb" : wifi ? "wifi" : "auto"},
                                                             {"timeout_ms", 250}}, false, true);
                            if (!found.value("ok", false))
                                throw std::runtime_error(found["error"].value("message", std::string("Discovery failed")));
                            if (found["result"].value("cancelled", false))
                                throw std::runtime_error("Device discovery was cancelled");
                            selected = select_device(found["result"]["devices"], "", !usb,
                                                     wifi ? wifi_address : "").at("udid").get<std::string>();
                        }
                        Json params = {{"udid", selected}, {"access", "read"},
                                       {"transport", usb ? "usb" : wifi ? "wifi" : "auto"}};
                        if (wifi) params["wifi"] = wifi_address;
                        auto opened = request("connection.open", params, false, true);
                        if (opened.value("ok", false)) {
                            if (!request("connection.close", Json::object(), false, true).value("ok", false))
                                throw std::runtime_error("Failed to close wait-for-device probe");
                            if (stopping || expired) break;
                            if (json_output) {
                                opened["result"] = {{"udid", selected}, {"state", "connected"}};
                                std::cout << opened.dump() << '\n';
                            }
                            return 0;
                        }
                        last_error = opened["error"].value("message", std::string("Connection failed"));
                    } catch (const SelectionError &e) {
                        if (e.ambiguous) throw;
                        last_error = e.what();
                    }
                    const auto retry = std::chrono::steady_clock::now() + std::chrono::milliseconds(250);
                    while (!stopping && !expired && std::chrono::steady_clock::now() < retry)
                        std::this_thread::sleep_for(std::chrono::milliseconds(20));
                }
            } catch (const std::exception &e) {
                if (!stopping && !expired) throw;
            }
            const auto message = stopping ? std::string("Wait cancelled")
                : "Timed out waiting for a connectable device" + (last_error.empty() ? "" : ": " + last_error);
            if (json_output)
                std::cout << Json{{"ok", false}, {"error", {{"code", stopping ? "cancelled" : "timeout"},
                                                           {"message", message}}}}.dump() << '\n';
            else std::cerr << message << '\n';
            return stopping ? 130 : 124;
        }
        if (args[0] == "rpc-shell") {
            std::string line;
            while (std::getline(std::cin, line)) {
                if (line.empty())
                    continue;
                std::string method;
                Json params;
                try {
                    auto v = xdb::ipc::parse_json(line);
                    method = v.at("method").get<std::string>();
                    params = v.value("params", Json::object());
                    if (method.empty() || !params.is_object())
                        throw std::invalid_argument("Expected a non-empty method string and an object params");
                } catch (const Json::exception &e) {
                    std::cerr << "xdb rpc-shell: " << e.what() << '\n';
                    continue;
                } catch (const std::invalid_argument &e) {
                    std::cerr << "xdb rpc-shell: " << e.what() << '\n';
                    continue;
                }
                request(method, params);
            }
            return 0;
        }
        if (args[0] == "rpc") {
            if (args.size() < 2 || args.size() > 3)
                throw std::invalid_argument("rpc requires METHOD [JSON_PARAMS]");
            return request(args[1], args.size() == 3 ? xdb::ipc::parse_json(args[2]) : Json::object())
                           .value("ok", false)
                       ? 0
                       : 1;
        }
        Json params = Json::object();
        if (!serial.empty())
            params["udid"] = serial;
        if (args[0] == "connect" || args[0] == "disconnect") {
            const auto info = request("server.info", Json::object(), false);
            if (!info.value("ok", false) ||
                !info.value("result", Json::object()).value("capabilities", Json::object())
                     .value("manual_connections", false))
                throw std::runtime_error("This server does not support connect/disconnect; upgrade xdb Server");
            if (endpoint) {
                params["address"] = endpoint->address;
                params["port"] = endpoint->port;
            }
            if (timeout >= 0) params["timeout_ms"] = timeout;
            return request(args[0], params).value("ok", false) ? 0 : 1;
        }
        if (args[0] == "devices" || args[0] == "pair") {
            if (args.size() != 1)
                throw std::invalid_argument("Unexpected argument");
            params["transport"] = usb ? "usb" : (wifi || args[0] == "pair" ? "wifi" : "auto");
            if (timeout >= 0)
                params["timeout_ms"] = timeout;
            if (display_brand) {
                const auto info = request("server.info", Json::object(), false);
                if (!info.value("ok", false) ||
                    !info.value("result", Json::object()).value("capabilities", Json::object())
                         .value("pairing_display_brand", false))
                    throw std::runtime_error("This server does not support display_brand; upgrade xdb Server");
                params["display_brand"] = *display_brand;
            }
            return request(args[0], params).value("ok", false) ? 0 : 1;
        }
        if (args[0] != "screenshot" && args[0] != "ddi" && !query_device)
            throw std::invalid_argument("Unknown command; run xdb --help");
        if (args[0] == "screenshot" && args.size() != 2)
            throw std::invalid_argument("Expected screenshot FILE");
        if (serial.empty() || query_device) {
            Json options = {{"transport", usb ? "usb" : wifi ? "wifi" : "auto"}};
            if (timeout >= 0)
                options["timeout_ms"] = timeout;
            auto found = request("devices", options, false);
            if (!found.value("ok", false))
                return 1;
            if (found["result"].value("cancelled", false))
                throw std::runtime_error("Device discovery was cancelled");
            const auto &device = select_device(found["result"]["devices"], serial,
                                                args[0] != "ddi" && !usb, wifi ? wifi_address : "");
            serial = device.at("udid").get<std::string>();
            params["udid"] = serial;
            if (query_device) {
                auto state = device.at("state").get<std::string>();
                if (json_output) {
                    found["result"] = {{"udid", serial}, {"state", state}};
                    std::cout << found.dump() << '\n';
                } else
                    std::cout << (args[0] == "get-state" ? state : serial) << '\n';
                return 0;
            }
        }
        if (wifi)
            params["wifi"] = wifi_address;
        if (args[0] == "ddi") {
            if (args[1] == "prepare") {
                params["replace"] = replace;
                if (!cache.empty())
                    params["cache_directory"] = cache;
            }
            return request("ddi." + args[1], params).value("ok", false) ? 0 : 1;
        }
        if (args[0] == "screenshot" && args.size() == 2) {
            output = args[1];
            params["transport"] = usb ? "usb" : wifi ? "wifi" : "auto";
            const auto info = request("server.info", Json::object(), false);
            if (info.value("ok", false) && info.value("result", Json::object())
                    .value("capabilities", Json::object()).value("read_only_sessions", false))
                params["access"] = "read";
            if (!request("connection.open", params, false).value("ok", false))
                return 1;
            return request("screenshot", Json::object()).value("ok", false) ? 0 : 1;
        }
        throw std::invalid_argument("Unknown command; run xdb --help");
    } catch (const std::exception &e) {
        std::cerr << "xdb: " << e.what() << '\n';
        return 2;
    }
}
