#include "media/AudioPump.h"
#include "media/Recorder.h"

#include <algorithm>
#include <chrono>
#include <cstdio>
#include <optional>
#include <span>
#include <thread>
#include <utility>

#include "remote/Device.h"
#include "rt/Rtcp.h"
#include "rt/RtpHevc.h"
#include "rt/RtpSeq.h"

namespace xdb::media {
namespace {

/// 每秒发送一个 RR，延长设备的 RTCP 空闲租期。音频会话独立计时，
/// 不能依赖视频 RR 续期，验证见 docs/coredevice.md §13。
constexpr uint64_t kRtcpPeriodMs = 1000;

/// 每轮收包的等待上限，兼顾 CPU 占用、停止响应和 RTCP 调度。
constexpr int kPollTimeoutMs = 50;

/// 环形缓冲容量至少为半秒，用于容纳短暂接收、消费抖动。
/// 实际容量随目标水位增大，确保预滚阈值可达，见 compute_waterline()。
constexpr std::size_t kMinRingCapacityFrames = 24000;

/// 限制最大缓冲时长，控制实时播放延迟和命令行参数导致的内存分配。
constexpr int kMaxTargetBacklogMs = 1000;

/// 音频包静默超过此时长后查询设备会话状态。
/// 实测静音内容仍约每秒发送 100 个包，故无音频包可作为查询理由，
/// 但不能据此直接认定会话结束。其他客户端的 stopAll 也可能结束音频，
/// 400 ms 查询阈值用于缩短这种中断；对照见 docs/coredevice.md §17.2。
constexpr uint64_t kQuietProbeMs = 400;

/// 两次 PCM 入环之间，空缓冲已播放一秒静音，旧水位和补偿不再描述当前时间线。
/// 以消费端缺少 PCM 的帧数判断，RTCP 活性不能掩盖播放器的长暂停。
constexpr uint64_t kClockPauseSeconds = 1;

uint64_t now_ms() {
    using clock = std::chrono::steady_clock;
    return static_cast<uint64_t>(
        std::chrono::duration_cast<std::chrono::milliseconds>(clock::now().time_since_epoch())
            .count());
}

}  // namespace

AudioPump::Waterline AudioPump::compute_waterline(const Options &options) {
    Waterline w;
    if (!options.decode_pcm) return w;
    int ms = options.target_backlog_ms;
    if (ms > kMaxTargetBacklogMs) {
        w.clamped_to_ms = kMaxTargetBacklogMs;
        ms = kMaxTargetBacklogMs;
    }
    if (ms < 0) {
        ms = 0;  // 0 = 不攒，取多少给多少；负数没有意义
    }
    const std::size_t rate =
        options.sample_rate > 0 ? static_cast<std::size_t>(options.sample_rate) : 48000;
    w.target_frames = static_cast<std::size_t>(ms) * rate / 1000;
    // 容量大于两倍水位，使 read() 的积压调节先于环满丢弃生效。
    w.capacity_frames =
        std::max<std::size_t>(kMinRingCapacityFrames, w.target_frames * 4 + w.target_frames / 4);
    // 保持预滚水位可达的约束，避免容量下限修改后无法开始播放。
    if (w.target_frames >= w.capacity_frames) {
        w.capacity_frames = w.target_frames * 4 + 1;
    }
    return w;
}

AudioPump::ReadTrim AudioPump::compute_read_trim(std::size_t buffered,
                                                std::size_t requested,
                                                std::size_t target,
                                                int frame_length, bool first_read) {
    if (requested == 0 || buffered <= requested) {
        return {};
    }
    const std::size_t remaining = buffered - requested;
    if (remaining <= target) {
        return {};
    }
    const std::size_t excess = remaining - target;
    if (first_read) {
        return {excess, true};
    }
    const std::size_t packet_frames = frame_length > 0 ? static_cast<std::size_t>(frame_length) : 480;
    // 等价于 remaining > 2 * target + packet_frames，但分步相减避免极值相加溢出。
    if (excess > target && excess - target > packet_frames) {
        return {excess, false};
    }
    return {};
}

std::unique_ptr<AudioPump> AudioPump::start(remote::Device &device, const Options &options,
                                           std::string &err, bool verbose) {
    if (!options.decode_pcm && (options.recorder == nullptr || !options.recorder->includes_audio())) {
        err = "Audio capture without PCM decoding requires a container recording with an audio track";
        return nullptr;
    }
    // 起流前计算并提示被限制的配置，与构造函数采用相同纯函数。
    const Waterline w = compute_waterline(options);
    if (w.clamped_to_ms != 0) {
        std::printf("Clamped audio buffer %d to %d ms and adjusted buffer capacity\n",
                    options.target_backlog_ms, w.clamped_to_ms);
    }
    auto pump = std::unique_ptr<AudioPump>(new AudioPump(device, options));
    pump->verbose_ = verbose;
    if (!pump->start_session(err)) {
        return nullptr;
    }
    if (options.decode_pcm) {
        std::string clock_error;
        pump->regulator_ = AudioRegulator::create(options.sample_rate, options.channels,
                                                  pump->target_frames_, clock_error);
        if (pump->regulator_ != nullptr) {
            pump->stats_.clock = pump->regulator_->stats();
        } else if (!clock_error.empty()) {
            pump->report_clock_failure(clock_error);
        }
    }
    pump->worker_ = std::thread([raw = pump.get()] { raw->loop(); });
    return pump;
}

AudioPump::~AudioPump() { stop(); }

bool AudioPump::validate_stream_mode(const StreamSession::Started &started,
                                     const Options &options, std::string &err) {
    const auto *mode = started.answer.at("connection").at("streamConfig").find("AudioStreamMode");
    uint64_t value = 0;
    if (mode != nullptr && mode->type == xpc::Type::UInt64) {
        value = mode->uint64;
    } else if (mode != nullptr && mode->type == xpc::Type::Int64 && mode->int64 >= 0) {
        value = static_cast<uint64_t>(mode->int64);
    } else {
        err = "Audio routing was not confirmed: answer has no valid AudioStreamMode";
        return false;
    }
    const uint64_t expected = options.audio_dup ? 8 : 10;
    if (value != expected) {
        err = options.audio_dup
            ? "Phone-and-computer audio routing was not accepted (duplicate=true requires AudioStreamMode 8)"
            : "Computer-only audio routing was not accepted (requires AudioStreamMode 10); not falling back to duplicate=true";
        return false;
    }
    err.clear();
    return true;
}

void AudioPump::reject_negotiation(std::string &err) {
    negotiation_invalid_ = true;
    if (options_.stop_device_on_exit && cleanup_session_ != nullptr) {
        err += ". Audio reception stopped; cleanup will stop device streaming when no other media pump is active";
    } else {
        char lease_note[384];
        std::snprintf(lease_note, sizeof(lease_note),
            ". Audio keepalive has stopped; wait for session expiry (about %u seconds), "
            "then resume the phone's player if needed", options_.lease_seconds);
        err += lease_note;
    }
    // 首次 AcceptedInvalidAnswer 没有有效 handle，不能声称已经停止设备会话。
    // 默认与视频并用时只停本地收包和续期，避免 stopAll 中断视频。
    note_terminal_error(err);
}

void AudioPump::note_terminal_error(const std::string &err) {
    std::lock_guard<std::mutex> lock(live_mutex_);
    if (terminal_error_.empty()) terminal_error_ = err;
}

bool AudioPump::start_session(std::string &err) {
    // 先确认解码器可用再起流，避免构建缺少后端时占用设备媒体会话。
    if (options_.decode_pcm && decoder_ == nullptr) {
        decoder_ = create_audio_decoder(options_.sample_rate, options_.channels,
                                       options_.frame_length, err);
        if (decoder_ == nullptr) {
            return false;
        }
    }

    StreamSession::Request request;
    request.cancel = stop_source_.get_token();
    request.audio = true;
    request.offer.audio_dup = options_.audio_dup;
    request.timeout_seconds = options_.lease_seconds;
    request.client_session_uuid = options_.client_session_uuid;
    StreamSession::StartStatus start_status = StreamSession::StartStatus::NotConfirmed;
    auto session = StreamSession::start(device_, request, err, verbose_, nullptr, &start_status);
    if (session == nullptr) {
        if (start_status == StreamSession::StartStatus::AcceptedInvalidAnswer) {
            reject_negotiation(err);
        }
        return false;
    }
    const auto &started = session->started();
    if (!validate_stream_mode(started, options_, err)) {
        if (options_.stop_device_on_exit) cleanup_session_ = std::move(session);
        reject_negotiation(err);
        // 不发 RR，也不为获得声音而静默改成双端播放。仅音频拥有者的最终
        // 清理可使用已确认的 handle；与视频并用时仍让音频租期到期。
        return false;
    }
    if (!started.has_remote_ssrc || !started.has_local_ssrc) {
        // 未协商设备来源时可绑定第一条合法音频 RTP；双方身份未确定前不发 RR。
        // 缺少客户端身份时不能凭默认 0 续期，输出协商值以便排查。
        std::fprintf(stderr,
                     "Audio answer missing SSRC (RemoteSSRC=%u LocalSSRC=%u); session renewal may fail\n",
                     started.remote_ssrc, started.local_ssrc);
    }
    session_ = std::move(session);
    cleanup_session_.reset();
    if (options_.recorder != nullptr && !worker_.joinable()) {
        (void)options_.recorder->begin_track(Recorder::Track::Audio, started.session_uuid,
            started.has_local_ssrc ? std::optional<uint32_t>(started.local_ssrc) : std::nullopt);
    }
    if (regulator_ != nullptr) {
        regulator_->reset();
        std::lock_guard<std::mutex> lock(mutex_);
        clock_silence_pending_ = 0;
        clock_discard_pending_ = 0;
        stats_.clock = regulator_->stats();
    }
    publish_live();
    return true;
}

/// 会话变更后更新公开快照。backend_name_ 也在相同锁内写入，
/// 与 backend_name() 的并发读取同步。
void AudioPump::publish_live() {
    std::lock_guard<std::mutex> lock(live_mutex_);
    Live live;
    if (session_ != nullptr) {
        const auto &started = session_->started();
        live.receiver_port = session_->receiver_port();
        live.payload_type = started.payload_type;
        live.sender_port = started.sender_port;
        live.remote_ssrc = started.remote_ssrc;
        live.local_ssrc = started.local_ssrc;
    }
    backend_name_ = decoder_ != nullptr ? decoder_->backend_name() : "none";
    live_ = live;
}

void AudioPump::clear_live() {
    std::lock_guard<std::mutex> lock(live_mutex_);
    live_ = {};
}

void AudioPump::stop_receiving() {
    stopping_.store(true);
    stop_source_.request_stop();
    if (worker_.joinable()) {
        worker_.join();
    }
}

void AudioPump::stop() {
    stop_receiving();
    // 接收线程已退出，外部应先关闭声卡。共享设备还有其他媒体泵时不发送 stopAll，
    // 本流停止续租；最后一个拥有者才使用已确认的会话清理设备。
    if (options_.stop_device_on_exit && !device_stop_attempted_) {
        device_stop_attempted_ = true;
        const auto *session = session_ != nullptr ? session_.get() : cleanup_session_.get();
        if (session != nullptr) {
            std::string stop_error;
            if (!media_lease_.stop_if_exclusive([&] { return session->stop(device_, stop_error, verbose_); })) {
                note_terminal_error(stop_error);
                std::fprintf(stderr, "Failed to stop audio-only device sessions: %s\n",
                             stop_error.c_str());
            }
        }
    }
    session_.reset();
    cleanup_session_.reset();
    media_lease_.release();
    clear_live();
}

void AudioPump::push(const std::vector<int16_t> &pcm) {
    if (regulator_ != nullptr) {
        bool paused;
        {
            std::lock_guard<std::mutex> lock(mutex_);
            paused = read_started_ && used_ == 0 &&
                     clock_silence_pending_ >= static_cast<uint64_t>(options_.sample_rate) *
                                               kClockPauseSeconds;
            if (paused) {
                // 累计欠载由 AudioOut 保留；仅清掉跨暂停的时钟估计修正。
                clock_silence_pending_ = 0;
                clock_discard_pending_ = 0;
            }
        }
        if (paused) {
            // 仍由生产线程操作 swr，并在转换恢复首包前撤销旧补偿。
            regulator_->reset();
        }
    }
    std::vector<int16_t> adjusted;
    std::string clock_error;
    const bool regulated = regulator_ != nullptr && regulator_->process(pcm, adjusted, clock_error);
    if (!clock_error.empty()) {
        report_clock_failure(clock_error);
    }
    // 库暂时不可用时播放原始 PCM，不让补偿错误结束解码或设备会话。
    const auto &output = regulated ? adjusted : pcm;
    const std::size_t channels =
        options_.channels > 0 ? static_cast<std::size_t>(options_.channels) : 1;
    const std::size_t frames = output.size() / channels;
    AudioRegulator::Observation observation;
    {
        std::lock_guard<std::mutex> lock(mutex_);
        if (ring_.empty()) {
            ring_.assign(capacity_frames_ * channels, 0);
        }
        // 短 burst 的音频仍会在后续收包间隙消费，不能因暂时超过两倍目标
        // 就硬裁。仅环满时丢弃旧数据；正常水位由软补偿逐渐回到固定目标。
        std::size_t from = 0;
        if (frames >= capacity_frames_) {
            const std::size_t drop = used_ + frames - capacity_frames_;
            stats_.dropped_stale += drop;
            clock_discard_pending_ += drop;
            used_ = 0;
            read_ = write_;
            from = frames - capacity_frames_;
        } else if (used_ + frames > capacity_frames_) {
            const std::size_t drop = used_ + frames - capacity_frames_;
            read_ = (read_ + drop) % capacity_frames_;
            used_ -= drop;
            stats_.dropped_stale += drop;
            clock_discard_pending_ += drop;
        }
        for (std::size_t f = from; f < frames; ++f) {
            const std::size_t slot = ((write_ + (f - from)) % capacity_frames_) * channels;
            for (std::size_t c = 0; c < channels; ++c) {
                ring_[slot + c] = output[f * channels + c];
            }
        }
        write_ = (write_ + (frames - from)) % capacity_frames_;
        used_ += frames - from;
        observation.buffered_frames = used_;
        observation.playing = read_started_;
        observation.inserted_silence = std::exchange(clock_silence_pending_, 0);
        observation.discarded_frames = std::exchange(clock_discard_pending_, 0);
    }
    if (regulated && !regulator_->observe(observation, clock_error)) {
        report_clock_failure(clock_error);
    }
    if (regulator_ != nullptr) {
        const auto clock_stats = regulator_->stats();
        std::lock_guard<std::mutex> lock(mutex_);
        stats_.clock = clock_stats;
    }
}

void AudioPump::report_clock_failure(const std::string &err) {
    std::uint64_t failures;
    {
        std::lock_guard<std::mutex> lock(mutex_);
        failures = ++stats_.clock_failed;
    }
    if (failures <= 3) {
        std::fprintf(stderr, "Audio clock compensation failed: %s; continuing playback\n",
                     err.c_str());
    }
}

std::size_t AudioPump::read(int16_t *dst, std::size_t frames) {
    if (!options_.decode_pcm) return 0;
    const std::size_t channels =
        options_.channels > 0 ? static_cast<std::size_t>(options_.channels) : 1;
    std::lock_guard<std::mutex> lock(mutex_);
    if (frames == 0) {
        return 0;
    }
    if (ring_.empty()) {
        if (read_started_) {
            clock_silence_pending_ += frames;
        }
        return 0;
    }
    // 本次将播放的 frames 不是额外积压；将它也算入目标会在正常节拍下反复
    // 丢掉少量样本。软补偿只裁启动积压；直接 PCM 路径还保留大积压保护。
    const auto trim = compute_read_trim(used_, frames, target_frames_, options_.frame_length,
                                       !read_started_);
    if (trim.frames > 0 && (trim.startup || regulator_ == nullptr)) {
        read_ = (read_ + trim.frames) % capacity_frames_;
        used_ -= trim.frames;
        clock_discard_pending_ += trim.frames;
        if (trim.startup) {
            stats_.startup_trimmed += trim.frames;
        } else {
            stats_.steered += trim.frames;
        }
    }
    const std::size_t take = frames < used_ ? frames : used_;
    for (std::size_t f = 0; f < take; ++f) {
        const std::size_t slot = ((read_ + f) % capacity_frames_) * channels;
        for (std::size_t c = 0; c < channels; ++c) {
            dst[f * channels + c] = ring_[slot + c];
        }
    }
    read_ = (read_ + take) % capacity_frames_;
    used_ -= take;
    if (take > 0) {
        read_started_ = true;
    }
    if (read_started_) {
        clock_silence_pending_ += frames - take;
    }
    return take;
}

std::size_t AudioPump::buffered_frames() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return used_;
}

AudioPump::Stats AudioPump::stats() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return stats_;
}

std::uint16_t AudioPump::receiver_port() const {
    std::lock_guard<std::mutex> lock(live_mutex_);
    return live_.receiver_port;
}

std::uint8_t AudioPump::payload_type() const {
    std::lock_guard<std::mutex> lock(live_mutex_);
    return live_.payload_type;
}

std::string AudioPump::backend_name() const {
    std::lock_guard<std::mutex> lock(live_mutex_);
    return backend_name_.empty() ? std::string("none") : backend_name_;
}

std::string AudioPump::terminal_error() const {
    std::lock_guard<std::mutex> lock(live_mutex_);
    return terminal_error_;
}

void AudioPump::loop() {
    std::vector<uint8_t> datagram;
    std::string err;
    uint64_t next_rtcp_ms = now_ms() + kRtcpPeriodMs;
    uint64_t last_packet_ms = now_ms();
    uint64_t last_probe_ms = 0;
    xdb::rt::RtpSeq seq;
    // LocalSSRC 采用设备视角，是收到的媒体来源。显式 0 合法；缺失时等待
    // 第一条合法、同 PT 的媒体 RTP，不能从 SR 或其他载荷类型猜测来源。
    std::optional<uint32_t> media_source = session_->started().has_local_ssrc
                                             ? std::optional<uint32_t>(session_->started().local_ssrc)
                                             : std::nullopt;
    /// RTP 序号统计按会话重置；重置前将旧会话丢包值计入 lost_carry，
    /// 供整个 AudioPump 生命周期的累计统计使用。
    uint64_t lost_carry = 0;
    uint64_t decode_failures_logged = 0;

    while (!stopping_.load()) {
        const uint64_t now = now_ms();

        if (session_ == nullptr) {
            if (options_.recorder != nullptr) {
                options_.recorder->fail("Audio session was recreated during container recording");
            }
            std::string rerr;
            if (start_session(rerr)) {
                {
                    std::lock_guard<std::mutex> lock(mutex_);
                    ++stats_.restarts;
                }
                std::printf("Audio session recreated, receive port=%u\n", session_->receiver_port());
                last_packet_ms = now_ms();
                next_rtcp_ms = last_packet_ms + kRtcpPeriodMs;
                last_probe_ms = 0;
                media_source = session_->started().has_local_ssrc
                                   ? std::optional<uint32_t>(session_->started().local_ssrc)
                                   : std::nullopt;
                // 新会话的序号空间与上一条无关，不重置会把第一包判成大片缺口。
                lost_carry += seq.lost();
                seq.reset();
                continue;
            }
            if (negotiation_invalid_) {
                std::fprintf(stderr, "Audio negotiation failed during recovery; disabling audio: %s\n",
                             rerr.c_str());
                break;
            }
            std::fprintf(stderr, "Failed to recreate audio session: %s (retry in 1 second)\n", rerr.c_str());
            // 使用可取消的条件变量等待，停止请求无需等待退避期结束。
            for (int i = 0; i < 10 && !stopping_.load(); ++i) {
                std::this_thread::sleep_for(std::chrono::milliseconds(100));
            }
            continue;
        }

        // 每轮检查本流的静默，而非仅在 UDP 收包超时后检查。连续的无关数据报
        // 不应绕过探测；确认会话结束后立即进入新会话，不能处理旧 epoch 的包。
        const uint64_t quiet = now - last_packet_ms;
        if (quiet >= kQuietProbeMs && now >= last_probe_ms + kRtcpPeriodMs) {
            last_probe_ms = now;
            std::string perr;
            const auto state = StreamSession::probe(device_, session_->started().session_uuid,
                                                    perr, verbose_, stop_source_.get_token());
            if (state == StreamSession::ServerState::Ended) {
                if (options_.recorder != nullptr) {
                    options_.recorder->fail("Device ended the recorded audio session");
                }
                std::fprintf(stderr, "Audio: device session ended (%llu ms without audio); recreating session\n",
                             static_cast<unsigned long long>(quiet));
                if (options_.stop_device_on_exit) cleanup_session_ = std::move(session_);
                else session_.reset();
                clear_live();
                continue;
            }
        }

        // 保活使用每轮检查的单调时钟，不依赖收包超时；错过周期时从当前
        // 时间重新调度，不连续补发过期 RR。只有双方身份已知才发送；0 是合法值，
        // 不能把未协商的默认 0 当成发送者或报告目标。
        if (media_source && session_->started().has_remote_ssrc && now >= next_rtcp_ms) {
            next_rtcp_ms = now + kRtcpPeriodMs;
            const auto rr = xdb::rt::build_rr(session_->started().remote_ssrc,
                                                 *media_source, seq.extended_high());
            std::string serr;
            const bool ok = session_->send_rtp(rr, session_->started().sender_port, serr);
            uint64_t failed_after = 0;
            {
                std::lock_guard<std::mutex> lock(mutex_);
                if (ok) {
                    ++stats_.rtcp_sent;
                } else {
                    failed_after = ++stats_.rtcp_failed;
                }
            }
            // 每个会话只输出第一次发送失败，后续由会话恢复策略处理。
            if (failed_after == 1) {
                std::fprintf(stderr, "Failed to send audio RTCP keepalive: %s\n", serr.c_str());
            }
        }

        uint16_t peer_port = 0;
        if (!session_->next_packet(datagram, peer_port, kPollTimeoutMs, err)) {
            continue;
        }

        // RTP/RTCP 在此端口复用；起流答复已拒绝冲突的媒体 PT 64..95。
        // RTCP 的 length 不是 RTP sequence，必须先分类。
        // parser 校验 compound 边界及 SR/RR 字段；其他 RTCP 仅检查帧边界，
        // 不将它们当作媒体活性。坏 RTCP 也不能落入 RTP 处理路径。
        if (datagram.size() >= 2 && datagram[1] >= 192 && datagram[1] <= 223) {
            std::vector<xdb::rt::SenderReport> reports;
            if (xdb::rt::parse_sender_reports(datagram, reports)) {
                for (const auto &report : reports) {
                    if (media_source && report.ssrc == *media_source) {
                        last_packet_ms = now_ms();
                        if (options_.recorder != nullptr) {
                            (void)options_.recorder->sender_report(Recorder::Track::Audio,
                                session_->started().session_uuid, report);
                        }
                    }
                }
                std::lock_guard<std::mutex> lock(mutex_);
                ++stats_.other_payload;
            }
            continue;
        }

        xdb::rt::PacketInfo info;
        if (!xdb::rt::parse_rtp_header(std::span<const uint8_t>(datagram), info)) {
            continue;
        }
        // 载荷类型和来源都确认后才更新本流活性与序号。PT101 的 marker 置位
        // 后第二字节为 229，仍是合法音频 RTP，不属于上面的 RTCP 范围。
        if (info.payload_type != session_->started().payload_type) {
            std::lock_guard<std::mutex> lock(mutex_);
            ++stats_.other_payload;
            continue;
        }
        if (!media_source) {
            media_source = info.ssrc;
        } else if (info.ssrc != *media_source) {
            continue;
        }
        last_packet_ms = now_ms();
        // 使用共享 rt::RtpSeq 处理序号回绕和乱序；最高序号不随迟到包回退。
        const auto verdict = seq.observe(info.sequence);
        {
            std::lock_guard<std::mutex> lock(mutex_);
            ++stats_.packets;
            if (verdict == xdb::rt::RtpSeq::Verdict::kGap) {
                ++stats_.seq_gaps;
            } else if (verdict == xdb::rt::RtpSeq::Verdict::kLate) {
                ++stats_.out_of_order;
            }
            // 使用当前未补齐缺口数，允许迟到包减少丢包读数；旧会话值已保存在
            // lost_carry 中。
            stats_.seq_lost = lost_carry + seq.lost();
        }
        // 当前没有音频重排队列，无法把迟到帧插回已输出的 PCM。仍保留接收统计
        // 的缺口补齐，但重复和迟到载荷不得再次送入有状态的 AAC 解码器。
        if (verdict == xdb::rt::RtpSeq::Verdict::kLate) {
            continue;
        }
        // 当前 ELD 每包承载一帧（10 ms），不做重组或重传，只统计序号缺口。
        // 录制保留后续包的原始时间戳，缺失区间不补包、不压缩，也不终止其它轨道。
        const auto payload = std::span<const uint8_t>(datagram).subspan(
            info.payload_offset, info.payload_size);
        if (options_.recorder != nullptr) {
            (void)options_.recorder->audio(session_->started().session_uuid, *media_source,
                info.timestamp, payload);
        }
        if (!options_.decode_pcm) continue;
        std::vector<int16_t> pcm;
        std::string derr;
        if (!decoder_->decode(payload, pcm, derr)) {
            {
                std::lock_guard<std::mutex> lock(mutex_);
                ++stats_.decode_failed;
            }
            // 解码错误只输出前几次，避免每包重复日志。
            if (decode_failures_logged < 3) {
                ++decode_failures_logged;
                std::fprintf(stderr, "Audio decode failed (%zu-byte payload): %s\n", payload.size(),
                             derr.c_str());
            }
            continue;
        }
        if (!pcm.empty()) {
            {
                std::lock_guard<std::mutex> lock(mutex_);
                ++stats_.decoded;
            }
            push(pcm);
        }
    }
}

}  // namespace xdb::media
