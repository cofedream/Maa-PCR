#include "util/OutputFile.h"
#include <cerrno>
#include "media/RecordingMuxer.h"

#include "media/RecordingVideoConfig.h"

#include <array>
#include <cstring>
#include <limits>
#include <utility>

#ifdef XDB_HAVE_LIBAVFORMAT
extern "C" {
#include <libavcodec/avcodec.h>
#include <libavcodec/version.h>
#include <libavformat/avformat.h>
#include <libavformat/version.h>
#include <libavutil/channel_layout.h>
#include <libavutil/display.h>
#include <libavutil/error.h>
#include <libavutil/mem.h>
#include <libavutil/version.h>
}
#endif

namespace xdb::media {
namespace {
[[maybe_unused]] constexpr const char* unavailable = "Container recording requires libavformat and libavcodec";

#ifdef XDB_HAVE_LIBAVFORMAT
std::string libav_error(int code) {
    char text[AV_ERROR_MAX_STRING_SIZE]{};
    av_strerror(code, text, sizeof(text));
    return text;
}

struct ContextDeleter {
    void operator()(AVCodecContext* context) const { avcodec_free_context(&context); }
};

// 参数检查与 codecpar 导出使用同一份原始字节；不经临时文件或手写 hvcC 转换。
bool video_parameters(AVCodecParameters* output, const RecordingMuxer::Options& options,
                      std::string& error) {
    const AVCodec* codec = avcodec_find_decoder_by_name("hevc");
    if (codec == nullptr) {
        error = "libavcodec has no software HEVC decoder";
        return false;
    }
    std::unique_ptr<AVCodecContext, ContextDeleter> context(avcodec_alloc_context3(codec));
    if (context == nullptr) {
        error = "Cannot allocate the HEVC recording context";
        return false;
    }
    context->thread_count = 1;
    context->err_recognition = AV_EF_EXPLODE;
    const std::array<std::span<const uint8_t>, 3> parameters{
        options.vps, options.sps, options.pps};
    const std::size_t size = options.vps.size() + options.sps.size() + options.pps.size() + 12;
    context->extradata = static_cast<uint8_t*>(av_mallocz(size + AV_INPUT_BUFFER_PADDING_SIZE));
    if (context->extradata == nullptr) {
        error = "Cannot allocate HEVC recording extradata";
        return false;
    }
    context->extradata_size = static_cast<int>(size);
    auto* target = context->extradata;
    constexpr std::array<uint8_t, 4> prefix{0, 0, 0, 1};
    for (const auto nal : parameters) {
        std::memcpy(target, prefix.data(), prefix.size());
        target += prefix.size();
        std::memcpy(target, nal.data(), nal.size());
        target += nal.size();
    }
    const int opened = avcodec_open2(context.get(), codec, nullptr);
    if (opened < 0) {
        error = "Cannot open the HEVC recording configuration: " + libav_error(opened);
        return false;
    }
    const int copied = avcodec_parameters_from_context(output, context.get());
    if (copied < 0) {
        error = "Cannot export HEVC recording parameters: " + libav_error(copied);
        return false;
    }
    return true;
}

bool audio_parameters(AVCodecParameters* output, const RecordingMuxer::Audio& audio,
                      std::string& error) {
    output->codec_type = AVMEDIA_TYPE_AUDIO;
    output->codec_id = AV_CODEC_ID_AAC;
#ifdef AV_PROFILE_AAC_ELD
    output->profile = AV_PROFILE_AAC_ELD;
#else
    output->profile = FF_PROFILE_AAC_ELD;
#endif
    output->sample_rate = audio.sample_rate;
    output->frame_size = audio.frame_samples;
#if LIBAVUTIL_VERSION_INT >= AV_VERSION_INT(57, 24, 100)
    av_channel_layout_default(&output->ch_layout, audio.channels);
#else
    output->channels = audio.channels;
    output->channel_layout = AV_CH_LAYOUT_STEREO;
#endif
    // 与现有 AAC-ELD 解码器使用的已验证 ASC 相同：48 kHz、双声道，
    // frameLengthFlag=1 对应 480，0 对应 512。没有 ADTS 或 SBR。
    const std::array<uint8_t, 4> asc{
        0xf8, 0xe6, static_cast<uint8_t>(audio.frame_samples == 480 ? 0x50 : 0x40), 0x00};
    output->extradata = static_cast<uint8_t*>(av_mallocz(asc.size() + AV_INPUT_BUFFER_PADDING_SIZE));
    if (output->extradata == nullptr) {
        error = "Cannot allocate AAC-ELD recording extradata";
        return false;
    }
    std::memcpy(output->extradata, asc.data(), asc.size());
    output->extradata_size = static_cast<int>(asc.size());
    return true;
}
#endif
}  // namespace

struct RecordingMuxer::Impl {
    std::string first_error;
    bool closed = false;

    bool fail(std::string reason, std::string& error) {
        if (first_error.empty()) first_error = std::move(reason);
        error = first_error;
        return false;
    }

#ifdef XDB_HAVE_LIBAVFORMAT
    AVFormatContext* context = nullptr;
    std::FILE* output = nullptr;
    static int write_output(void* opaque, const uint8_t* data, int size) {
        auto* self = static_cast<Impl*>(opaque);
        if (std::fwrite(data, 1, size, self->output) != static_cast<size_t>(size))
            return AVERROR(errno ? errno : EIO);
        return size;
    }
    static int write_output(void* opaque, uint8_t* data, int size) {
        return write_output(opaque, static_cast<const uint8_t*>(data), size);
    }
    static int64_t seek_output(void* opaque, int64_t offset, int whence) {
        auto* self = static_cast<Impl*>(opaque);
        if (whence & AVSEEK_SIZE) {
            const auto current = util::seek_output_file(self->output, 0, SEEK_CUR);
            if (current < 0) return AVERROR(errno ? errno : EIO);
            const auto size = util::seek_output_file(self->output, 0, SEEK_END);
            if (util::seek_output_file(self->output, current, SEEK_SET) < 0)
                return AVERROR(errno ? errno : EIO);
            return size < 0 ? AVERROR(errno ? errno : EIO) : size;
        }
        const auto position = util::seek_output_file(self->output, offset, whence & ~AVSEEK_FORCE);
        return position < 0 ? AVERROR(errno ? errno : EIO) : position;
    }
    AVPacket* packet = nullptr;
    AVStream* video = nullptr;
    AVStream* audio = nullptr;
    Format format = Format::Mp4;
    bool header_written = false;
    std::optional<int64_t> video_dts, audio_dts;

    void remember(std::string reason) {
        if (first_error.empty()) first_error = std::move(reason);
    }

    void check_io(const char* operation) {
        if (context != nullptr && context->pb != nullptr && context->pb->error < 0) {
            remember(std::string(operation) + ": " + libav_error(context->pb->error));
        }
    }

    bool write(std::span<const uint8_t> bytes, Timing timing, AVStream* stream,
               std::optional<int64_t>& last_dts, bool is_video, bool keyframe,
               std::string& error) {
        error.clear();
        if (!first_error.empty()) return fail(first_error, error);
        if (closed) {
            error = "The recording file has already been closed";
            return false;
        }
        if (stream == nullptr) return fail(is_video ? "This recording has no video track"
                                                  : "This recording has no audio track", error);
        if (bytes.empty() || bytes.size() > kMaxRecordingMuxerPacketBytes) {
            return fail("Recording access unit is empty or exceeds the 16 MiB packet budget", error);
        }
        if (is_video) {
            const bool annex_b = bytes.size() >= 4 && bytes[0] == 0 && bytes[1] == 0 &&
                (bytes[2] == 1 || (bytes[2] == 0 && bytes[3] == 1));
            if (!annex_b) return fail("HEVC recording requires an Annex-B access unit", error);
            if (timing.pts_us != timing.dts_us) {
                return fail("This HEVC configuration requires equal recording PTS and DTS", error);
            }
            if (format == Format::Mp4 && timing.duration_us == 0) {
                return fail("MP4 recording requires a known positive HEVC access unit duration", error);
            }
        }
        if (timing.pts_us == AV_NOPTS_VALUE || timing.dts_us == AV_NOPTS_VALUE ||
            timing.duration_us < 0 || (!is_video && timing.duration_us == 0) ||
            timing.pts_us > std::numeric_limits<int64_t>::max() - timing.duration_us ||
            timing.dts_us > std::numeric_limits<int64_t>::max() - timing.duration_us) {
            return fail("Recording timestamps or duration are invalid or overflow", error);
        }
        if (format == Format::Matroska && (timing.pts_us < 0 || timing.dts_us < 0)) {
            return fail("Matroska recording requires a nonnegative common origin for both tracks", error);
        }
        av_packet_unref(packet);
        const int allocated = av_new_packet(packet, static_cast<int>(bytes.size()));
        if (allocated < 0) return fail("Cannot allocate a recording packet: " + libav_error(allocated), error);
        std::memcpy(packet->data, bytes.data(), bytes.size());
        packet->stream_index = stream->index;
        packet->pts = timing.pts_us;
        packet->dts = timing.dts_us;
        packet->duration = timing.duration_us;
        packet->pos = -1;
        if (keyframe) packet->flags |= AV_PKT_FLAG_KEY;
        // write_header 可改变 time_base；必须使用当前流的实际值，不能保留先验微秒。
        av_packet_rescale_ts(packet, AVRational{1, 1000000}, stream->time_base);
        if (packet->pts == AV_NOPTS_VALUE || packet->dts == AV_NOPTS_VALUE ||
            packet->pts == std::numeric_limits<int64_t>::max() ||
            packet->dts == std::numeric_limits<int64_t>::max() || packet->duration < 0 ||
            (timing.duration_us != 0 && packet->duration == 0) ||
            packet->pts > std::numeric_limits<int64_t>::max() - packet->duration ||
            packet->dts > std::numeric_limits<int64_t>::max() - packet->duration) {
            av_packet_unref(packet);
            return fail("Recording timestamps cannot be represented in the container time base", error);
        }
        if (last_dts.has_value() && packet->dts <= *last_dts) {
            av_packet_unref(packet);
            return fail("Recording DTS must increase within each track and its container time base", error);
        }
        // movenc 的 sample duration 使用有符号 32 位差值；超限应明确失败，
        // 不能让未知时长或极大时间间隔在写 trailer 时触发库内部断言。
        if (format == Format::Mp4 &&
            (packet->duration > std::numeric_limits<int>::max() ||
             (last_dts.has_value() &&
              *last_dts <= std::numeric_limits<int64_t>::max() - std::numeric_limits<int>::max() &&
              packet->dts > *last_dts + std::numeric_limits<int>::max()))) {
            av_packet_unref(packet);
            return fail("Recording sample duration or DTS interval exceeds the MP4 range", error);
        }
        const int64_t written_dts = packet->dts;
        const int written = av_interleaved_write_frame(context, packet);
        av_packet_unref(packet);
        if (written < 0) remember("Cannot write a recording packet: " + libav_error(written));
        check_io("Cannot write the recording file");
        if (!first_error.empty()) return fail(first_error, error);
        last_dts = written_dts;
        return true;
    }
#endif

    bool finish(std::string& error) {
#ifdef XDB_HAVE_LIBAVFORMAT
        if (!closed) {
            if (context != nullptr && header_written) {
                const int trailer = av_write_trailer(context);
                if (trailer < 0) remember("Cannot finish the recording container: " + libav_error(trailer));
                check_io("Cannot finish the recording file");
            }
            if (context != nullptr && context->pb != nullptr) {
                avio_flush(context->pb);
                check_io("Cannot flush the recording file");
                av_freep(&context->pb->buffer);
                avio_context_free(&context->pb);
            }
            if (output != nullptr) {
                if (std::fclose(output) != 0) remember("Cannot close the recording file");
                output = nullptr;
            }
            av_packet_free(&packet);
            avformat_free_context(context);
            context = nullptr;
            video = audio = nullptr;
            closed = true;
        }
#else
        closed = true;
        if (first_error.empty()) first_error = unavailable;
#endif
        error = first_error;
        return first_error.empty();
    }
};

RecordingMuxer::RecordingMuxer(std::unique_ptr<Impl> impl) : impl_(std::move(impl)) {}

RecordingMuxer::~RecordingMuxer() {
    std::string ignored;
    impl_->finish(ignored);
}

bool RecordingMuxer::available() noexcept {
#ifdef XDB_HAVE_LIBAVFORMAT
    return true;
#else
    return false;
#endif
}

bool RecordingMuxer::validate_video_orientation(Format format, int degrees, std::string& error) {
    error.clear();
    if (format != Format::Mp4 && format != Format::Matroska) {
        error = "Unsupported recording container format";
        return false;
    }
    if (degrees != 0 && degrees != 90 && degrees != 180 && degrees != 270) {
        error = "Recording video orientation must be 0, 90, 180 or 270 degrees clockwise";
        return false;
    }
    if (degrees == 0) return true;
#ifndef XDB_HAVE_LIBAVFORMAT
    error = unavailable;
    return false;
#else
    // FFmpeg 6.1 是已核对支持普通画面 ProjectionPoseRoll 的版本下限。
    // 5.x/6.0 的 MKV muxer 会忽略 display matrix，不能让方向静默失效。
#if LIBAVFORMAT_VERSION_INT < AV_VERSION_INT(60, 16, 100) || \
    LIBAVCODEC_VERSION_INT < AV_VERSION_INT(60, 30, 100)
    if (format == Format::Matroska) {
        error = "Matroska recording orientation requires FFmpeg 6.1 or newer";
        return false;
    }
#endif
    return true;
#endif
}

std::unique_ptr<RecordingMuxer> RecordingMuxer::open(const Options& options, std::string& error) {
    if (!options.include_video && !options.audio.has_value()) {
        error = "Recording requires at least one selected track";
        return nullptr;
    }
    if (!options.include_video && options.video_orientation != 0) {
        error = "Audio-only recording requires zero video orientation";
        return nullptr;
    }
    if (!options.include_video && (!options.vps.empty() || !options.sps.empty() || !options.pps.empty())) {
        error = "Audio-only recording must not include HEVC parameter sets";
        return nullptr;
    }
    if (!validate_video_orientation(options.format, options.video_orientation, error)) return nullptr;
#ifndef XDB_HAVE_LIBAVFORMAT
    (void)options;
    error = unavailable;
    return nullptr;
#else
    if (options.path.empty() || options.path.find('\0') != std::string::npos) {
        error = "Recording requires a nonempty local file path without NUL bytes";
        return nullptr;
    }
    const char* format = nullptr;
    switch (options.format) {
        case Format::Mp4: format = "mp4"; break;
        case Format::Matroska: format = "matroska"; break;
        default: error = "Unsupported recording container format"; return nullptr;
    }
    if (options.audio.has_value() &&
        (options.audio->sample_rate != 48000 || options.audio->channels != 2 ||
         (options.audio->frame_samples != 480 && options.audio->frame_samples != 512))) {
        error = "AAC-ELD recording supports only 48 kHz stereo with 480 or 512 samples per packet";
        return nullptr;
    }
    if (options.include_video) {
        const auto checked = inspect_recording_video_config(options.vps, options.sps, options.pps);
        if (!checked.permits_equal_dts_pts()) {
            error = checked.status == RecordingVideoConfig::Status::Reorder
                ? "Recording HEVC with frame reordering is not supported"
                : "Cannot validate the HEVC recording configuration: " + checked.error;
            return nullptr;
        }
    }
    auto result = std::unique_ptr<RecordingMuxer>(new RecordingMuxer(std::make_unique<Impl>()));
    auto& impl = *result->impl_;
    impl.format = options.format;
    const int allocated = avformat_alloc_output_context2(&impl.context, nullptr, format, options.path.c_str());
    if (allocated < 0 || impl.context == nullptr) {
        impl.fail("Cannot allocate the recording container: " + libav_error(allocated), error);
        return nullptr;
    }
#ifdef AVFMT_AVOID_NEG_TS_DISABLED
    impl.context->avoid_negative_ts = AVFMT_AVOID_NEG_TS_DISABLED;
#else
    // FFmpeg 5.0 的公开字段以 0 表示 disabled，尚未提供同名常量。
    impl.context->avoid_negative_ts = 0;
#endif
    // 静止视频不会阻塞持续音频直到下一幅图像；这里只使用 libavformat 的有界交错。
    impl.context->max_interleave_delta = 100000;
    if (options.include_video) {
        impl.video = avformat_new_stream(impl.context, nullptr);
        if (impl.video == nullptr) {
            impl.fail("Cannot allocate the HEVC recording track", error);
            return nullptr;
        }
        if (!video_parameters(impl.video->codecpar, options, error)) {
            impl.fail(error, error);
            return nullptr;
        }
        // hvc1 makes movenc strip in-band parameter sets. hev1 preserves the
        // checked IDR prefixes that allow a later size/configuration transition.
        impl.video->codecpar->codec_tag = options.format == Format::Mp4 ? MKTAG('h', 'e', 'v', '1') : 0;
        impl.video->time_base = AVRational{1, 1000000};
        impl.video->avg_frame_rate = impl.video->r_frame_rate = AVRational{0, 1};
        if (options.video_orientation != 0) {
            // codec 参数复制完成后、写 header 前设置，以免后续参数复制覆盖矩阵。
            // set 接受顺时针角度；get/ffprobe 的角度按逆时针报告，符号相反。
#if LIBAVCODEC_VERSION_INT >= AV_VERSION_INT(60, 30, 100)
            const auto* side_data = av_packet_side_data_new(&impl.video->codecpar->coded_side_data,
                &impl.video->codecpar->nb_coded_side_data, AV_PKT_DATA_DISPLAYMATRIX,
                9 * sizeof(int32_t), 0);
            uint8_t* matrix = side_data == nullptr ? nullptr : side_data->data;
#else
            uint8_t* matrix = av_stream_new_side_data(impl.video, AV_PKT_DATA_DISPLAYMATRIX,
                                                     9 * sizeof(int32_t));
#endif
            if (matrix == nullptr) {
                impl.fail("Cannot allocate recording video orientation metadata", error);
                return nullptr;
            }
            av_display_rotation_set(reinterpret_cast<int32_t*>(matrix), options.video_orientation);
        }
    }
    if (options.audio.has_value()) {
        impl.audio = avformat_new_stream(impl.context, nullptr);
        if (impl.audio == nullptr) {
            impl.fail("Cannot allocate the AAC-ELD recording track", error);
            return nullptr;
        }
        if (!audio_parameters(impl.audio->codecpar, *options.audio, error)) {
            impl.fail(error, error);
            return nullptr;
        }
        impl.audio->time_base = AVRational{1, 1000000};
    }
    impl.packet = av_packet_alloc();
    if (impl.packet == nullptr) {
        impl.fail("Cannot allocate the recording packet", error);
        return nullptr;
    }
    impl.output = util::create_output_file(options.path, error);
    if (impl.output == nullptr) {
        impl.fail("Cannot open the recording file: " + error, error);
        return nullptr;
    }
    // libav owns one buffer; FILE remains unbuffered so I/O errors reach pb->error.
    std::setvbuf(impl.output, nullptr, _IONBF, 0);
    auto* buffer = static_cast<unsigned char*>(av_malloc(32768));
    if (buffer == nullptr) {
        impl.fail("Cannot allocate recording I/O buffer", error);
        return nullptr;
    }
    impl.context->pb = avio_alloc_context(buffer, 32768, 1, &impl, nullptr,
                                          &Impl::write_output, &Impl::seek_output);
    if (impl.context->pb == nullptr) {
        av_free(buffer);
        impl.fail("Cannot allocate recording I/O context", error);
        return nullptr;
    }
    impl.context->flags |= AVFMT_FLAG_CUSTOM_IO;
    // 普通 MP4 保留完整 AAC roll sample groups；不通过分片或关闭 edit list
    // 绕过尾帧/priming 约束。未知视频时长在 write 前明确拒绝，由调用方处理。
    const int header = avformat_write_header(impl.context, nullptr);
    if (header < 0) impl.remember("Cannot write the recording header: " + libav_error(header));
    impl.header_written = header >= 0;
    // 部分协议使用缓冲写入。显式 flush 才能在 open 阶段识别真正的头部 I/O 失败。
    avio_flush(impl.context->pb);
    impl.check_io("Cannot write the recording header");
    if (!impl.first_error.empty()) {
        error = impl.first_error;
        return nullptr;
    }
    return result;
#endif
}

bool RecordingMuxer::write_video(std::span<const uint8_t> bytes, Timing timing,
                                 bool keyframe, std::string& error) {
#ifdef XDB_HAVE_LIBAVFORMAT
    return impl_->write(bytes, timing, impl_->video, impl_->video_dts, true, keyframe, error);
#else
    (void)bytes; (void)timing; (void)keyframe;
    return impl_->fail(unavailable, error);
#endif
}

bool RecordingMuxer::write_audio(std::span<const uint8_t> bytes, Timing timing, std::string& error) {
#ifdef XDB_HAVE_LIBAVFORMAT
    return impl_->write(bytes, timing, impl_->audio, impl_->audio_dts, false, true, error);
#else
    (void)bytes; (void)timing;
    return impl_->fail(unavailable, error);
#endif
}

bool RecordingMuxer::finish(std::string& error) { return impl_->finish(error); }

const std::string& RecordingMuxer::error() const noexcept { return impl_->first_error; }

}  // namespace xdb::media
