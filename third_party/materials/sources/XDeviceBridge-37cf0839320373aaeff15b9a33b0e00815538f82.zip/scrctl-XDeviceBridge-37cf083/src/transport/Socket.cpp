#include "transport/Socket.h"
#include <algorithm>
#include <climits>
#ifndef _WIN32
#include <sys/time.h>
#include <netinet/tcp.h>
#include <unistd.h>
#else
#include <mstcpip.h>
#endif

namespace xdb::transport {
namespace {
// socket BIO 不经过 write_all，因此在支持的平台对句柄本身关闭 SIGPIPE。
// TLS BIO 的 send 同样使用 MSG_NOSIGNAL，不修改进程级信号处理。
void disable_sigpipe(NativeSocket fd) {
#ifdef SO_NOSIGPIPE
    const int one = 1;
    ::setsockopt(fd, SOL_SOCKET, SO_NOSIGPIPE, &one, sizeof(one));
#else
    (void)fd;
#endif
}

} // namespace

// ------------------------------------------------------------ Socket ------

Socket::Socket(NativeSocket fd) : fd_(fd) {
    if (valid()) {
        disable_sigpipe(fd_);
    }
}

Socket::Socket(Socket &&other) noexcept : fd_(other.fd_) { other.fd_ = kInvalidSocket; }

Socket &Socket::operator=(Socket &&other) noexcept {
    if (this != &other) {
        close();
        fd_ = other.fd_;
        other.fd_ = kInvalidSocket;
    }
    return *this;
}

Socket::~Socket() { close(); }

void Socket::reset(NativeSocket fd) {
    close();
    fd_ = fd;
    if (valid()) {
        disable_sigpipe(fd_);
    }
}

void Socket::close() {
    if (valid()) {
        close_socket(fd_);
        fd_ = kInvalidSocket;
    }
}

#if defined(MSG_NOSIGNAL)
// Linux 使用 MSG_NOSIGNAL 保护这里的 send。OpenSSL 的 socket BIO
// 不经过本方法，但其自定义 BIO 同样使用 MSG_NOSIGNAL。
constexpr int kNoSigPipe = MSG_NOSIGNAL;
#else
constexpr int kNoSigPipe = 0;
#endif

bool Socket::enable_keepalive(std::string &err) {
    const int on = 1;
    if (::setsockopt(fd_, SOL_SOCKET, SO_KEEPALIVE, reinterpret_cast<const char *>(&on), sizeof(on)) != 0)
        return err = "Cannot enable TCP keepalive: " + socket_error_message(), false;
#ifdef _WIN32
    tcp_keepalive values{1, 30000, 10000};
    DWORD returned = 0;
    if (::WSAIoctl(fd_, SIO_KEEPALIVE_VALS, &values, sizeof(values), nullptr, 0, &returned, nullptr, nullptr) != 0)
        return err = "Cannot configure TCP keepalive: " + socket_error_message(), false;
#else
    const int idle = 30, interval = 10, count = 3;
#ifdef __APPLE__
    constexpr int idle_option = TCP_KEEPALIVE;
#else
    constexpr int idle_option = TCP_KEEPIDLE;
#endif
    if (::setsockopt(fd_, IPPROTO_TCP, idle_option, &idle, sizeof(idle)) != 0 ||
        ::setsockopt(fd_, IPPROTO_TCP, TCP_KEEPINTVL, &interval, sizeof(interval)) != 0 ||
        ::setsockopt(fd_, IPPROTO_TCP, TCP_KEEPCNT, &count, sizeof(count)) != 0)
        return err = "Cannot configure TCP keepalive: " + socket_error_message(), false;
#endif
    return true;
}

bool Socket::write_all(const void *data, size_t len, std::string &err) {
    const auto *p = static_cast<const uint8_t *>(data);
    size_t left = len;
    while (left > 0) {
        const auto n = ::send(fd_, reinterpret_cast<const char *>(p),
                              static_cast<int>(std::min(left, size_t(INT_MAX))), kNoSigPipe);
        if (n < 0) {
            if (socket_error() == kSocketInterrupted) {
                continue;
            }
            err = std::string("send failed: ") + socket_error_message();
            return false;
        }
        if (n == 0) {
            err = "Peer closed write direction";
            return false;
        }
        p += static_cast<size_t>(n);
        left -= static_cast<size_t>(n);
    }
    return true;
}

bool Socket::read_exact(void *data, size_t len, std::string &err) {
    if (len == 0) {
        return true;
    }
    auto *p = static_cast<uint8_t *>(data);
    size_t got = 0;
    while (got < len) {
        const auto n = ::recv(fd_, reinterpret_cast<char *>(p + got),
                              static_cast<int>(std::min(len - got, size_t(INT_MAX))), 0);
        if (n < 0) {
            if (socket_error() == kSocketInterrupted) {
                continue;
            }
            if (socket_read_timed_out(socket_error())) {
                err = "Read timed out (no bytes before deadline)";
                return false;
            }
            err = std::string("recv failed: ") + socket_error_message();
            return false;
        }
        if (n == 0) {
            err = "Peer closed (received only " + std::to_string(got) + "/" +
                  std::to_string(len) + ")";
            return false;
        }
        got += static_cast<size_t>(n);
    }
    return true;
}

bool Socket::set_read_timeout(int ms, std::string &err) {
#ifdef _WIN32
    const DWORD tv = static_cast<DWORD>(std::max(ms, 0));
#else
    timeval tv{};
    tv.tv_sec = ms / 1000;
    tv.tv_usec = (ms % 1000) * 1000;
#endif
    if (::setsockopt(fd_, SOL_SOCKET, SO_RCVTIMEO, reinterpret_cast<const char *>(&tv),
                     sizeof(tv)) != 0) {
        err = std::string("Failed to set read timeout: ") + socket_error_message();
        return false;
    }
    return true;
}

void Socket::interrupt() {
    if (valid()) {
        ::shutdown(fd_, kShutdownBoth);
#ifdef _WIN32
        // Winsock shutdown 不一定唤醒已挂起的接收；取消该句柄的未完成 I/O，
        // 所有权仍保留到使用它的线程退出后再关闭。
        CancelIoEx(reinterpret_cast<HANDLE>(fd_), nullptr);
#endif
    }
}

bool Socket::wait_readable(int ms, std::string &err, bool *timed_out) {
    if (timed_out)
        *timed_out = false;
    if (!valid()) {
        err = "Socket closed";
        return false;
    }
    for (;;) {
        const int n = wait_socket(fd_, false, ms);
        if (n > 0) {
            return true;
        }
        if (n == 0) {
            if (timed_out) {
                *timed_out = true;
                err.clear();
            } else {
                err = "Wait timed out";
            }
            return false;
        }
        if (socket_error() != kSocketInterrupted) {
            err = std::string("poll failed: ") + socket_error_message();
            return false;
        }
    }
}

bool Socket::read_len_prefixed_be(std::vector<uint8_t> &out, std::string &err) {
    uint8_t hdr[4];
    if (!read_exact(hdr, 4, err)) {
        return false;
    }
    const uint32_t len =
        uint32_t(hdr[0]) << 24 | uint32_t(hdr[1]) << 16 | uint32_t(hdr[2]) << 8 | hdr[3];
    if (len < 4 || len > (32u << 20)) {
        err = "Invalid lockdown frame length: " + std::to_string(len);
        return false;
    }
    out.resize(len);
    return read_exact(out.data(), len, err);
}

bool Socket::write_len_prefixed_be(std::string_view payload, std::string &err) {
    uint8_t hdr[4];
    const uint32_t n = static_cast<uint32_t>(payload.size());
    hdr[0] = static_cast<uint8_t>(n >> 24);
    hdr[1] = static_cast<uint8_t>(n >> 16);
    hdr[2] = static_cast<uint8_t>(n >> 8);
    hdr[3] = static_cast<uint8_t>(n);
    if (!write_all(hdr, 4, err)) {
        return false;
    }
    return write_all(payload.data(), payload.size(), err);
}

} // namespace xdb::transport
