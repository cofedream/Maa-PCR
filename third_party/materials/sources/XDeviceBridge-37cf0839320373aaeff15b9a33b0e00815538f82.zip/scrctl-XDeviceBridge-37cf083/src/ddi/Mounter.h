#pragma once

#include "ddi/Download.h"
#include "plist/Plist.h"
#include <vector>

namespace xdb::ddi {

// The adapter owns framing, TLS/RSD and the live connection. Each operation
// must enforce the supplied remaining timeout, including reconnect/handshake.
struct PlistService {
    std::function<std::optional<plist::Value>(const plist::Value &, std::chrono::milliseconds, std::string &)> request;
    std::function<std::optional<plist::Value>(std::chrono::milliseconds, std::string &)> receive;
    std::function<bool(const uint8_t *, size_t, std::chrono::milliseconds, std::string &)> send_bytes;
    std::function<bool(std::chrono::milliseconds, std::string &)> reconnect;
};

struct MountOptions {
    std::chrono::seconds timeout{300};
    std::function<bool()> cancelled;
    std::function<void(uint64_t, uint64_t)> progress;
    bool replace_existing = false;
    // Returns an Apple-signed ApImg4Ticket. Identifiers and nonce are obtained
    // from this connection; the callback must also enforce remaining timeout.
    std::function<std::optional<std::vector<uint8_t>>(
        const plist::Value &, const plist::Value &, uint64_t, const std::vector<uint8_t> &,
        std::chrono::milliseconds, std::string &)> personalize;
};

enum class MountState { NotMounted, AlreadyMounted, Mounted };
struct MountResult {
    MountState state = MountState::NotMounted;
    std::string image_type;
    std::string verification; // LookupImage signature or CopyDevices entry.
    std::vector<uint8_t> signature;
    // Empty means an existing image was observed without comparing our ticket.
    std::optional<bool> signature_matches;
};

// Cryptex DDIs are also visible as Personalized to mobile_image_mounter.
std::optional<MountResult> inspect_mounted(PlistService &, Kind, const MountOptions &, std::string &error);
// Target-aware inspection checks Classic signatures against the pinned OS catalog
// without downloading an image. Callers must require signature_matches == true.
std::optional<MountResult> inspect_mounted(PlistService &, const DownloadTarget &, const MountOptions &, std::string &error);
// Explicit removal only; never rolls a nonce. Already absent is success.
// Verifies the image is gone; changed is set only after a verified removal.
bool unmount_current(PlistService &, Kind, const MountOptions &, std::string &error, bool *changed = nullptr);
// Classic/Personalized only. Validates pinned cache, prepares signature/ticket,
// sends image and checks mounted state. Classic reuse requires a matching signature.
// AlreadyMounted is not an installation.
std::optional<MountResult> mount_image(PlistService &, const DownloadResult &, const DownloadTarget &,
                                     uint64_t ecid, const MountOptions &, std::string &error);

namespace detail {
struct Catalog;
// Offline protocol-test seams, never used with externally supplied catalogs.
std::optional<MountResult> inspect_mounted_with_catalog(PlistService &, const Catalog &,
    const MountOptions &, std::string &error);
std::optional<MountResult> mount_image_with_catalog(PlistService &, const DownloadResult &, const DownloadTarget &,
    uint64_t ecid, const MountOptions &, const Catalog &, std::string &error);
}
} // namespace xdb::ddi
