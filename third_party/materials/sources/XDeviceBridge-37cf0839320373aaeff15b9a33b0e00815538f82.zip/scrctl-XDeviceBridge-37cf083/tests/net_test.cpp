// IPv6 上层校验和自检。
//
// 这块值得单独钉：IPv6 下 TCP/UDP 的校验和要带伪头，算错的表现是**对方静默
// 丢弃**——不报错、不回 RST，只是永远握不上手。没有对照向量的话，这种错只能
// 靠接上真机去猜，而真机上的排查成本是每次几分钟。
#ifdef _WIN32
#include <winsock2.h>
#include <ws2tcpip.h>
#else
#include <arpa/inet.h>
#endif
#include <algorithm>
#include <cstdio>
#include <cstdint>
#include <string>
#include <vector>

#include "MemoryTunnel.h"
#include <future>
#include "net/Stack.h"
#include "net/UdpSocket.h"
#include "remote/Device.h"
#include "remote/Rsd.h"

namespace {

int Failures = 0;

void check(bool ok, const std::string &what) {
    std::printf("  [%s] %s\n", ok ? "PASS" : "FAIL", what.c_str());
    if (!ok) {
        ++Failures;
    }
}

// 捕获生产 UdpSocket 经 lwIP 生成、并由隧道线程送出的 L4 字节。
std::vector<uint8_t> capture_udp(uint16_t local_port, uint16_t peer_port,
                                 const uint8_t src[16], const uint8_t dst[16],
                                 const std::vector<uint8_t> &payload) {
  char local[64], peer[64];
  inet_ntop(AF_INET6, src, local, sizeof(local));
  inet_ntop(AF_INET6, dst, peer, sizeof(peer));
  MemoryTunnel tunnel;
  std::promise<std::vector<uint8_t>> wire;
  auto result = wire.get_future();
  bool delivered = false;
  tunnel.deliver = [&](std::vector<uint8_t> packet) {
    if (packet.size() >= 48 && packet[6] == 17 && !delivered) {
      delivered = true;
      wire.set_value(std::vector<uint8_t>(packet.begin() + 40, packet.end()));
    }
  };
  xdb::net::Stack stack(tunnel, local, peer);
  std::string err;
  if (!stack.start_pump(err))
    throw std::runtime_error(err);
  xdb::net::UdpSocket socket(stack, local_port);
  if (!socket.bind(err) || !socket.send(payload, peer_port, err))
    throw std::runtime_error(err);
  if (result.wait_for(std::chrono::seconds(2)) != std::future_status::ready)
    throw std::runtime_error("UDP capture timed out");
  return result.get();
}

std::vector<uint8_t> addr(const char *text) {
    std::vector<uint8_t> a(16);
    inet_pton(AF_INET6, text, a.data());
    return a;
}

void put16(std::vector<uint8_t> &v, uint16_t x) {
    v.push_back(static_cast<uint8_t>(x >> 8));
    v.push_back(static_cast<uint8_t>(x));
}

void put32(std::vector<uint8_t> &v, uint32_t x) {
    v.push_back(static_cast<uint8_t>(x >> 24));
    v.push_back(static_cast<uint8_t>(x >> 16));
    v.push_back(static_cast<uint8_t>(x >> 8));
    v.push_back(static_cast<uint8_t>(x));
}

/// 一个 UDP 段（含 8 字节头，校验和字段置零），返回算出的校验和。
uint16_t udp_sum(const std::vector<uint8_t> &src, const std::vector<uint8_t> &dst,
                 uint16_t sport, uint16_t dport, const std::vector<uint8_t> &payload) {
    std::vector<uint8_t> dgram;
    put16(dgram, sport);
    put16(dgram, dport);
    put16(dgram, static_cast<uint16_t>(8 + payload.size()));
    put16(dgram, 0);
    dgram.insert(dgram.end(), payload.begin(), payload.end());
    return xdb::net::l4_checksum(src.data(), dst.data(), dgram.data(), dgram.size(), 17);
}

std::vector<uint8_t> tcp_seg(uint16_t sport, uint16_t dport, uint32_t seq, uint32_t ack,
                             uint8_t flags, const std::vector<uint8_t> &options) {
    std::vector<uint8_t> seg;
    put16(seg, sport);
    put16(seg, dport);
    put32(seg, seq);
    put32(seg, ack);
    seg.push_back(static_cast<uint8_t>((5 + options.size() / 4) << 4));
    seg.push_back(flags);
    put16(seg, 65535);
    put16(seg, 0);  // 校验和位置零
    put16(seg, 0);
    seg.insert(seg.end(), options.begin(), options.end());
    return seg;
}

uint16_t tcp_sum(const std::vector<uint8_t> &src, const std::vector<uint8_t> &dst,
                 const std::vector<uint8_t> &seg) {
    return xdb::net::l4_checksum(src.data(), dst.data(), seg.data(), seg.size(), 6);
}

}  // namespace

int main() {
    std::setvbuf(stdout, nullptr, _IONBF, 0);
    const auto src = addr("fd12::2");
    const auto dst = addr("fd12::1");

    std::printf("== 对照向量（另一套独立实现按 RFC 1071/2460 算出）==\n");
    check(udp_sum(src, dst, 5000, 4000, {}) == 0xE28D, "UDP 空载荷");
    check(udp_sum(src, dst, 5000, 4000, {'h', 'i'}) == 0x7A20, "UDP 2 字节载荷");
    // 59 字节：奇数长度，走"末字节补零"那条分支
    std::vector<uint8_t> odd;
    for (uint8_t i = 1; i <= 59; ++i) {
        odd.push_back(i);
    }
    check(udp_sum(src, dst, 49152, 5004, odd) == 0xAA49, "UDP 奇数长度载荷");

    const auto bare = tcp_seg(49152, 5004, 7, 0, 0x12, {});
    check(bare.size() == 20, "无选项的 TCP 头 20 字节");
    check(tcp_sum(src, dst, bare) == 0xE216, "TCP SYN");
    const auto with_mss = tcp_seg(49152, 5004, 7, 0, 0x12, {0x02, 0x04, 0x3E, 0x94});
    check(with_mss.size() == 24, "带 MSS 选项的 TCP 头 24 字节");
    check(tcp_sum(src, dst, with_mss) == 0x917A, "TCP SYN + MSS 选项");

    std::printf("\n== 校验和的自反性 ==\n");
    // 把算出来的和填回字段再整段重算，结果必须是 0——这是接收端的判据。
    {
        std::vector<uint8_t> dgram;
        const uint16_t s = udp_sum(src, dst, 5000, 4000, odd);
        put16(dgram, 5000);
        put16(dgram, 4000);
        put16(dgram, static_cast<uint16_t>(8 + odd.size()));
        put16(dgram, s);
        dgram.insert(dgram.end(), odd.begin(), odd.end());
        check(xdb::net::l4_checksum(dst.data(), src.data(), dgram.data(), dgram.size(), 17) ==
                  0,
              "接收端重算得 0");
        dgram[9] ^= 0x01;  // 改一个载荷字节
        check(xdb::net::l4_checksum(dst.data(), src.data(), dgram.data(), dgram.size(), 17) !=
                  0,
              "载荷被改后重算不为 0");
    }

    std::printf("\n== 金标准：苹果真的被设备收进的那个 RTCP 包 ==\n");
    // 来源：Xcode DeviceHub 镜像时的抓包（utun 已被 remoted 解封装，内层明文），
    // 客户端 fda4:4c2:5901::2:49637 -> 设备 fda4:4c2:5901::1:56179 的一个 32 字节 RCTL。
    //
    // 为什么要钉这一条：设备的内核计数器显示我们发往它媒体 socket 的 UDP
    // **一个都没进去**（`udp_connection_summary ... pkts in: 0`，见 docs §13），
    // 于是"是不是我们的 IPv6/UDP 头或校验和算错、被内核静默丢掉"成了头号嫌疑。
    // 这个怀疑不能靠读代码排除——校验和算错的表现恰恰就是"对方静默丢弃"。
    // 拿一个**同类流量、同一条隧道、设备确实收进了**的真实包当对照向量。
    //
    // **但这一条只测到了 `l4_checksum` 这个零件，没测到真正上线的字节**：它用的是
    // 本文件里自己写的 `udp_sum()` 助手（拼装是对的），而产品代码走的是
    // `UdpSocket::send()`——根因恰恰在后者。所以"结果：一致"当时被误读成
    // "我们这侧的封装划掉嫌疑了"，那是过头的结论。教训记在这里：对照向量要对的是
    // **即将发出去的那一串字节**，不是参与计算的某个函数。见下面那条回归测。
    {
        const auto a_src = addr("fda4:4c2:5901::2");
        const auto a_dst = addr("fda4:4c2:5901::1");
        const std::vector<uint8_t> a_payload = {
            0x80, 0xcc, 0x00, 0x07, 0x00, 0x65, 0xbb, 0xd8, 0x52, 0x43, 0x54, 0x4c,
            0x85, 0x00, 0x00, 0x04, 0x00, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x06,
            0x90, 0x64, 0x00, 0x00, 0x00, 0x48, 0x00, 0x00};
        const uint16_t ours = udp_sum(a_src, a_dst, 49637, 56179, a_payload);
        check(ours == 0xB212,
              "我们对苹果那个包算出的校验和 == 抓包里的 0xb212（" + std::to_string(ours) + "）");
        // 回验方向也要过：把抓到的校验和塞回头字段整段重算得 0，
        // 说明我们的算法与苹果的收发两端是同一套。
        std::vector<uint8_t> wire;
        put16(wire, 49637);
        put16(wire, 56179);
        put16(wire, static_cast<uint16_t>(8 + a_payload.size()));
        put16(wire, 0xB212);
        wire.insert(wire.end(), a_payload.begin(), a_payload.end());
        check(xdb::net::l4_checksum(a_src.data(), a_dst.data(), wire.data(), wire.size(), 17) ==
                  0,
              "用苹果抓包里的校验和回验得 0");
        // 同一个向量现在改走产品代码的拼装：结果必须一模一样。
        // （曾经的版本在这里会给出完全不同的字节，而这条测当时不存在。）
        const auto via_product = capture_udp(49637, 56179, a_src.data(),
                                                                 a_dst.data(), a_payload);
        check(via_product == wire, "产品代码拼出的苹果那个包 == 抓包字节（逐字节相等）");
    }

    std::printf("\n== 回归：我们自己发出去的 UDP 字节 ==\n");
    // 20 秒断流的根因就在这一段拼装里，而它躲过了上面所有校验和测试。
    // 错法是：头缓冲区按"头+载荷"的长度申请（内容是填零），载荷却又 append 到尾巴上。
    // 于是三件事同时发生：
    //   1) 声明在长度字段里的那 N 字节载荷**全是 0**——真正的载荷跑到了缓冲区尾巴；
    //   2) UDP 长度字段比缓冲区真实长度少 N，IPv6 头里的 payload length 又是按真实
    //      长度写的，两者不一致；
    //   3) 校验和按**两倍的长度**算，而内核只核对长度字段那么多字节 → 校验失败。
    // 内核丢弃一个校验和错的 UDP 数据报是**静默**的：不回错、不计进 socket 的
    // `pkts in`，所以设备侧唯一的表现就是"一个都没收到"——排查时手里的包形状
    // 全都对，因为错的从来不是形状，是缓冲区。
    {
        const auto s = addr("fd00::2");
        const auto d = addr("fd00::1");
        const std::vector<uint8_t> payload = {'A', 'B', 'C', 'D'};
        const auto dgram = capture_udp(0x1234, 0x5678, s.data(), d.data(),
                                                           payload);
        const uint16_t declared = static_cast<uint16_t>(dgram[4] << 8 | dgram[5]);
        check(dgram.size() == payload.size() + 8, "数据报长度 = 8 + 载荷长（不是两倍）");
        check(declared == dgram.size(), "UDP 长度字段 == 缓冲区真实字节数");
        check(std::equal(payload.begin(), payload.end(), dgram.begin() + 8),
              "载荷紧跟在 8 字节头之后（不是零、也没重复一遍）");
        // 内核是按长度字段裁完字节再核对的，所以自校验也必须用这个长度。
        check(xdb::net::l4_checksum(s.data(), d.data(), dgram.data(), declared, 17) == 0,
              "按内核会核对的那段字节自校验得 0");
        // 偶数长度的载荷走完上面三步；奇数长度会碰上半字节进位，单独测一个。
        const std::vector<uint8_t> odd = {'X', 'Y', 'Z'};
        const auto odd_dgram =
            capture_udp(0x1234, 0x5678, s.data(), d.data(), odd);
        check(odd_dgram.size() == 11 && std::equal(odd.begin(), odd.end(), odd_dgram.begin() + 8),
              "奇数长度载荷：长度 11、载荷在第 9 字节起");
        check(xdb::net::l4_checksum(s.data(), d.data(), odd_dgram.data(), odd_dgram[4] << 8 |
                                                               odd_dgram[5],
                                       17) == 0,
              "奇数长度载荷按声明长度自校验得 0");
    }

    // 连接失败时的两句"人话"必须离线可判：一份外部反馈里那台设备连着重试了好几轮，
    // 而我们补的后缀把方向指错了（`PasswordProtected` 是锁屏，不是 DDI），另一处只报
    // "缺哪个服务"、不报"目录里有什么"，远程就分不开"没挂 DDI"与"这版系统没这个服务"。
    std::printf("\n== 连接失败的措辞要把方向指对 ==\n");
    {
        // Invalid local records are detected before any network I/O, without calling them device rejections.
        using xdb::transport::DeviceError;
        xdb::transport::IoBudget budget;
        DeviceError failure = DeviceError::unauthorized;
        std::string error;
        xdb::wifi::PairRecord incomplete;
        auto missing = xdb::remote::Device::establish_wifi_bounded("invalid host", incomplete, budget,
                                                                  error, false, 49152, &failure);
        check(!missing && failure == DeviceError::not_paired && error.find("xdb -e pair") != std::string::npos,
              "incomplete local record is not an explicit device rejection");
        xdb::transport::IoBudget cancelled({std::chrono::milliseconds(1), [] { return true; }});
        failure = DeviceError::unauthorized;
        auto stopped = xdb::remote::Device::establish_wifi_bounded("invalid host", incomplete, cancelled,
                                                                  error, false, 49152, &failure);
        check(!stopped && failure == DeviceError::other, "cancellation clears previous authorization classification");
        using xdb::remote::proxy_failure_hint;
        const auto locked = proxy_failure_hint("StartService(x) 被拒: PasswordProtected");
        check(locked.find("locked") != std::string::npos &&
                  locked.find("unlock") != std::string::npos,
              "PasswordProtected -> 请解锁（不能再暗示 DDI）: " + locked);
        check(locked.find("mounting") == std::string::npos,
              "锁屏那一句里不许反问 DDI 挂载不挂载——两条提问会让用户两条都去查: " + locked);
        check(locked.find("DDI") == std::string::npos,
              "但要明说这不是 DDI 的事，省得他自己去猜: " + locked);
        const auto denied = proxy_failure_hint("StartService(x) 被拒: UserDenied");
        check(denied.find("Trust") != std::string::npos, "UserDenied -> 点信任: " + denied);
        const auto nosvc = proxy_failure_hint("StartService(x) 被拒: InvalidService");
        check(nosvc.find("DDI") != std::string::npos, "InvalidService -> 查 DDI: " + nosvc);
        check(nosvc.find("xdb ddi prepare") != std::string::npos,
              "服务缺失提供正式镜像下载入口: " + nosvc);
        check(proxy_failure_hint("连接被重置").find("DDI") != std::string::npos,
              "认不出的错误保留原来那句兜底提问（不能一个都不给）");

        using xdb::remote::Rsd;
        std::vector<xdb::remote::ServiceInfo> seen;
        const auto empty_msg = Rsd::missing_service_message("com.apple.x.displayservice", seen);
        check(empty_msg.find("empty") != std::string::npos,
              "目录为空要说清是空的（那是隧道没通，不是缺服务）: " + empty_msg);
        seen.push_back({"com.apple.coredevice.hid.indigo", 50001, true, false, "",
                        {"com.apple.coredevice.feature.remote.hid.button"}});
        seen.push_back({"com.apple.coredevice.displayservice", 50002, true, false, "", {}});
        seen.push_back({"com.apple.mobile.installation_proxy", 60100, false, true, "", {}});
        const auto msg = Rsd::missing_service_message("com.apple.coredevice.screenshotservice", seen);
        check(msg.find("contains 3 services") != std::string::npos, "要报目录总条数: " + msg);
        check(msg.find("including 2 com.apple.coredevice.*") != std::string::npos,
              "coredevice 那一族要单独点数——它才是「挂没挂 DDI」的判据: " + msg);
        check(msg.find("com.apple.coredevice.hid.indigo") != std::string::npos,
              "族里的每一条都要打出来: " + msg);
        check(msg.find("installation_proxy") == std::string::npos,
              "族外的不列（实测一台设备有 85 条，全列反而没人读）: " + msg);
        check(msg.find("com.apple.coredevice.screenshotservice") != std::string::npos,
              "缺的那个名字本身也必须在句子里");
        check(msg.find("Include this service diagnostic") != std::string::npos, "给出可用于报告问题的服务诊断: " + msg);
        // 一台只挂了裸 CoreDevice、没有媒体服务的设备（外部反馈那台 iPad 的形状）：
        // 报错必须能把它和"DDI 完全没挂"分开。
        const auto no_cd = Rsd::missing_service_message(
            "com.apple.coredevice.displayservice",
            {{"com.apple.mobile.installation_proxy", 60100, false, true, "", {}}});
        check(no_cd.find("none found") != std::string::npos &&
                  no_cd.find("xdb ddi prepare") != std::string::npos,
              "coredevice 族为空 -> 直接指向「检查 DDI，使用 xdb ddi prepare」: " + no_cd);
        const auto partial_ddi = Rsd::missing_service_message(
            "com.apple.coredevice.displayservice",
            {{"com.apple.coredevice.deviceinfo", 60100, false, true, "", {}}});
        check(partial_ddi.find("mounted DDI may still lack") != std::string::npos &&
                  partial_ddi.find("xdb ddi prepare") != std::string::npos,
              "部分开发服务存在时仍指出镜像能力差异，不把目录存在当成媒体可用: " + partial_ddi);
        // iOS 18 的设备会按版本拒掉媒体流（code 9021）。只转述设备原话的话，用户会照着
        // 去查 DDI 与配对——而这两样都是好的，门槛在设备系统版本上。
        const auto gate = xdb::remote::Rsd::remote_control_version_hint(
            "Remote control requires iOS 27.0 or later on this device.");
        check(gate.find("iOS 27") != std::string::npos && gate.find("iOS 18") != std::string::npos,
              "版本门槛要明说「不是 DDI 没挂、不是配对问题」: " + gate);
        check(gate.find("Screenshot fallback") != std::string::npos,
              "要交代同机上还有什么能用: " + gate);
        check(xdb::remote::Rsd::remote_control_version_hint(
                  "The operation couldn't be completed.") == "",
              "无关的设备错误不贴这段补白");
    }

    std::printf("\n%s (失败 %d 项)\n", Failures == 0 ? "全部通过" : "存在失败", Failures);
    return Failures == 0 ? 0 : 1;
}
