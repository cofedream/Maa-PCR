﻿using MaaFramework.Binding.Buffers;
using MaaFramework.Binding.Interop.Native;
using System.Diagnostics.CodeAnalysis;
using static MaaFramework.Binding.Interop.Native.MaaToolkit;
using static MaaFramework.Binding.Interop.Native.MaaToolkitMacOS;

namespace MaaFramework.Binding;

/// <summary>
///     A wrapper class providing a reference implementation for <see cref="MaaFramework.Binding.Interop.Native.MaaToolkit"/>.
/// </summary>
public class MaaToolkit : IMaaToolkit
{
    /// <summary>
    ///    Gets the shared <see cref="MaaToolkit"/> instance.
    /// </summary>
    public static MaaToolkit Shared { get; } = new();

    /// <summary>
    ///     Creates a <see cref="MaaToolkit"/> instance.
    /// </summary>
    /// <param name="init">Whether invokes the <see cref="IMaaToolkitConfig.InitOption"/>.</param>
    /// <param name="userPath">The user path. Default is <see cref="Environment.CurrentDirectory"/>.</param>
    /// <param name="defaultJson">The default config. Default is an empty json.</param>
    public MaaToolkit(bool init = false, string userPath = nameof(Environment.CurrentDirectory), [StringSyntax("Json")] string defaultJson = "{}")
    {
        if (init)
        {
            _ = Config.InitOption(userPath, defaultJson);
        }
    }

    /// <inheritdoc/>
    public IMaaToolkitConfig Config { get; } = new ConfigClass();

    /// <inheritdoc/>
    public IMaaToolkitAdbDevice AdbDevice { get; } = new AdbDeviceClass();

    /// <inheritdoc/>
    public IMaaToolkitDesktop Desktop { get; } = new DesktopClass();

    /// <inheritdoc/>
    public IMaaToolkitMacOS MacOS { get; } = new MacOSClass();

    /// <inheritdoc cref="MaaToolkit"/>
    protected internal class ConfigClass : IMaaToolkitConfig
    {
        /// <inheritdoc/>
        /// <remarks>
        ///     Wrapper of <see cref="MaaToolkitConfigInitOption"/>.
        /// </remarks>
        public bool InitOption(string userPath = nameof(Environment.CurrentDirectory), [StringSyntax("Json")] string defaultJson = "{}")
        {
            if (userPath == nameof(Environment.CurrentDirectory))
                userPath = Environment.CurrentDirectory;
            return MaaToolkitConfigInitOption(userPath, defaultJson);
        }
    }

    /// <inheritdoc cref="MaaToolkit"/>
    protected internal class AdbDeviceClass : IMaaToolkitAdbDevice
    {
        /// <inheritdoc/>
        public IMaaListBuffer<AdbDeviceInfo> Find(string adbPath = "")
        {
            var list = new AdbDeviceListBuffer();
            _ = string.IsNullOrWhiteSpace(adbPath)
                ? MaaToolkitAdbDeviceFind(list.Handle).ThrowIfFalse()
                : MaaToolkitAdbDeviceFindSpecified(adbPath, list.Handle).ThrowIfFalse();
            return list;
        }

        /// <inheritdoc/>
        public async Task<IMaaListBuffer<AdbDeviceInfo>> FindAsync(string adbPath = "")
        {
            var list = new AdbDeviceListBuffer();
            await Task.Run(() =>
            {
                _ = string.IsNullOrWhiteSpace(adbPath)
                    ? MaaToolkitAdbDeviceFind(list.Handle).ThrowIfFalse()
                    : MaaToolkitAdbDeviceFindSpecified(adbPath, list.Handle).ThrowIfFalse();
            });
            return list;
        }
    }

    /// <inheritdoc cref="MaaToolkit"/>
    protected internal class DesktopClass : IMaaToolkitDesktop
    {
        /// <inheritdoc/>
        public IMaaToolkitDesktopWindow Window { get; } = new DesktopWindowClass();
    }

    /// <inheritdoc cref="MaaToolkit"/>
    protected internal class DesktopWindowClass : IMaaToolkitDesktopWindow
    {
        /// <remarks>
        ///     Wrapper of <see cref="MaaToolkitDesktopWindowFindAll"/>.
        /// </remarks>
        /// <inheritdoc/>
        public IMaaListBuffer<DesktopWindowInfo> Find()
        {
            var list = new DesktopWindowListBuffer();
            _ = MaaToolkitDesktopWindowFindAll(list.Handle).ThrowIfFalse();
            return list;
        }
    }

    /// <inheritdoc cref="MaaToolkit"/>
    protected internal class MacOSClass : IMaaToolkitMacOS
    {
        /// <inheritdoc/>
        /// <remarks>
        ///     Wrapper of <see cref="MaaToolkitMacOSCheckPermission"/>.
        /// </remarks>
        public bool CheckPermission(MacOSPermission permission)
            => MaaToolkitMacOSCheckPermission((MaaMacOSPermission)permission);

        /// <inheritdoc/>
        /// <remarks>
        ///     Wrapper of <see cref="MaaToolkitMacOSRequestPermission"/>.
        /// </remarks>
        public bool RequestPermission(MacOSPermission permission)
            => MaaToolkitMacOSRequestPermission((MaaMacOSPermission)permission);

        /// <inheritdoc/>
        /// <remarks>
        ///     Wrapper of <see cref="MaaToolkitMacOSRevealPermissionSettings"/>.
        /// </remarks>
        public bool RevealPermissionSettings(MacOSPermission permission)
            => MaaToolkitMacOSRevealPermissionSettings((MaaMacOSPermission)permission);
    }
}
