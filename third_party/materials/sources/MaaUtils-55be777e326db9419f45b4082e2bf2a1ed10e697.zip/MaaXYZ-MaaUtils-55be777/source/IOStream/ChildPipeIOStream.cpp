#include "MaaUtils/IOStream/ChildPipeIOStream.h"

#include "MaaUtils/Encoding.h"
#include "MaaUtils/Logger.h"
#include "MaaUtils/Time.hpp"

#if MAAUTILS_HAS_BOOST_PROCESS && !defined(_WIN32)
#include <cerrno>
#include <fcntl.h>
#include <limits>
#include <poll.h>
#include <unistd.h>
#endif

MAA_NS_BEGIN

#ifdef _WIN32
struct prevent_inherit : boost::process::extend::handler
{
    template <typename Char, typename Sequence>
    void on_setup(boost::process::extend::windows_executor<Char, Sequence>& exec)
    {
        SIZE_T size = 0;
        InitializeProcThreadAttributeList(NULL, 1, 0, &size);
        auto attrlist = reinterpret_cast<LPPROC_THREAD_ATTRIBUTE_LIST>(HeapAlloc(GetProcessHeap(), 0, size));
        InitializeProcThreadAttributeList(attrlist, 1, 0, &size);
        HANDLE empty[1] = {};
        UpdateProcThreadAttribute(attrlist, 0, PROC_THREAD_ATTRIBUTE_HANDLE_LIST, empty, 0, NULL, NULL);
        exec.startup_info_ex.lpAttributeList = attrlist;
    }

    template <typename Char, typename Sequence>
    void on_error(boost::process::extend::windows_executor<Char, Sequence>& exec, const std::error_code&) const
    {
        if (exec.startup_info_ex.lpAttributeList) {
            HeapFree(GetProcessHeap(), 0, exec.startup_info_ex.lpAttributeList);
        }
    }

    template <typename Char, typename Sequence>
    void on_success(boost::process::extend::windows_executor<Char, Sequence>& exec) const
    {
        if (exec.startup_info_ex.lpAttributeList) {
            HeapFree(GetProcessHeap(), 0, exec.startup_info_ex.lpAttributeList);
        }
    }
};

std::vector<std::wstring> conv_args(const std::vector<std::string>& args)
{
    std::vector<std::wstring> wargs;
    for (const auto& arg : args) {
        wargs.emplace_back(to_u16(arg));
    }
    return wargs;
}
#else
std::vector<std::string> conv_args(const std::vector<std::string>& args)
{
    return args;
}
#endif

ChildPipeIOStream::ChildPipeIOStream(const std::filesystem::path& exec, const std::vector<std::string>& args)
    : ChildPipeIOStream(exec, conv_args(args), false)
{
}

#ifdef _WIN32
ChildPipeIOStream::ChildPipeIOStream(const std::filesystem::path& exec, const std::vector<std::wstring>& wargs)
    : ChildPipeIOStream(exec, wargs, false)
{
}
#endif

std::string ChildPipeIOStream::read_some(size_t count, duration_t timeout)
{
#if MAAUTILS_HAS_BOOST_PROCESS && !defined(_WIN32)
    const auto start = std::chrono::steady_clock::now();
    std::string result;
    while (is_open() && result.size() < count) {
        const auto elapsed = duration_since(start);
        if (elapsed >= timeout) {
            break;
        }
        const auto remaining = timeout == duration_t::max() ? timeout : timeout - elapsed;
        result.append(read_once(count - result.size(), remaining));
    }
    return result;
#else
    return IOStream::read_some(count, timeout);
#endif
}

std::string ChildPipeIOStream::read_until(std::string_view delimiter, duration_t timeout)
{
#if MAAUTILS_HAS_BOOST_PROCESS && !defined(_WIN32)
    const auto start = std::chrono::steady_clock::now();
    std::string result;
    while (is_open() && !result.ends_with(delimiter)) {
        const auto elapsed = duration_since(start);
        if (elapsed >= timeout) {
            break;
        }
        const auto remaining = timeout == duration_t::max() ? timeout : timeout - elapsed;
        result.append(read_once(1, remaining));
    }
    return result;
#else
    return IOStream::read_until(delimiter, timeout);
#endif
}

#if MAAUTILS_HAS_BOOST_PROCESS
ChildPipeIOStream::ChildPipeIOStream(const std::filesystem::path& exec, const std::vector<os_string>& args, bool)
    : exec_(exec)
    , args_(args)
    , child_(
          exec_,
          args_,
          boost::process::std_out > pin_,
          boost::process::std_err > boost::process::null,
          boost::process::std_in < pout_,
          boost::process::start_dir = exec_.parent_path()
#ifdef _WIN32
              ,
          prevent_inherit(),
          boost::process::windows::create_no_window
#endif
      )
{
    LogDebug << VAR(exec_) << VAR(args_) << VAR(child_.id());
#ifndef _WIN32
    // Read stdout directly: istream::read waits for count bytes or EOF, so a
    // child holding a partial buffer open can bypass IOStream's timeout forever.
    const int fd = pin_.pipe().native_source();
    const int flags = fcntl(fd, F_GETFL);
    if (flags == -1 || fcntl(fd, F_SETFL, flags | O_NONBLOCK) == -1) {
        const int error = errno;
        LogError << "cannot make child stdout nonblocking" << VAR(error) << VAR(child_.id());
        pin_.setstate(std::ios::badbit);
    }
#endif
}

ChildPipeIOStream::~ChildPipeIOStream()
{
    release();
}

bool ChildPipeIOStream::write(std::string_view data)
{
    if (!pout_.good()) {
        LogError << "pout is not good" << VAR(exec_) << VAR(args_) << VAR(child_.id());
        return false;
    }

    pout_ << data << std::endl;
    return true;
}

bool ChildPipeIOStream::release()
{
    auto start_time = std::chrono::steady_clock::now();
    using namespace std::chrono_literals;
    while (child_.running() && duration_since(start_time) < 100ms) {
        std::this_thread::yield();
    }

    if (child_.running()) {
        child_.terminate();
    }
    else {
        child_.wait();
    }

    int code = child_.exit_code();

    if (code != 0) {
        LogWarn << "child exit with" << code << VAR(exec_) << VAR(args_) << VAR(child_.id());
        return false;
    }

    return true;
}

bool ChildPipeIOStream::is_open() const
{
#ifdef _WIN32
    return !pin_.eof();
#else
    return !pin_.eof() && !pin_.bad();
#endif
}

bool ChildPipeIOStream::running()
{
    return child_.running();
}

bool ChildPipeIOStream::eof() const
{
    return pin_.eof() && !pin_.bad();
}

std::string ChildPipeIOStream::read_once(size_t max_count)
{
    return read_once(max_count, duration_t::max());
}

std::string ChildPipeIOStream::read_once(size_t max_count, duration_t timeout)
{
    constexpr size_t kBufferSize = 128 * 1024;

    if (!buffer_) {
        buffer_ = std::make_unique<char[]>(kBufferSize);
    }

    size_t count = std::min(kBufferSize, max_count);
#ifdef _WIN32
    (void)timeout;
    auto read = pin_.read(buffer_.get(), count).gcount();
    return std::string(buffer_.get(), read);
#else
    if (count == 0 || !is_open()) {
        return { };
    }

    // Wait for the remaining deadline, or indefinitely for an unbounded read.
    // O_NONBLOCK protects the read after poll; interrupted waits return to the
    // outer loop to recompute the remaining time against the original deadline.
    pollfd descriptor { pin_.pipe().native_source(), POLLIN, 0 };
    const int wait_ms =
        timeout == duration_t::max() ? -1 : static_cast<int>(std::min<duration_t::rep>(timeout.count(), std::numeric_limits<int>::max()));
    const int ready = poll(&descriptor, 1, wait_ms);
    if (ready == 0 || (ready < 0 && errno == EINTR)) {
        return { };
    }
    if (ready < 0) {
        const int error = errno;
        LogError << "poll child stdout failed" << VAR(error) << VAR(child_.id());
        pin_.setstate(std::ios::badbit);
        return { };
    }

    // POLLHUP may accompany unread data. Drain it before marking EOF.
    const auto bytes_read = ::read(descriptor.fd, buffer_.get(), count);
    if (bytes_read > 0) {
        return std::string(buffer_.get(), static_cast<size_t>(bytes_read));
    }
    if (bytes_read == 0) {
        pin_.setstate(std::ios::eofbit);
    }
    else if (errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR) {
        const int error = errno;
        LogError << "read child stdout failed" << VAR(error) << VAR(child_.id());
        pin_.setstate(std::ios::badbit);
    }
    return { };
#endif
}
#else
ChildPipeIOStream::ChildPipeIOStream(const std::filesystem::path& exec, const std::vector<os_string>& args, bool)
    : exec_(exec)
    , args_(args)
{
    LogError << "Boost.Process is not available in this build" << VAR(exec_);
}

ChildPipeIOStream::~ChildPipeIOStream()
{
}

bool ChildPipeIOStream::write(std::string_view)
{
    LogError << "Boost.Process is not available in this build" << VAR(exec_);
    return false;
}

bool ChildPipeIOStream::release()
{
    return false;
}

bool ChildPipeIOStream::is_open() const
{
    return false;
}

bool ChildPipeIOStream::running()
{
    return false;
}

bool ChildPipeIOStream::eof() const
{
    return false;
}

std::string ChildPipeIOStream::read_once(size_t)
{
    return { };
}

std::string ChildPipeIOStream::read_once(size_t, duration_t)
{
    return { };
}
#endif

MAA_NS_END
