#pragma once

#include <filesystem>
#include <memory>
#include <vector>

#include "IOStream.h"
#include "MaaUtils/Port.h"

MAA_NS_BEGIN

class MAA_UTILS_API ChildPipeIOStream : public IOStream
{
public:
    ChildPipeIOStream(const std::filesystem::path& exec, const std::vector<std::string>& args);

#ifdef _WIN32
    ChildPipeIOStream(const std::filesystem::path& exec, const std::vector<std::wstring>& wargs);
#endif

    // NonCopyButMovable
    // https://stackoverflow.com/questions/29289956/c11-virtual-destructors-and-auto-generation-of-move-special-functions
    ChildPipeIOStream(const ChildPipeIOStream&) = delete;
    ChildPipeIOStream(ChildPipeIOStream&&) = default;
    ChildPipeIOStream& operator=(const ChildPipeIOStream&) = delete;
    ChildPipeIOStream& operator=(ChildPipeIOStream&&) = default;

    virtual ~ChildPipeIOStream() override;

public:
    virtual bool write(std::string_view data) override;

    virtual std::string read_some(size_t count, duration_t timeout = duration_t::max()) override;
    virtual std::string read_until(std::string_view delimiter, duration_t timeout = duration_t::max()) override;

    virtual bool release() override;
    virtual bool is_open() const override;

    bool running();

    // A timed read or an I/O error is not successful stdout completion.
    bool eof() const;

protected:
    virtual std::string read_once(size_t max_count) override;

private:
    using os_string = std::filesystem::path::string_type;

    ChildPipeIOStream(const std::filesystem::path& exec, const std::vector<os_string>& args, bool);

    std::string read_once(size_t max_count, duration_t timeout);

private:
    std::filesystem::path exec_;
    std::vector<os_string> args_;

#if MAAUTILS_HAS_BOOST_PROCESS
    boost::process::ipstream pin_;
    boost::process::opstream pout_;
    boost::process::child child_;
#endif

    std::unique_ptr<char[]> buffer_ = nullptr;
};

MAA_NS_END
